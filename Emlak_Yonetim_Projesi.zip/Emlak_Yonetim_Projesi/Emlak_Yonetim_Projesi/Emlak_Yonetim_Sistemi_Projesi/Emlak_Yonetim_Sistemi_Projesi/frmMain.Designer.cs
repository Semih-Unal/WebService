﻿namespace Emlak_Yonetim_Sistemi_Projesi
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.btnCikis = new MetroFramework.Controls.MetroButton();
            this.btnCityCountryPart = new MetroFramework.Controls.MetroButton();
            this.btnIlanTipi = new MetroFramework.Controls.MetroButton();
            this.btnKullanici = new MetroFramework.Controls.MetroButton();
            this.btnKategori = new MetroFramework.Controls.MetroButton();
            this.btnIlanVeren = new MetroFramework.Controls.MetroButton();
            this.btnIlan = new MetroFramework.Controls.MetroButton();
            this.metroPanelForm = new MetroFramework.Controls.MetroPanel();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(20, 60);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.btnCikis);
            this.splitContainer1.Panel1.Controls.Add(this.btnCityCountryPart);
            this.splitContainer1.Panel1.Controls.Add(this.btnIlanTipi);
            this.splitContainer1.Panel1.Controls.Add(this.btnKullanici);
            this.splitContainer1.Panel1.Controls.Add(this.btnKategori);
            this.splitContainer1.Panel1.Controls.Add(this.btnIlanVeren);
            this.splitContainer1.Panel1.Controls.Add(this.btnIlan);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.metroPanelForm);
            this.splitContainer1.Size = new System.Drawing.Size(925, 528);
            this.splitContainer1.SplitterDistance = 200;
            this.splitContainer1.TabIndex = 0;
            // 
            // btnCikis
            // 
            this.btnCikis.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCikis.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnCikis.Location = new System.Drawing.Point(11, 392);
            this.btnCikis.Margin = new System.Windows.Forms.Padding(6);
            this.btnCikis.Name = "btnCikis";
            this.btnCikis.Size = new System.Drawing.Size(181, 38);
            this.btnCikis.TabIndex = 8;
            this.btnCikis.Text = "Çıkış";
            this.btnCikis.UseCustomBackColor = true;
            this.btnCikis.UseCustomForeColor = true;
            this.btnCikis.UseSelectable = true;
            this.btnCikis.Click += new System.EventHandler(this.btnCikis_Click);
            // 
            // btnCityCountryPart
            // 
            this.btnCityCountryPart.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCityCountryPart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnCityCountryPart.Location = new System.Drawing.Point(11, 292);
            this.btnCityCountryPart.Margin = new System.Windows.Forms.Padding(6);
            this.btnCityCountryPart.Name = "btnCityCountryPart";
            this.btnCityCountryPart.Size = new System.Drawing.Size(181, 38);
            this.btnCityCountryPart.TabIndex = 7;
            this.btnCityCountryPart.Text = "İl/İlçe/Semt";
            this.btnCityCountryPart.UseCustomBackColor = true;
            this.btnCityCountryPart.UseCustomForeColor = true;
            this.btnCityCountryPart.UseSelectable = true;
            this.btnCityCountryPart.Click += new System.EventHandler(this.btnSemt_Click);
            // 
            // btnIlanTipi
            // 
            this.btnIlanTipi.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnIlanTipi.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnIlanTipi.Location = new System.Drawing.Point(11, 242);
            this.btnIlanTipi.Margin = new System.Windows.Forms.Padding(6);
            this.btnIlanTipi.Name = "btnIlanTipi";
            this.btnIlanTipi.Size = new System.Drawing.Size(181, 38);
            this.btnIlanTipi.TabIndex = 4;
            this.btnIlanTipi.Text = "İlan Tipleri";
            this.btnIlanTipi.UseCustomBackColor = true;
            this.btnIlanTipi.UseCustomForeColor = true;
            this.btnIlanTipi.UseSelectable = true;
            this.btnIlanTipi.Click += new System.EventHandler(this.btnIlanTipi_Click);
            // 
            // btnKullanici
            // 
            this.btnKullanici.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnKullanici.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnKullanici.Location = new System.Drawing.Point(11, 342);
            this.btnKullanici.Margin = new System.Windows.Forms.Padding(6);
            this.btnKullanici.Name = "btnKullanici";
            this.btnKullanici.Size = new System.Drawing.Size(181, 38);
            this.btnKullanici.TabIndex = 3;
            this.btnKullanici.Text = "Kullanıcı";
            this.btnKullanici.UseCustomBackColor = true;
            this.btnKullanici.UseCustomForeColor = true;
            this.btnKullanici.UseSelectable = true;
            this.btnKullanici.Click += new System.EventHandler(this.btnKullanici_Click);
            // 
            // btnKategori
            // 
            this.btnKategori.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnKategori.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnKategori.Location = new System.Drawing.Point(11, 192);
            this.btnKategori.Margin = new System.Windows.Forms.Padding(6);
            this.btnKategori.Name = "btnKategori";
            this.btnKategori.Size = new System.Drawing.Size(181, 38);
            this.btnKategori.TabIndex = 2;
            this.btnKategori.Text = "İlan Kategoriler";
            this.btnKategori.UseCustomBackColor = true;
            this.btnKategori.UseCustomForeColor = true;
            this.btnKategori.UseSelectable = true;
            this.btnKategori.Click += new System.EventHandler(this.btnKategori_Click);
            // 
            // btnIlanVeren
            // 
            this.btnIlanVeren.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnIlanVeren.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnIlanVeren.Location = new System.Drawing.Point(12, 142);
            this.btnIlanVeren.Margin = new System.Windows.Forms.Padding(6);
            this.btnIlanVeren.Name = "btnIlanVeren";
            this.btnIlanVeren.Size = new System.Drawing.Size(181, 38);
            this.btnIlanVeren.TabIndex = 1;
            this.btnIlanVeren.Text = "İlan Veren";
            this.btnIlanVeren.UseCustomBackColor = true;
            this.btnIlanVeren.UseCustomForeColor = true;
            this.btnIlanVeren.UseSelectable = true;
            this.btnIlanVeren.Click += new System.EventHandler(this.btnIlanVeren_Click);
            // 
            // btnIlan
            // 
            this.btnIlan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnIlan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnIlan.Location = new System.Drawing.Point(13, 92);
            this.btnIlan.Margin = new System.Windows.Forms.Padding(6);
            this.btnIlan.Name = "btnIlan";
            this.btnIlan.Size = new System.Drawing.Size(181, 38);
            this.btnIlan.TabIndex = 0;
            this.btnIlan.Text = "İlanlar";
            this.btnIlan.UseCustomBackColor = true;
            this.btnIlan.UseCustomForeColor = true;
            this.btnIlan.UseSelectable = true;
            this.btnIlan.UseStyleColors = true;
            this.btnIlan.Click += new System.EventHandler(this.btnIlan_Click);
            // 
            // metroPanelForm
            // 
            this.metroPanelForm.AllowDrop = true;
            this.metroPanelForm.AutoScroll = true;
            this.metroPanelForm.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanelForm.HorizontalScrollbar = true;
            this.metroPanelForm.HorizontalScrollbarBarColor = true;
            this.metroPanelForm.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanelForm.HorizontalScrollbarSize = 10;
            this.metroPanelForm.Location = new System.Drawing.Point(0, 0);
            this.metroPanelForm.Name = "metroPanelForm";
            this.metroPanelForm.Size = new System.Drawing.Size(721, 528);
            this.metroPanelForm.TabIndex = 0;
            this.metroPanelForm.VerticalScrollbar = true;
            this.metroPanelForm.VerticalScrollbarBarColor = true;
            this.metroPanelForm.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanelForm.VerticalScrollbarSize = 10;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(965, 608);
            this.Controls.Add(this.splitContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(965, 608);
            this.Name = "frmMain";
            this.Text = "Emlak Yönetim Sistemi";
            this.TransparencyKey = System.Drawing.Color.Empty;
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private MetroFramework.Controls.MetroButton btnCityCountryPart;
        private MetroFramework.Controls.MetroButton btnIlanTipi;
        private MetroFramework.Controls.MetroButton btnKullanici;
        private MetroFramework.Controls.MetroButton btnKategori;
        private MetroFramework.Controls.MetroButton btnIlanVeren;
        private MetroFramework.Controls.MetroButton btnIlan;
        private MetroFramework.Controls.MetroButton btnCikis;
        private MetroFramework.Controls.MetroPanel metroPanelForm;
    }
}