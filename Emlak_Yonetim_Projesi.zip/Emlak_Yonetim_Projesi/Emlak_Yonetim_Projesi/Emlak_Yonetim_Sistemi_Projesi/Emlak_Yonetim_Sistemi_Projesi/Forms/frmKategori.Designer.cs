﻿namespace Emlak_Yonetim_Sistemi_Projesi.Forms
{
    partial class frmKategori
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.cbTurler = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.lblToplam = new System.Windows.Forms.Label();
            this.btnClear = new MetroFramework.Controls.MetroButton();
            this.btnDelete = new MetroFramework.Controls.MetroButton();
            this.btnUpdate = new MetroFramework.Controls.MetroButton();
            this.btnAdd = new MetroFramework.Controls.MetroButton();
            this.lstKategoriler = new System.Windows.Forms.ListBox();
            this.txtName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.lblToplamAlt = new System.Windows.Forms.Label();
            this.cbAltTurler = new MetroFramework.Controls.MetroComboBox();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.cbKategoriler = new MetroFramework.Controls.MetroComboBox();
            this.btnAltDelete = new MetroFramework.Controls.MetroButton();
            this.btnAltUpdate = new MetroFramework.Controls.MetroButton();
            this.btnAltClear = new MetroFramework.Controls.MetroButton();
            this.btnAltAdd = new MetroFramework.Controls.MetroButton();
            this.lstAltKategoriler = new System.Windows.Forms.ListBox();
            this.txtAltName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroTabControl1.SuspendLayout();
            this.metroTabPage1.SuspendLayout();
            this.metroTabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Controls.Add(this.metroTabPage1);
            this.metroTabControl1.Controls.Add(this.metroTabPage2);
            this.metroTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroTabControl1.Location = new System.Drawing.Point(0, 0);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 1;
            this.metroTabControl1.Size = new System.Drawing.Size(492, 450);
            this.metroTabControl1.TabIndex = 1;
            this.metroTabControl1.UseSelectable = true;
            this.metroTabControl1.SelectedIndexChanged += new System.EventHandler(this.metroTabControl1_SelectedIndexChanged);
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.Controls.Add(this.cbTurler);
            this.metroTabPage1.Controls.Add(this.metroLabel7);
            this.metroTabPage1.Controls.Add(this.lblToplam);
            this.metroTabPage1.Controls.Add(this.btnClear);
            this.metroTabPage1.Controls.Add(this.btnDelete);
            this.metroTabPage1.Controls.Add(this.btnUpdate);
            this.metroTabPage1.Controls.Add(this.btnAdd);
            this.metroTabPage1.Controls.Add(this.lstKategoriler);
            this.metroTabPage1.Controls.Add(this.txtName);
            this.metroTabPage1.Controls.Add(this.metroLabel1);
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.HorizontalScrollbarSize = 10;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(484, 408);
            this.metroTabPage1.TabIndex = 0;
            this.metroTabPage1.Text = "Kategori";
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            this.metroTabPage1.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.VerticalScrollbarSize = 10;
            // 
            // cbTurler
            // 
            this.cbTurler.FormattingEnabled = true;
            this.cbTurler.ItemHeight = 23;
            this.cbTurler.Location = new System.Drawing.Point(141, 8);
            this.cbTurler.Name = "cbTurler";
            this.cbTurler.Size = new System.Drawing.Size(278, 29);
            this.cbTurler.TabIndex = 34;
            this.cbTurler.UseSelectable = true;
            this.cbTurler.SelectionChangeCommitted += new System.EventHandler(this.cbTurler_SelectionChangeCommitted);
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel7.Location = new System.Drawing.Point(26, 13);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(47, 19);
            this.metroLabel7.TabIndex = 33;
            this.metroLabel7.Text = "Türü :";
            // 
            // lblToplam
            // 
            this.lblToplam.AutoSize = true;
            this.lblToplam.BackColor = System.Drawing.Color.White;
            this.lblToplam.Location = new System.Drawing.Point(23, 348);
            this.lblToplam.Name = "lblToplam";
            this.lblToplam.Size = new System.Drawing.Size(13, 13);
            this.lblToplam.TabIndex = 32;
            this.lblToplam.Text = "0";
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(154, 83);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(60, 23);
            this.btnClear.TabIndex = 12;
            this.btnClear.Text = "Temizle";
            this.btnClear.UseSelectable = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(367, 83);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(52, 23);
            this.btnDelete.TabIndex = 5;
            this.btnDelete.Text = "Sil";
            this.btnDelete.UseSelectable = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(293, 83);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(68, 23);
            this.btnUpdate.TabIndex = 5;
            this.btnUpdate.Text = "Güncelle";
            this.btnUpdate.UseSelectable = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(220, 83);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(67, 23);
            this.btnAdd.TabIndex = 5;
            this.btnAdd.Text = "Ekle";
            this.btnAdd.UseSelectable = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lstKategoriler
            // 
            this.lstKategoriler.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lstKategoriler.FormattingEnabled = true;
            this.lstKategoriler.ItemHeight = 16;
            this.lstKategoriler.Location = new System.Drawing.Point(26, 123);
            this.lstKategoriler.Name = "lstKategoriler";
            this.lstKategoriler.Size = new System.Drawing.Size(393, 212);
            this.lstKategoriler.TabIndex = 4;
            this.lstKategoriler.SelectedIndexChanged += new System.EventHandler(this.lstKategoriler_SelectedIndexChanged);
            // 
            // txtName
            // 
            // 
            // 
            // 
            this.txtName.CustomButton.Image = null;
            this.txtName.CustomButton.Location = new System.Drawing.Point(253, 1);
            this.txtName.CustomButton.Name = "";
            this.txtName.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtName.CustomButton.TabIndex = 1;
            this.txtName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtName.CustomButton.UseSelectable = true;
            this.txtName.CustomButton.Visible = false;
            this.txtName.Lines = new string[0];
            this.txtName.Location = new System.Drawing.Point(142, 43);
            this.txtName.MaxLength = 32767;
            this.txtName.Name = "txtName";
            this.txtName.PasswordChar = '\0';
            this.txtName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtName.SelectedText = "";
            this.txtName.SelectionLength = 0;
            this.txtName.SelectionStart = 0;
            this.txtName.ShortcutsEnabled = true;
            this.txtName.Size = new System.Drawing.Size(277, 25);
            this.txtName.TabIndex = 3;
            this.txtName.UseSelectable = true;
            this.txtName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.Location = new System.Drawing.Point(26, 46);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(102, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "Kategori Adı :";
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.lblToplamAlt);
            this.metroTabPage2.Controls.Add(this.cbAltTurler);
            this.metroTabPage2.Controls.Add(this.metroLabel8);
            this.metroTabPage2.Controls.Add(this.cbKategoriler);
            this.metroTabPage2.Controls.Add(this.btnAltDelete);
            this.metroTabPage2.Controls.Add(this.btnAltUpdate);
            this.metroTabPage2.Controls.Add(this.btnAltClear);
            this.metroTabPage2.Controls.Add(this.btnAltAdd);
            this.metroTabPage2.Controls.Add(this.lstAltKategoriler);
            this.metroTabPage2.Controls.Add(this.txtAltName);
            this.metroTabPage2.Controls.Add(this.metroLabel3);
            this.metroTabPage2.Controls.Add(this.metroLabel2);
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.HorizontalScrollbarSize = 10;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(484, 408);
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "Alt Kategori";
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.VerticalScrollbarSize = 10;
            // 
            // lblToplamAlt
            // 
            this.lblToplamAlt.AutoSize = true;
            this.lblToplamAlt.BackColor = System.Drawing.Color.White;
            this.lblToplamAlt.Location = new System.Drawing.Point(24, 373);
            this.lblToplamAlt.Name = "lblToplamAlt";
            this.lblToplamAlt.Size = new System.Drawing.Size(13, 13);
            this.lblToplamAlt.TabIndex = 37;
            this.lblToplamAlt.Text = "0";
            // 
            // cbAltTurler
            // 
            this.cbAltTurler.FormattingEnabled = true;
            this.cbAltTurler.ItemHeight = 23;
            this.cbAltTurler.Location = new System.Drawing.Point(158, 14);
            this.cbAltTurler.Name = "cbAltTurler";
            this.cbAltTurler.Size = new System.Drawing.Size(270, 29);
            this.cbAltTurler.TabIndex = 36;
            this.cbAltTurler.UseSelectable = true;
            this.cbAltTurler.SelectionChangeCommitted += new System.EventHandler(this.cbAltTurler_SelectionChangeCommitted);
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel8.Location = new System.Drawing.Point(27, 20);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(47, 19);
            this.metroLabel8.TabIndex = 35;
            this.metroLabel8.Text = "Türü :";
            // 
            // cbKategoriler
            // 
            this.cbKategoriler.FormattingEnabled = true;
            this.cbKategoriler.ItemHeight = 23;
            this.cbKategoriler.Location = new System.Drawing.Point(158, 49);
            this.cbKategoriler.Name = "cbKategoriler";
            this.cbKategoriler.Size = new System.Drawing.Size(270, 29);
            this.cbKategoriler.TabIndex = 12;
            this.cbKategoriler.UseSelectable = true;
            this.cbKategoriler.SelectionChangeCommitted += new System.EventHandler(this.cbKategoriler_SelectionChangeCommitted);
            // 
            // btnAltDelete
            // 
            this.btnAltDelete.Location = new System.Drawing.Point(374, 132);
            this.btnAltDelete.Name = "btnAltDelete";
            this.btnAltDelete.Size = new System.Drawing.Size(54, 23);
            this.btnAltDelete.TabIndex = 9;
            this.btnAltDelete.Text = "Sil";
            this.btnAltDelete.UseSelectable = true;
            this.btnAltDelete.Click += new System.EventHandler(this.btnAltDelete_Click);
            // 
            // btnAltUpdate
            // 
            this.btnAltUpdate.Location = new System.Drawing.Point(300, 132);
            this.btnAltUpdate.Name = "btnAltUpdate";
            this.btnAltUpdate.Size = new System.Drawing.Size(68, 23);
            this.btnAltUpdate.TabIndex = 10;
            this.btnAltUpdate.Text = "Güncelle";
            this.btnAltUpdate.UseSelectable = true;
            this.btnAltUpdate.Click += new System.EventHandler(this.btnAltUpdate_Click);
            // 
            // btnAltClear
            // 
            this.btnAltClear.Location = new System.Drawing.Point(154, 132);
            this.btnAltClear.Name = "btnAltClear";
            this.btnAltClear.Size = new System.Drawing.Size(67, 23);
            this.btnAltClear.TabIndex = 11;
            this.btnAltClear.Text = "Temizle";
            this.btnAltClear.UseSelectable = true;
            this.btnAltClear.Click += new System.EventHandler(this.btnAltClear_Click);
            // 
            // btnAltAdd
            // 
            this.btnAltAdd.Location = new System.Drawing.Point(227, 132);
            this.btnAltAdd.Name = "btnAltAdd";
            this.btnAltAdd.Size = new System.Drawing.Size(67, 23);
            this.btnAltAdd.TabIndex = 11;
            this.btnAltAdd.Text = "Ekle";
            this.btnAltAdd.UseSelectable = true;
            this.btnAltAdd.Click += new System.EventHandler(this.btnAltAdd_Click);
            // 
            // lstAltKategoriler
            // 
            this.lstAltKategoriler.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lstAltKategoriler.FormattingEnabled = true;
            this.lstAltKategoriler.ItemHeight = 16;
            this.lstAltKategoriler.Location = new System.Drawing.Point(27, 174);
            this.lstAltKategoriler.MultiColumn = true;
            this.lstAltKategoriler.Name = "lstAltKategoriler";
            this.lstAltKategoriler.Size = new System.Drawing.Size(401, 196);
            this.lstAltKategoriler.TabIndex = 8;
            this.lstAltKategoriler.SelectedIndexChanged += new System.EventHandler(this.lstAltKategoriler_SelectedIndexChanged);
            // 
            // txtAltName
            // 
            // 
            // 
            // 
            this.txtAltName.CustomButton.Image = null;
            this.txtAltName.CustomButton.Location = new System.Drawing.Point(247, 1);
            this.txtAltName.CustomButton.Name = "";
            this.txtAltName.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtAltName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtAltName.CustomButton.TabIndex = 1;
            this.txtAltName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtAltName.CustomButton.UseSelectable = true;
            this.txtAltName.CustomButton.Visible = false;
            this.txtAltName.Lines = new string[0];
            this.txtAltName.Location = new System.Drawing.Point(158, 85);
            this.txtAltName.MaxLength = 32767;
            this.txtAltName.Name = "txtAltName";
            this.txtAltName.PasswordChar = '\0';
            this.txtAltName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAltName.SelectedText = "";
            this.txtAltName.SelectionLength = 0;
            this.txtAltName.SelectionStart = 0;
            this.txtAltName.ShortcutsEnabled = true;
            this.txtAltName.Size = new System.Drawing.Size(271, 25);
            this.txtAltName.TabIndex = 7;
            this.txtAltName.UseSelectable = true;
            this.txtAltName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtAltName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.Location = new System.Drawing.Point(26, 89);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(125, 19);
            this.metroLabel3.TabIndex = 6;
            this.metroLabel3.Text = "Alt Kategori Adı :";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.Location = new System.Drawing.Point(26, 55);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(102, 19);
            this.metroLabel2.TabIndex = 6;
            this.metroLabel2.Text = "Kategori Adı :";
            // 
            // frmKategori
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(492, 450);
            this.Controls.Add(this.metroTabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmKategori";
            this.Text = "frmKategori";
            this.Load += new System.EventHandler(this.frmKategori_Load);
            this.metroTabControl1.ResumeLayout(false);
            this.metroTabPage1.ResumeLayout(false);
            this.metroTabPage1.PerformLayout();
            this.metroTabPage2.ResumeLayout(false);
            this.metroTabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroTabPage metroTabPage1;
        private MetroFramework.Controls.MetroButton btnDelete;
        private MetroFramework.Controls.MetroButton btnUpdate;
        private MetroFramework.Controls.MetroButton btnAdd;
        private System.Windows.Forms.ListBox lstKategoriler;
        private MetroFramework.Controls.MetroTextBox txtName;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private MetroFramework.Controls.MetroComboBox cbKategoriler;
        private MetroFramework.Controls.MetroButton btnAltDelete;
        private MetroFramework.Controls.MetroButton btnAltUpdate;
        private MetroFramework.Controls.MetroButton btnAltAdd;
        private System.Windows.Forms.ListBox lstAltKategoriler;
        private MetroFramework.Controls.MetroTextBox txtAltName;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroButton btnClear;
        private MetroFramework.Controls.MetroButton btnAltClear;
        private System.Windows.Forms.Label lblToplam;
        private MetroFramework.Controls.MetroComboBox cbTurler;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroComboBox cbAltTurler;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private System.Windows.Forms.Label lblToplamAlt;
    }
}