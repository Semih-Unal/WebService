﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Emlak_Yonetim_Sistemi_Projesi.Forms
{
    public partial class frmKullanici : Form
    {
        public frmKullanici()
        {
            InitializeComponent();
        }
        // Access Veritabanı kullanarak veri aktarımı gerçekleştirdik...

        string conStr = string.Format("Provider= Microsoft.Jet.OleDB.4.0; Data Source = {0}; Persist Security Info = False;", Application.StartupPath + "\\YoneticiDB.mdb");

        int secilenId;
        private void frmKullanici_Load(object sender, EventArgs e)
        {
            Listele(); // metodu altta
        }

        private void Listele()
        {
            dGwKullanicilar.Rows.Clear();
            OleDbConnection cnn = new OleDbConnection(conStr);
            try
            {
                // Linq ile tablomuzu çekelim
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();

                OleDbCommand cmd = new OleDbCommand("Select Id,KullaniciAdi,Sifre From Yoneticiler", cnn);

                OleDbDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        dGwKullanicilar.Rows.Add(reader["Id"].ToString(), reader.GetString(1), reader.GetString(2));
                    }
                }
            }
            catch (Exception ex)
            {
                frmCustomMsgBx.Show("Hatayla Karşılaşıldı, Tekrar Deneyiniz !!!" + ex.Message, frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
            finally
            {
                cnn.Close();
            }
        }
        //---------------------------
        // Ekle
        private void btnAdd_Click(object sender, EventArgs e)
        {
            OleDbConnection cnn = new OleDbConnection(conStr);
            try
            {
                // Oledb ile tablomuzu çektik
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                OleDbCommand cmd = new OleDbCommand("Select Max(Id) From Yoneticiler", cnn);

                int maxID = Convert.ToInt32(cmd.ExecuteScalar());


                if (txtSifre.Text.Length < 6)
                {
                    frmCustomMsgBx.Show("Şifre 6 karakterden az olamaz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                OleDbCommand cmd2 = new OleDbCommand("Insert Into Yoneticiler (Id,KullaniciAdi,Sifre) Values (@Id,@KullaniciAdi,@Sifre)", cnn);

                cmd2.Parameters.AddWithValue("@Id", (maxID + 1));
                cmd2.Parameters.AddWithValue("@KullaniciAdi", txtKullanici.Text);
                cmd2.Parameters.AddWithValue("@Sifre", txtSifre.Text);


                frmCustomMsgBx.Show(cmd2.ExecuteNonQuery() > 0 ? "İşleminiz Başarılı Şekilde Gerçekleştirilmiştir..." : "Hata", frmCustomMsgBx.CustomMsgbxButtons.OK);

                Listele();
                txtKullanici.Clear();
                txtSifre.Clear();

                txtKullanici.Focus();
            }
            catch (Exception ex)
            {
                frmCustomMsgBx.Show("Hatayla Karşılaşıldı, Tekrar Deneyiniz !!!" + ex.Message, frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
            finally
            {
                cnn.Close();
            }
        }
        //---------------------------
        // Güncelle
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            OleDbConnection cnn = new OleDbConnection(conStr);
            try
            {

                // Oledb ile tablomuzu çektik
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                // Sil
                OleDbCommand cmd2 = new OleDbCommand("Delete From Yoneticiler Where Id= @Id", cnn);
                
                cmd2.Parameters.AddWithValue("@Id", secilenId);
                cmd2.ExecuteNonQuery();

                OleDbCommand cmd = new OleDbCommand("Select Max(Id) From Yoneticiler", cnn);

                int maxID = Convert.ToInt32(cmd.ExecuteScalar());


                if (txtSifre.Text.Length < 6)
                {
                    frmCustomMsgBx.Show("Şifre 6 karakterden az olamaz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                // Ekle
                OleDbCommand cmd3 = new OleDbCommand("Insert Into Yoneticiler (Id,KullaniciAdi,Sifre) Values (@Id,@KullaniciAdi,@Sifre)", cnn);

                cmd3.Parameters.AddWithValue("@Id", (maxID + 1));
                cmd3.Parameters.AddWithValue("@KullaniciAdi", txtKullanici.Text);
                cmd3.Parameters.AddWithValue("@Sifre", txtSifre.Text);
                

                if (txtSifre.Text.Length < 6)
                {
                    frmCustomMsgBx.Show("Şifre 6 karakterden az olamaz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }
                
                frmCustomMsgBx.Show(cmd3.ExecuteNonQuery() > 0 ? "İşleminiz Başarılı Şekilde Gerçekleştirilmiştir..." : "Hata", frmCustomMsgBx.CustomMsgbxButtons.OK);
                
                Listele();
                txtKullanici.Clear();
                txtSifre.Clear();

                txtKullanici.Focus();
            }
            catch (Exception ex)
            {
                frmCustomMsgBx.Show("Hatayla Karşılaşıldı, Tekrar Deneyiniz !!!" + ex.Message, frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
            finally
            {
                cnn.Close();
            }
        }
        //---------------------------
        // Sil
        private void btnDelete_Click(object sender, EventArgs e)
        {
            OleDbConnection cnn = new OleDbConnection(conStr);
            try
            {
                // Linq ile tablomuzu çekelim
                if (cnn.State == ConnectionState.Closed)
                    cnn.Open();
                

                OleDbCommand cmd = new OleDbCommand("Delete From Yoneticiler Where Id= @Id", cnn);

                
               cmd.Parameters.AddWithValue("@Id", secilenId);

                frmCustomMsgBx.Show(cmd.ExecuteNonQuery() > 0 ? "İşleminiz Başarılı Şekilde Gerçekleştirilmiştir..." : "Hata", frmCustomMsgBx.CustomMsgbxButtons.OK);

                Listele();
                txtKullanici.Clear();
                txtSifre.Clear();

                txtKullanici.Focus();
            }
            catch (Exception ex)
            {
                frmCustomMsgBx.Show("Hatayla Karşılaşıldı, Tekrar Deneyiniz !!!" + ex.Message, frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
            finally
            {
                cnn.Close();
            }
        }
        //---------------------------
        // Temizle
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtKullanici.Clear();
            txtSifre.Clear();

            txtKullanici.Focus();
        }
        //---------------------------
        private void dGwKullanicilar_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            secilenId = Convert.ToInt32(dGwKullanicilar.CurrentRow.Cells[0].Value);
            txtKullanici.Text = dGwKullanicilar.CurrentRow.Cells[1].Value.ToString();
            txtSifre.Text = dGwKullanicilar.CurrentRow.Cells[2].Value.ToString();
        }
    }
}
