﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Emlak_Yonetim_Sistemi_Projesi.Forms
{
    public partial class frmIlanVeren : Form
    {
        public frmIlanVeren()
        {
            InitializeComponent();
        }
        EmlakContext db = new EmlakContext();
        int secilenID;
        bool contextmenu = false;
        private void frmIlanVeren_Load(object sender, EventArgs e)
        {
            metroTabControl1.SelectedIndex = 0;
            Listele();
        }


        private void Listele()
        {
            var ilanVerenler = db.IlanVerenler.Select(i => new
            {
                i.IlanVerenID,
                Adi = i.IlanVerenSirket,
                Detay = i.Aciklama,
                Telefon = i.IlanVerenTel,
                Mobil = i.IlanVerenCepTel,
                Web = i.IlanVerenWeb,
                Adres = i.Adres,
                Resim = i.IlanVerenResim
            }).ToList();

            dGwIlanVerenler.DataSource = ilanVerenler;

            lblToplam.Text = dGwIlanVerenler.Rows.Count.ToString();
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            var list = db.IlanVerenler.Where(l => l.IlanVerenSirket.Contains(txtSearch.Text)).Select(i => new
            {
                i.IlanVerenID,
                Adi = i.IlanVerenSirket,
                Detay = i.Aciklama,
                Telefon = i.IlanVerenTel,
                Mobil = i.IlanVerenCepTel,
                Web = i.IlanVerenWeb,
                Adres = i.Adres,
                Resim = i.IlanVerenResim
            }).ToList();

            dGwIlanVerenler.DataSource = list;
            lblToplam.Text = dGwIlanVerenler.Rows.Count.ToString();
        }

        //---------------------------------------------
        // Ekle
        #region Resim Ekle için
        string addpath;
        Image addimg;
        private void lblAddResim_DragDrop(object sender, DragEventArgs e)
        {
            object suruklenenNesne = e.Data.GetData(DataFormats.FileDrop);
            string[] suruklenenDosyalar = (string[])suruklenenNesne;

            if (suruklenenDosyalar.Length > 0)
            {
                addpath = suruklenenDosyalar[0];
                addimg = Image.FromFile(addpath);
                
                lblAddResim.Image = addimg;
                lblAddResim.ImageAlign = ContentAlignment.MiddleCenter;
                lblAddResim.Text = "";
            }
        }

        private void lblAddResim_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }
        
        private void btnAddResimSec_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "JPEG(*.jpg)|*.jpg|PNG(*.png)|*.png|All Files(*.*)|*.*";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                addpath = ofd.FileName;
                lblAddResim.Image = Image.FromFile(addpath);
                lblAddResim.ImageAlign = ContentAlignment.MiddleCenter;
                lblAddResim.Text = "";
            }
        }
        #endregion
        
        // Ekle Butonu
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtAddSirket.Text == "" || txtAddAdress.Text == "" || mtxtAddCepTel.Text == null || txtAddAciklama.Text == "" || lblAddResim.Image == null)
                {
                    frmCustomMsgBx.Show("Lütfen (*) ile işaretlenmiş olanları boş geçmeyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }
                IlanVeren ilanveren = new IlanVeren();
                if (db.IlanVerenler.Count()>0)
                    ilanveren.IlanVerenID = db.IlanVerenler.Max(i => i.IlanVerenID) + 1;
                else
                    ilanveren.IlanVerenID = 1;
                
                ilanveren.IlanVerenSirket = txtAddSirket.Text;
                ilanveren.Aciklama = txtAddAciklama.Text;
                ilanveren.IlanVerenWeb = txtAddWeb.Text;
                ilanveren.IlanVerenTel = mtxtAddTel.Text;
                ilanveren.IlanVerenCepTel = mtxtAddCepTel.Text;
                ilanveren.Adres = txtAddAdress.Text;
                //----------
                string Resim = @"..\..\Images\IlanVeren\ilanveren_" + Guid.NewGuid().ToString().Replace("-", " ").Substring(0, 5) + Path.GetExtension(addpath); 

                Image img = Image.FromFile(addpath);

                img.Save(Resim); // resmi kaydettik

                ilanveren.IlanVerenResim = Resim;
                //--------------
                
                db.IlanVerenler.Add(ilanveren);
                db.SaveChanges();
                metroTabControl1.SelectedIndex = 0;
                Listele();
                Temizle();
            }
            catch (Exception)
            {

                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        
        //---------------------------------------------
        // Güncelle

        #region Resim Güncelle için
        string updatepath;
        Image updateimg;
        private void lblUpdateResim_DragDrop(object sender, DragEventArgs e)
        {
            object suruklenenNesne = e.Data.GetData(DataFormats.FileDrop);
            string[] suruklenenDosyalar = (string[])suruklenenNesne;

            if (suruklenenDosyalar.Length > 0)
            {
                updatepath = suruklenenDosyalar[0];
                updateimg = Image.FromFile(updatepath);

                lblUpdateResim.Image = updateimg;
                lblUpdateResim.ImageAlign = ContentAlignment.MiddleCenter;
            }
        }

        private void lblUpdateResim_DragEnter(object sender, DragEventArgs e)
        {
            e.Effect = DragDropEffects.Copy;
        }
        private void btnUpdateResimSec_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "JPEG(*.jpg)|*.jpg|PNG(*.png)|*.png|All Files(*.*)|*.*";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                updatepath = ofd.FileName;
                lblUpdateResim.Image = Image.FromFile(updatepath);
                lblUpdateResim.ImageAlign = ContentAlignment.MiddleCenter;
            }
        }
        #endregion
        // Güncelle Butonu
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                IlanVeren ilanveren = db.IlanVerenler.Where(i=>i.IlanVerenID == secilenID).FirstOrDefault();

                ilanveren.IlanVerenID = secilenID;
                ilanveren.IlanVerenSirket = txtUpdateSirket.Text;
                ilanveren.Aciklama = txtUpdateAciklama.Text;
                ilanveren.IlanVerenWeb = txtUpdateWeb.Text;
                ilanveren.IlanVerenTel = mtxtUpdateTel.Text;
                ilanveren.IlanVerenCepTel = mtxtUpdateCepTel.Text;
                ilanveren.Adres = txtUpdateAdres.Text;
                //----------
                if (updatepath != null)
                {
                    string Resim = @"..\..\Images\IlanVeren\ilanveren_" + Guid.NewGuid().ToString().Replace("-", " ").Substring(0, 5) + Path.GetExtension(updatepath);

                    Image img = Image.FromFile(updatepath);

                    img.Save(Resim); // resmi kaydettik

                    ilanveren.IlanVerenResim = Resim;
                }

                //--------------
                if (txtUpdateSirket.Text == "" || txtUpdateAdres.Text == ""|| mtxtUpdateCepTel.Text == null || txtUpdateAciklama.Text == "" || lblUpdateResim.Image == null)
                {
                    frmCustomMsgBx.Show("Lütfen (*) ile işaretlenmiş olanları boş geçmeyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }
                db.SaveChanges();
                metroTabControl1.SelectedIndex = 0;
                contextmenu = false;
                Listele();
                Temizle();
            }
            catch (Exception)
            {

                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        private void dGwIlanVerenler_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            secilenID = (int)dGwIlanVerenler.SelectedRows[0].Cells[0].Value;
        }

        #region ContextMenu / Sil
        private void güncelleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (secilenID == 0)
            {
                frmCustomMsgBx.Show("Lütfen Güncellemek İstediğiniz Veriyi Seçiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                return;
            }
            contextmenu = true;
            metroTabControl1.SelectedIndex = 2;
            IlanVeren secilenItem = db.IlanVerenler.Where(i => i.IlanVerenID == secilenID).FirstOrDefault();

            txtUpdateSirket.Text = secilenItem.IlanVerenSirket;
            txtUpdateAciklama.Text = secilenItem.Aciklama;
            txtUpdateWeb.Text = secilenItem.IlanVerenWeb;
            mtxtUpdateCepTel.Text = secilenItem.IlanVerenCepTel;
            mtxtUpdateTel.Text = secilenItem.IlanVerenTel;
            txtUpdateAdres.Text = secilenItem.Adres;

            lblUpdateResim.Image = Image.FromFile(secilenItem.IlanVerenResim);

        }

        private void silToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (secilenID == 0)
            {
                frmCustomMsgBx.Show("Lütfen Silmek İstediğiniz Veriyi Seçiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                return;
            }
            if (frmCustomMsgBx.Show("Silmek İstediğinize Emin Misiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    IlanVeren ilanveren = db.IlanVerenler.Where(i => i.IlanVerenID == secilenID).FirstOrDefault();

                    db.IlanVerenler.Remove(ilanveren);
                    db.SaveChanges();

                    Listele();
                    Temizle();
                }
                catch (Exception)
                {

                    frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                }
            }
        }
        #endregion
        private void metroTabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (metroTabControl1.SelectedIndex == 2)
            {
                if (contextmenu == false)
                {
                    metroTabControl1.SelectedIndex = 0;
                    frmCustomMsgBx.Show("Lütfen Güncellemek İstediğiniz Veriyi Seçiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);

                   
                }
            }
            contextmenu = false;
        }

        private void Temizle()
        {
            // Ekle
            txtAddSirket.Clear();
            txtAddAciklama.Clear();
            txtAddWeb.Clear();
            mtxtAddTel.Clear();
            mtxtAddCepTel.Clear();
            txtAddAdress.Clear();
            lblAddResim.Image = null;
            lblAddResim.Text = "Resmi Sürükle Bırak (*)";
            // Güncelle
            txtUpdateSirket.Clear();
            txtUpdateAciklama.Clear();
            txtUpdateWeb.Clear();
            mtxtUpdateCepTel.Clear();
            mtxtUpdateTel.Clear();
            txtUpdateAdres.Clear();
            lblUpdateResim.Image = null;

            secilenID = 0;
        }

    }
}
