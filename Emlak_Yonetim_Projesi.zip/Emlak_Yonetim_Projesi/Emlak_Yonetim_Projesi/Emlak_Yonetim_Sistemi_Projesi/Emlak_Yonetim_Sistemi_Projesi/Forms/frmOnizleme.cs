﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Emlak_Yonetim_Sistemi_Projesi.Forms
{
    public partial class frmOnizleme : Form
    {
        Ilan ilan;
        public frmOnizleme(Ilan gelenIlan)
        {
            InitializeComponent();
            ilan = gelenIlan;
        }
        EmlakContext db = new EmlakContext();
        private void frmOnizleme_Load(object sender, EventArgs e)
        {
            lblTitle.Text = ilan.IlanAdi;
            lblIlanNo.Text = ilan.IlanNo.ToString();
            lblFiyat.Text = string.Format("{0:C2}", ilan.IlanFiyat);
            lblIlanTarih.Text = ilan.IlanTarihi.ToShortDateString();
            pbIlanVerenResim.Image = Image.FromFile(ilan.ilanVeren.IlanVerenResim);
            lblIlanVerenAdi.Text = ilan.ilanVeren.IlanVerenSirket;
            lblAciklama.Text = ilan.Aciklama;

            IlanDetay detay = db.IlanDetaylari.Where(d=>d.IlanID == ilan.IlanID).FirstOrDefault();

            lblNav.Text = detay.AltKategori.kategori.IlanTuru.IlanTuruAdi + " > " + detay.AltKategori.kategori.KategoriAdi + " > " + detay.AltKategori.AltKategoriAdi;
            lblBrutMetre.Text = detay.BrütMetreKare.ToString();
            lblNetMetreKare.Text = detay.NetMetreKare.ToString();
            lblAdres.Text = detay.semt.ilce.il.IlAdi + "/" + detay.semt.ilce.IlceAdi + "/" + detay.semt.SemtAdi;
            // Ek Özellikler
            var ekozelliks = db.KategoriOzellikleri.Where(ek=>ek.IlanDetayID == detay.IlanDetayID).ToList();

            foreach (KategoriOzellik ek in ekozelliks)
            {
                Label lbl5 = new Label();
                lbl5.Text = ek.Adi + " :";
                lbl5.Font = new Font("Microsoft Sans Serif",9);
                lbl5.Width = 100;
                fLpKategoriOzellik.Controls.Add(lbl5);

                Label lbl6 = new Label();
                lbl6.Text = ek.Aciklama;
                lbl6.Font = new Font("Microsoft Sans Serif", 9);
                lbl6.Width = 100;
                fLpKategoriOzellik.Controls.Add(lbl6);
            }

            // Resimler
            var resimler = db.Resimler.Where(r => r.IlanID == ilan.IlanID).ToList();
            int i = 0;
            foreach (Resim pic in resimler)
            {
                if (i == 0)
                    pbMainPic.Image = Image.FromFile(pic.ResimPath);

                Picture foto = new Picture();
                foto.index = i++;
                foto.ResimPath = pic.ResimPath;
                Button btn = new Button();
                btn.FlatStyle = FlatStyle.Flat;
                Image addimg = Image.FromFile(pic.ResimPath);
                btn.BackgroundImage = addimg;
                btn.BackgroundImageLayout = ImageLayout.Stretch;
                btn.Size = new Size(50, 50);
                btn.Margin = new Padding(5);
                btn.Tag = foto;
                fLpSlayt.Controls.Add(btn);
                btn.Click += Btn_Click;

                
            }

            // Dış Özellikleri
            Label lbl1 = new Label();
            lbl1.Text = "Dış Özellikleri :";
            lbl1.Font = new Font("Microsoft Sans Serif", 12);
            lbl1.Width = fLpOzellikler.Width;
            lbl1.Margin = new Padding(0, 5, 0, 0);
            fLpOzellikler.Controls.Add(lbl1);

            var disozelliks = db.DisOzellikleri.Where(o => o.IlanDetayID == detay.IlanDetayID).ToList();

            foreach (DisOzellik dis in disozelliks)
            {
                Label lbl = new Label();
                lbl.Text = dis.DisOzellikAdi;
                lbl.Font = new Font("Microsoft Sans Serif", 9);
                lbl.Margin = new Padding(0, 5, 0, 0);
                lbl.AutoSize = true;
                fLpOzellikler.Controls.Add(lbl);
            }

            // İç Özellikleri
            Label lbl2 = new Label();
            lbl2.Text = "İç Özellikleri :";
            lbl2.Font = new Font("Microsoft Sans Serif", 12);
            lbl2.Width = fLpOzellikler.Width;
            lbl2.Margin = new Padding(0, 5, 0, 0);
            fLpOzellikler.Controls.Add(lbl2);

            var icozelliks = db.IcOzellikleri.Where(o => o.IlanDetayID == detay.IlanDetayID).ToList();

            foreach (IcOzellik ic in icozelliks)
            {
                Label lbl = new Label();
                lbl.Text = ic.IcOzellikAdi;
                lbl.Font = new Font("Microsoft Sans Serif", 9);
                lbl.AutoSize = true;
                lbl.Margin = new Padding(0, 5, 0, 0);
                fLpOzellikler.Controls.Add(lbl);
            }

            // Konum Özellikleri
            Label lbl3 = new Label();
            lbl3.Text = "Konum Özellikleri :";
            lbl3.Font = new Font("Microsoft Sans Serif", 12);
            lbl3.Width = fLpOzellikler.Width;
            lbl3.Margin = new Padding(0, 5, 0, 0);
            fLpOzellikler.Controls.Add(lbl3);

            var konumozelliks = db.KonumOzellikleri.Where(o => o.IlanDetayID == detay.IlanDetayID).ToList();

            foreach (KonumOzellik konum in konumozelliks)
            {
                Label lbl = new Label();
                lbl.Text = konum.KonumOzellikAdi;
                lbl.Font = new Font("Microsoft Sans Serif", 9);
                lbl.AutoSize = true;
                lbl.Margin = new Padding(0, 5, 0, 0);
                fLpOzellikler.Controls.Add(lbl);
            }

        }

        private void Btn_Click(object sender, EventArgs e)
        {
            Button tiklanan = sender as Button;
            Picture pic = tiklanan.Tag as Picture;
            pbMainPic.Image = Image.FromFile(pic.ResimPath);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            //frmMain frm = new frmMain();
            //this.Close();
            //frm.Show();

            this.Close();
        }
    }
}
