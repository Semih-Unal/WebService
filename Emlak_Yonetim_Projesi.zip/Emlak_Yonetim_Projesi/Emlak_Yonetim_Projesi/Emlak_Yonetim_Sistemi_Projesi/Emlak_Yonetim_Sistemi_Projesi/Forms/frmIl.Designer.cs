﻿namespace Emlak_Yonetim_Sistemi_Projesi.Forms
{
    partial class frmIl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.lblToplamIl = new System.Windows.Forms.Label();
            this.btnCityClear = new MetroFramework.Controls.MetroButton();
            this.btnCityDelete = new MetroFramework.Controls.MetroButton();
            this.btnCityUpdate = new MetroFramework.Controls.MetroButton();
            this.btnCityAdd = new MetroFramework.Controls.MetroButton();
            this.lstCities = new System.Windows.Forms.ListBox();
            this.txtCityName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.lblToplamIlce = new System.Windows.Forms.Label();
            this.btnCountryClear = new MetroFramework.Controls.MetroButton();
            this.cbCities = new MetroFramework.Controls.MetroComboBox();
            this.btnCountryDelete = new MetroFramework.Controls.MetroButton();
            this.btnCountryUpdate = new MetroFramework.Controls.MetroButton();
            this.btnCountryAdd = new MetroFramework.Controls.MetroButton();
            this.lstCountries = new System.Windows.Forms.ListBox();
            this.txtCountyName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage3 = new MetroFramework.Controls.MetroTabPage();
            this.lblToplamSemt = new System.Windows.Forms.Label();
            this.btnPartClear = new MetroFramework.Controls.MetroButton();
            this.cbCountries = new MetroFramework.Controls.MetroComboBox();
            this.btnPartDelete = new MetroFramework.Controls.MetroButton();
            this.btnPartUpdate = new MetroFramework.Controls.MetroButton();
            this.btnPartAdd = new MetroFramework.Controls.MetroButton();
            this.lstParts = new System.Windows.Forms.ListBox();
            this.txtPartName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroTabControl1.SuspendLayout();
            this.metroTabPage1.SuspendLayout();
            this.metroTabPage2.SuspendLayout();
            this.metroTabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Controls.Add(this.metroTabPage1);
            this.metroTabControl1.Controls.Add(this.metroTabPage2);
            this.metroTabControl1.Controls.Add(this.metroTabPage3);
            this.metroTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroTabControl1.Location = new System.Drawing.Point(0, 0);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 0;
            this.metroTabControl1.Size = new System.Drawing.Size(377, 459);
            this.metroTabControl1.TabIndex = 0;
            this.metroTabControl1.UseSelectable = true;
            this.metroTabControl1.SelectedIndexChanged += new System.EventHandler(this.metroTabControl1_SelectedIndexChanged);
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.Controls.Add(this.lblToplamIl);
            this.metroTabPage1.Controls.Add(this.btnCityClear);
            this.metroTabPage1.Controls.Add(this.btnCityDelete);
            this.metroTabPage1.Controls.Add(this.btnCityUpdate);
            this.metroTabPage1.Controls.Add(this.btnCityAdd);
            this.metroTabPage1.Controls.Add(this.lstCities);
            this.metroTabPage1.Controls.Add(this.txtCityName);
            this.metroTabPage1.Controls.Add(this.metroLabel1);
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.HorizontalScrollbarSize = 10;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(369, 417);
            this.metroTabPage1.TabIndex = 0;
            this.metroTabPage1.Text = "İl";
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            this.metroTabPage1.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.VerticalScrollbarSize = 10;
            // 
            // lblToplamIl
            // 
            this.lblToplamIl.AutoSize = true;
            this.lblToplamIl.BackColor = System.Drawing.Color.White;
            this.lblToplamIl.Location = new System.Drawing.Point(23, 377);
            this.lblToplamIl.Name = "lblToplamIl";
            this.lblToplamIl.Size = new System.Drawing.Size(13, 13);
            this.lblToplamIl.TabIndex = 24;
            this.lblToplamIl.Text = "0";
            // 
            // btnCityClear
            // 
            this.btnCityClear.Location = new System.Drawing.Point(86, 69);
            this.btnCityClear.Name = "btnCityClear";
            this.btnCityClear.Size = new System.Drawing.Size(51, 23);
            this.btnCityClear.TabIndex = 23;
            this.btnCityClear.Text = "Temizle";
            this.btnCityClear.UseSelectable = true;
            this.btnCityClear.Click += new System.EventHandler(this.btnCityClear_Click);
            // 
            // btnCityDelete
            // 
            this.btnCityDelete.Location = new System.Drawing.Point(290, 69);
            this.btnCityDelete.Name = "btnCityDelete";
            this.btnCityDelete.Size = new System.Drawing.Size(53, 23);
            this.btnCityDelete.TabIndex = 5;
            this.btnCityDelete.Text = "Sil";
            this.btnCityDelete.UseSelectable = true;
            this.btnCityDelete.Click += new System.EventHandler(this.btnCityDelete_Click);
            // 
            // btnCityUpdate
            // 
            this.btnCityUpdate.Location = new System.Drawing.Point(216, 69);
            this.btnCityUpdate.Name = "btnCityUpdate";
            this.btnCityUpdate.Size = new System.Drawing.Size(68, 23);
            this.btnCityUpdate.TabIndex = 5;
            this.btnCityUpdate.Text = "Güncelle";
            this.btnCityUpdate.UseSelectable = true;
            this.btnCityUpdate.Click += new System.EventHandler(this.btnCityUpdate_Click);
            // 
            // btnCityAdd
            // 
            this.btnCityAdd.Location = new System.Drawing.Point(144, 69);
            this.btnCityAdd.Name = "btnCityAdd";
            this.btnCityAdd.Size = new System.Drawing.Size(67, 23);
            this.btnCityAdd.TabIndex = 5;
            this.btnCityAdd.Text = "Ekle";
            this.btnCityAdd.UseSelectable = true;
            this.btnCityAdd.Click += new System.EventHandler(this.btnCityAdd_Click);
            // 
            // lstCities
            // 
            this.lstCities.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lstCities.FormattingEnabled = true;
            this.lstCities.ItemHeight = 16;
            this.lstCities.Location = new System.Drawing.Point(26, 98);
            this.lstCities.Name = "lstCities";
            this.lstCities.Size = new System.Drawing.Size(317, 276);
            this.lstCities.TabIndex = 4;
            this.lstCities.SelectedIndexChanged += new System.EventHandler(this.lstCities_SelectedIndexChanged);
            // 
            // txtCityName
            // 
            // 
            // 
            // 
            this.txtCityName.CustomButton.Image = null;
            this.txtCityName.CustomButton.Location = new System.Drawing.Point(235, 1);
            this.txtCityName.CustomButton.Name = "";
            this.txtCityName.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtCityName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCityName.CustomButton.TabIndex = 1;
            this.txtCityName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCityName.CustomButton.UseSelectable = true;
            this.txtCityName.CustomButton.Visible = false;
            this.txtCityName.Lines = new string[0];
            this.txtCityName.Location = new System.Drawing.Point(84, 20);
            this.txtCityName.MaxLength = 32767;
            this.txtCityName.Name = "txtCityName";
            this.txtCityName.PasswordChar = '\0';
            this.txtCityName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCityName.SelectedText = "";
            this.txtCityName.SelectionLength = 0;
            this.txtCityName.SelectionStart = 0;
            this.txtCityName.ShortcutsEnabled = true;
            this.txtCityName.Size = new System.Drawing.Size(259, 25);
            this.txtCityName.TabIndex = 3;
            this.txtCityName.UseSelectable = true;
            this.txtCityName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCityName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.Location = new System.Drawing.Point(26, 24);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(52, 19);
            this.metroLabel1.TabIndex = 2;
            this.metroLabel1.Text = "İl Adı :";
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.lblToplamIlce);
            this.metroTabPage2.Controls.Add(this.btnCountryClear);
            this.metroTabPage2.Controls.Add(this.cbCities);
            this.metroTabPage2.Controls.Add(this.btnCountryDelete);
            this.metroTabPage2.Controls.Add(this.btnCountryUpdate);
            this.metroTabPage2.Controls.Add(this.btnCountryAdd);
            this.metroTabPage2.Controls.Add(this.lstCountries);
            this.metroTabPage2.Controls.Add(this.txtCountyName);
            this.metroTabPage2.Controls.Add(this.metroLabel3);
            this.metroTabPage2.Controls.Add(this.metroLabel2);
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.HorizontalScrollbarSize = 10;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(369, 417);
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "İlçe";
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.VerticalScrollbarSize = 10;
            // 
            // lblToplamIlce
            // 
            this.lblToplamIlce.AutoSize = true;
            this.lblToplamIlce.BackColor = System.Drawing.Color.White;
            this.lblToplamIlce.Location = new System.Drawing.Point(24, 399);
            this.lblToplamIlce.Name = "lblToplamIlce";
            this.lblToplamIlce.Size = new System.Drawing.Size(13, 13);
            this.lblToplamIlce.TabIndex = 25;
            this.lblToplamIlce.Text = "0";
            // 
            // btnCountryClear
            // 
            this.btnCountryClear.Location = new System.Drawing.Point(67, 110);
            this.btnCountryClear.Name = "btnCountryClear";
            this.btnCountryClear.Size = new System.Drawing.Size(57, 23);
            this.btnCountryClear.TabIndex = 22;
            this.btnCountryClear.Text = "Temizle";
            this.btnCountryClear.UseSelectable = true;
            this.btnCountryClear.Click += new System.EventHandler(this.btnCountryClear_Click);
            // 
            // cbCities
            // 
            this.cbCities.FormattingEnabled = true;
            this.cbCities.ItemHeight = 23;
            this.cbCities.Location = new System.Drawing.Point(100, 21);
            this.cbCities.Name = "cbCities";
            this.cbCities.Size = new System.Drawing.Size(231, 29);
            this.cbCities.TabIndex = 12;
            this.cbCities.UseSelectable = true;
            this.cbCities.SelectionChangeCommitted += new System.EventHandler(this.cbCities_SelectionChangeCommitted);
            // 
            // btnCountryDelete
            // 
            this.btnCountryDelete.Location = new System.Drawing.Point(277, 110);
            this.btnCountryDelete.Name = "btnCountryDelete";
            this.btnCountryDelete.Size = new System.Drawing.Size(54, 23);
            this.btnCountryDelete.TabIndex = 9;
            this.btnCountryDelete.Text = "Sil";
            this.btnCountryDelete.UseSelectable = true;
            this.btnCountryDelete.Click += new System.EventHandler(this.btnCountryDelete_Click);
            // 
            // btnCountryUpdate
            // 
            this.btnCountryUpdate.Location = new System.Drawing.Point(203, 110);
            this.btnCountryUpdate.Name = "btnCountryUpdate";
            this.btnCountryUpdate.Size = new System.Drawing.Size(68, 23);
            this.btnCountryUpdate.TabIndex = 10;
            this.btnCountryUpdate.Text = "Güncelle";
            this.btnCountryUpdate.UseSelectable = true;
            this.btnCountryUpdate.Click += new System.EventHandler(this.btnCountryUpdate_Click);
            // 
            // btnCountryAdd
            // 
            this.btnCountryAdd.Location = new System.Drawing.Point(130, 110);
            this.btnCountryAdd.Name = "btnCountryAdd";
            this.btnCountryAdd.Size = new System.Drawing.Size(67, 23);
            this.btnCountryAdd.TabIndex = 11;
            this.btnCountryAdd.Text = "Ekle";
            this.btnCountryAdd.UseSelectable = true;
            this.btnCountryAdd.Click += new System.EventHandler(this.btnCountryAdd_Click);
            // 
            // lstCountries
            // 
            this.lstCountries.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lstCountries.FormattingEnabled = true;
            this.lstCountries.ItemHeight = 16;
            this.lstCountries.Location = new System.Drawing.Point(27, 142);
            this.lstCountries.MultiColumn = true;
            this.lstCountries.Name = "lstCountries";
            this.lstCountries.Size = new System.Drawing.Size(304, 244);
            this.lstCountries.TabIndex = 8;
            this.lstCountries.SelectedIndexChanged += new System.EventHandler(this.lstCountries_SelectedIndexChanged);
            // 
            // txtCountyName
            // 
            // 
            // 
            // 
            this.txtCountyName.CustomButton.Image = null;
            this.txtCountyName.CustomButton.Location = new System.Drawing.Point(207, 1);
            this.txtCountyName.CustomButton.Name = "";
            this.txtCountyName.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtCountyName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtCountyName.CustomButton.TabIndex = 1;
            this.txtCountyName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtCountyName.CustomButton.UseSelectable = true;
            this.txtCountyName.CustomButton.Visible = false;
            this.txtCountyName.Lines = new string[0];
            this.txtCountyName.Location = new System.Drawing.Point(100, 63);
            this.txtCountyName.MaxLength = 32767;
            this.txtCountyName.Name = "txtCountyName";
            this.txtCountyName.PasswordChar = '\0';
            this.txtCountyName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCountyName.SelectedText = "";
            this.txtCountyName.SelectionLength = 0;
            this.txtCountyName.SelectionStart = 0;
            this.txtCountyName.ShortcutsEnabled = true;
            this.txtCountyName.Size = new System.Drawing.Size(231, 25);
            this.txtCountyName.TabIndex = 7;
            this.txtCountyName.UseSelectable = true;
            this.txtCountyName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtCountyName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.Location = new System.Drawing.Point(27, 67);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(67, 19);
            this.metroLabel3.TabIndex = 6;
            this.metroLabel3.Text = "İlçe Adı :";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.Location = new System.Drawing.Point(27, 24);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(52, 19);
            this.metroLabel2.TabIndex = 6;
            this.metroLabel2.Text = "İl Adı :";
            // 
            // metroTabPage3
            // 
            this.metroTabPage3.Controls.Add(this.lblToplamSemt);
            this.metroTabPage3.Controls.Add(this.btnPartClear);
            this.metroTabPage3.Controls.Add(this.cbCountries);
            this.metroTabPage3.Controls.Add(this.btnPartDelete);
            this.metroTabPage3.Controls.Add(this.btnPartUpdate);
            this.metroTabPage3.Controls.Add(this.btnPartAdd);
            this.metroTabPage3.Controls.Add(this.lstParts);
            this.metroTabPage3.Controls.Add(this.txtPartName);
            this.metroTabPage3.Controls.Add(this.metroLabel4);
            this.metroTabPage3.Controls.Add(this.metroLabel5);
            this.metroTabPage3.HorizontalScrollbarBarColor = true;
            this.metroTabPage3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.HorizontalScrollbarSize = 10;
            this.metroTabPage3.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage3.Name = "metroTabPage3";
            this.metroTabPage3.Size = new System.Drawing.Size(369, 417);
            this.metroTabPage3.TabIndex = 2;
            this.metroTabPage3.Text = "Semt";
            this.metroTabPage3.VerticalScrollbarBarColor = true;
            this.metroTabPage3.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.VerticalScrollbarSize = 10;
            // 
            // lblToplamSemt
            // 
            this.lblToplamSemt.AutoSize = true;
            this.lblToplamSemt.BackColor = System.Drawing.Color.White;
            this.lblToplamSemt.Location = new System.Drawing.Point(27, 399);
            this.lblToplamSemt.Name = "lblToplamSemt";
            this.lblToplamSemt.Size = new System.Drawing.Size(13, 13);
            this.lblToplamSemt.TabIndex = 26;
            this.lblToplamSemt.Text = "0";
            // 
            // btnPartClear
            // 
            this.btnPartClear.Location = new System.Drawing.Point(72, 110);
            this.btnPartClear.Name = "btnPartClear";
            this.btnPartClear.Size = new System.Drawing.Size(54, 23);
            this.btnPartClear.TabIndex = 21;
            this.btnPartClear.Text = "Temizle";
            this.btnPartClear.UseSelectable = true;
            this.btnPartClear.Click += new System.EventHandler(this.btnPartClear_Click);
            // 
            // cbCountries
            // 
            this.cbCountries.FormattingEnabled = true;
            this.cbCountries.ItemHeight = 23;
            this.cbCountries.Location = new System.Drawing.Point(114, 21);
            this.cbCountries.Name = "cbCountries";
            this.cbCountries.Size = new System.Drawing.Size(216, 29);
            this.cbCountries.TabIndex = 20;
            this.cbCountries.UseSelectable = true;
            this.cbCountries.SelectionChangeCommitted += new System.EventHandler(this.cbCountries_SelectionChangeCommitted);
            // 
            // btnPartDelete
            // 
            this.btnPartDelete.Location = new System.Drawing.Point(279, 110);
            this.btnPartDelete.Name = "btnPartDelete";
            this.btnPartDelete.Size = new System.Drawing.Size(51, 23);
            this.btnPartDelete.TabIndex = 17;
            this.btnPartDelete.Text = "Sil";
            this.btnPartDelete.UseSelectable = true;
            this.btnPartDelete.Click += new System.EventHandler(this.btnPartDelete_Click);
            // 
            // btnPartUpdate
            // 
            this.btnPartUpdate.Location = new System.Drawing.Point(205, 110);
            this.btnPartUpdate.Name = "btnPartUpdate";
            this.btnPartUpdate.Size = new System.Drawing.Size(68, 23);
            this.btnPartUpdate.TabIndex = 18;
            this.btnPartUpdate.Text = "Güncelle";
            this.btnPartUpdate.UseSelectable = true;
            this.btnPartUpdate.Click += new System.EventHandler(this.btnPartUpdate_Click);
            // 
            // btnPartAdd
            // 
            this.btnPartAdd.Location = new System.Drawing.Point(132, 110);
            this.btnPartAdd.Name = "btnPartAdd";
            this.btnPartAdd.Size = new System.Drawing.Size(67, 23);
            this.btnPartAdd.TabIndex = 19;
            this.btnPartAdd.Text = "Ekle";
            this.btnPartAdd.UseSelectable = true;
            this.btnPartAdd.Click += new System.EventHandler(this.btnPartAdd_Click);
            // 
            // lstParts
            // 
            this.lstParts.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lstParts.FormattingEnabled = true;
            this.lstParts.ItemHeight = 16;
            this.lstParts.Location = new System.Drawing.Point(30, 142);
            this.lstParts.MultiColumn = true;
            this.lstParts.Name = "lstParts";
            this.lstParts.Size = new System.Drawing.Size(300, 244);
            this.lstParts.TabIndex = 16;
            this.lstParts.SelectedIndexChanged += new System.EventHandler(this.lstParts_SelectedIndexChanged);
            // 
            // txtPartName
            // 
            // 
            // 
            // 
            this.txtPartName.CustomButton.Image = null;
            this.txtPartName.CustomButton.Location = new System.Drawing.Point(192, 1);
            this.txtPartName.CustomButton.Name = "";
            this.txtPartName.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtPartName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtPartName.CustomButton.TabIndex = 1;
            this.txtPartName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtPartName.CustomButton.UseSelectable = true;
            this.txtPartName.CustomButton.Visible = false;
            this.txtPartName.Lines = new string[0];
            this.txtPartName.Location = new System.Drawing.Point(114, 63);
            this.txtPartName.MaxLength = 32767;
            this.txtPartName.Name = "txtPartName";
            this.txtPartName.PasswordChar = '\0';
            this.txtPartName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtPartName.SelectedText = "";
            this.txtPartName.SelectionLength = 0;
            this.txtPartName.SelectionStart = 0;
            this.txtPartName.ShortcutsEnabled = true;
            this.txtPartName.Size = new System.Drawing.Size(216, 25);
            this.txtPartName.TabIndex = 15;
            this.txtPartName.UseSelectable = true;
            this.txtPartName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtPartName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel4.Location = new System.Drawing.Point(30, 67);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(78, 19);
            this.metroLabel4.TabIndex = 13;
            this.metroLabel4.Text = "Semt Adı :";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel5.Location = new System.Drawing.Point(30, 24);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(67, 19);
            this.metroLabel5.TabIndex = 14;
            this.metroLabel5.Text = "İlçe Adı :";
            // 
            // frmIl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(377, 459);
            this.Controls.Add(this.metroTabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmIl";
            this.Text = "İl İşlemleri";
            this.Load += new System.EventHandler(this.frmIl_Load);
            this.metroTabControl1.ResumeLayout(false);
            this.metroTabPage1.ResumeLayout(false);
            this.metroTabPage1.PerformLayout();
            this.metroTabPage2.ResumeLayout(false);
            this.metroTabPage2.PerformLayout();
            this.metroTabPage3.ResumeLayout(false);
            this.metroTabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroTabPage metroTabPage1;
        private MetroFramework.Controls.MetroButton btnCityAdd;
        private System.Windows.Forms.ListBox lstCities;
        private MetroFramework.Controls.MetroTextBox txtCityName;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private System.Windows.Forms.ListBox lstCountries;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroButton btnCityDelete;
        private MetroFramework.Controls.MetroButton btnCityUpdate;
        private MetroFramework.Controls.MetroComboBox cbCities;
        private MetroFramework.Controls.MetroButton btnCountryDelete;
        private MetroFramework.Controls.MetroButton btnCountryUpdate;
        private MetroFramework.Controls.MetroButton btnCountryAdd;
        private MetroFramework.Controls.MetroTextBox txtCountyName;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTabPage metroTabPage3;
        private MetroFramework.Controls.MetroComboBox cbCountries;
        private MetroFramework.Controls.MetroButton btnPartDelete;
        private MetroFramework.Controls.MetroButton btnPartUpdate;
        private MetroFramework.Controls.MetroButton btnPartAdd;
        private System.Windows.Forms.ListBox lstParts;
        private MetroFramework.Controls.MetroTextBox txtPartName;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroButton btnCityClear;
        private MetroFramework.Controls.MetroButton btnCountryClear;
        private MetroFramework.Controls.MetroButton btnPartClear;
        private System.Windows.Forms.Label lblToplamIl;
        private System.Windows.Forms.Label lblToplamIlce;
        private System.Windows.Forms.Label lblToplamSemt;
    }
}