﻿namespace Emlak_Yonetim_Sistemi_Projesi.Forms
{
    partial class frmIlan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblToplam = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.dGwIlanlar = new System.Windows.Forms.DataGridView();
            this.contextMenuStripIlan = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.önizlemeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.güncelleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.silToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtSearch = new MetroFramework.Controls.MetroTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.btnAdd = new MetroFramework.Controls.MetroButton();
            this.metroTabControl2 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage7 = new MetroFramework.Controls.MetroTabPage();
            this.lstAddEkOzellikler = new System.Windows.Forms.ListBox();
            this.btnAddEkOzellikSil = new MetroFramework.Controls.MetroButton();
            this.btnAddEkOzellikGuncelle = new MetroFramework.Controls.MetroButton();
            this.btnAddEkOzellikEkle = new MetroFramework.Controls.MetroButton();
            this.txtAddEkOzellikAciklama = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.txtAddEkOzellikName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage4 = new MetroFramework.Controls.MetroTabPage();
            this.lstAddDisOzellikler = new System.Windows.Forms.ListBox();
            this.btnAddDisSil = new MetroFramework.Controls.MetroButton();
            this.btnAddDisGüncelle = new MetroFramework.Controls.MetroButton();
            this.btnAddDisEkle = new MetroFramework.Controls.MetroButton();
            this.txtAddDisName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage5 = new MetroFramework.Controls.MetroTabPage();
            this.lstAddIcOzellikler = new System.Windows.Forms.ListBox();
            this.btnAddIcSil = new MetroFramework.Controls.MetroButton();
            this.btnAddIcGuncelle = new MetroFramework.Controls.MetroButton();
            this.btnAddIcEkle = new MetroFramework.Controls.MetroButton();
            this.txtAddIcName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage6 = new MetroFramework.Controls.MetroTabPage();
            this.lstAddKonumOzellikler = new System.Windows.Forms.ListBox();
            this.btnAddKonumSil = new MetroFramework.Controls.MetroButton();
            this.btnAddKonumGuncelle = new MetroFramework.Controls.MetroButton();
            this.btnAddKonumEkle = new MetroFramework.Controls.MetroButton();
            this.txtAddKonumName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage12 = new MetroFramework.Controls.MetroTabPage();
            this.btnAddResimSil = new MetroFramework.Controls.MetroButton();
            this.btnAddResimEkle = new MetroFramework.Controls.MetroButton();
            this.label30 = new System.Windows.Forms.Label();
            this.fLpAddResimler = new System.Windows.Forms.FlowLayoutPanel();
            this.label29 = new System.Windows.Forms.Label();
            this.txtAddIlanAciklama = new MetroFramework.Controls.MetroTextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.nUdAddIlanNet = new System.Windows.Forms.NumericUpDown();
            this.nUdAddIlanBrut = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dTpAddIlanTarihi = new MetroFramework.Controls.MetroDateTime();
            this.cbAddAltKategori = new MetroFramework.Controls.MetroComboBox();
            this.cbAddIlanVeren = new MetroFramework.Controls.MetroComboBox();
            this.cbAddSemtler = new MetroFramework.Controls.MetroComboBox();
            this.cbAddKategori = new MetroFramework.Controls.MetroComboBox();
            this.cbAddIlceler = new MetroFramework.Controls.MetroComboBox();
            this.cbAddIlanTuru = new MetroFramework.Controls.MetroComboBox();
            this.cbAddIller = new MetroFramework.Controls.MetroComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.txtAddIlanNo = new MetroFramework.Controls.MetroTextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtAddFiyat = new MetroFramework.Controls.MetroTextBox();
            this.txtAddTitle = new MetroFramework.Controls.MetroTextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblAdi = new System.Windows.Forms.Label();
            this.metroTabPage3 = new MetroFramework.Controls.MetroTabPage();
            this.txtUpdateFiyat = new MetroFramework.Controls.MetroTextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.cbUpdateIlanVeren = new MetroFramework.Controls.MetroComboBox();
            this.label35 = new System.Windows.Forms.Label();
            this.btnUpdate = new MetroFramework.Controls.MetroButton();
            this.metroTabControl3 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage8 = new MetroFramework.Controls.MetroTabPage();
            this.lstUpdateEkOzellikler = new System.Windows.Forms.ListBox();
            this.btnUpdateEkOzellikSil = new MetroFramework.Controls.MetroButton();
            this.btnUpdateEkOzellikGuncelle = new MetroFramework.Controls.MetroButton();
            this.btnUpdateEkOzellikEkle = new MetroFramework.Controls.MetroButton();
            this.txtUpdateEkOzellikAciklama = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.txtUpdateEkOzellikName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage9 = new MetroFramework.Controls.MetroTabPage();
            this.lstUpdateDisOzellikler = new System.Windows.Forms.ListBox();
            this.btnUpdateDisSil = new MetroFramework.Controls.MetroButton();
            this.btnUpdateDisGuncelle = new MetroFramework.Controls.MetroButton();
            this.btnUpdateDisEkle = new MetroFramework.Controls.MetroButton();
            this.txtUpdateDisName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel8 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage10 = new MetroFramework.Controls.MetroTabPage();
            this.lstUpdateIcOzellikler = new System.Windows.Forms.ListBox();
            this.btnUpdateIcSil = new MetroFramework.Controls.MetroButton();
            this.btnUpdateIcGuncelle = new MetroFramework.Controls.MetroButton();
            this.btnUpdateIcEkle = new MetroFramework.Controls.MetroButton();
            this.txtUpdateIcOzellikName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel9 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage11 = new MetroFramework.Controls.MetroTabPage();
            this.lstUpdateKonumOzellikler = new System.Windows.Forms.ListBox();
            this.btnUpdateKonumSil = new MetroFramework.Controls.MetroButton();
            this.btnUpdateKonumGuncelle = new MetroFramework.Controls.MetroButton();
            this.btnUpdateKonumEkle = new MetroFramework.Controls.MetroButton();
            this.txtUpdateKonumName = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel10 = new MetroFramework.Controls.MetroLabel();
            this.metroTabPage13 = new MetroFramework.Controls.MetroTabPage();
            this.brnUpdateResimCikar = new MetroFramework.Controls.MetroButton();
            this.btnUpdateResimEkle = new MetroFramework.Controls.MetroButton();
            this.label31 = new System.Windows.Forms.Label();
            this.fLpUpdateResimler = new System.Windows.Forms.FlowLayoutPanel();
            this.label32 = new System.Windows.Forms.Label();
            this.txtUpdateIlanAciklama = new MetroFramework.Controls.MetroTextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.nUdUpdateIlanNet = new System.Windows.Forms.NumericUpDown();
            this.nUdUpdateIlanBrut = new System.Windows.Forms.NumericUpDown();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.dTpUpdateIlanTarihi = new MetroFramework.Controls.MetroDateTime();
            this.cbUpdateIlanAltKategori = new MetroFramework.Controls.MetroComboBox();
            this.cbUpdateIlanSemt = new MetroFramework.Controls.MetroComboBox();
            this.cbUpdateIlanKategori = new MetroFramework.Controls.MetroComboBox();
            this.cbUpdateIlanIlceler = new MetroFramework.Controls.MetroComboBox();
            this.cbUpdateIlanTuru = new MetroFramework.Controls.MetroComboBox();
            this.cbUpdateIlanIller = new MetroFramework.Controls.MetroComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtUpdateIlanNo = new MetroFramework.Controls.MetroTextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.txtUpdateIlanTitle = new MetroFramework.Controls.MetroTextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.metroToolTip1 = new MetroFramework.Components.MetroToolTip();
            this.helpProvider1 = new System.Windows.Forms.HelpProvider();
            this.metroTabControl1.SuspendLayout();
            this.metroTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGwIlanlar)).BeginInit();
            this.contextMenuStripIlan.SuspendLayout();
            this.metroTabPage2.SuspendLayout();
            this.metroTabControl2.SuspendLayout();
            this.metroTabPage7.SuspendLayout();
            this.metroTabPage4.SuspendLayout();
            this.metroTabPage5.SuspendLayout();
            this.metroTabPage6.SuspendLayout();
            this.metroTabPage12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nUdAddIlanNet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nUdAddIlanBrut)).BeginInit();
            this.metroTabPage3.SuspendLayout();
            this.metroTabControl3.SuspendLayout();
            this.metroTabPage8.SuspendLayout();
            this.metroTabPage9.SuspendLayout();
            this.metroTabPage10.SuspendLayout();
            this.metroTabPage11.SuspendLayout();
            this.metroTabPage13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nUdUpdateIlanNet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nUdUpdateIlanBrut)).BeginInit();
            this.SuspendLayout();
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Controls.Add(this.metroTabPage1);
            this.metroTabControl1.Controls.Add(this.metroTabPage2);
            this.metroTabControl1.Controls.Add(this.metroTabPage3);
            this.metroTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroTabControl1.Location = new System.Drawing.Point(0, 0);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 1;
            this.metroTabControl1.Size = new System.Drawing.Size(687, 609);
            this.metroTabControl1.TabIndex = 1;
            this.metroTabControl1.UseSelectable = true;
            this.metroTabControl1.SelectedIndexChanged += new System.EventHandler(this.metroTabControl1_SelectedIndexChanged);
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.Controls.Add(this.pictureBox1);
            this.metroTabPage1.Controls.Add(this.lblToplam);
            this.metroTabPage1.Controls.Add(this.label33);
            this.metroTabPage1.Controls.Add(this.dGwIlanlar);
            this.metroTabPage1.Controls.Add(this.txtSearch);
            this.metroTabPage1.Controls.Add(this.label1);
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.HorizontalScrollbarSize = 10;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(679, 567);
            this.metroTabPage1.TabIndex = 0;
            this.metroTabPage1.Text = "İlanlar";
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            this.metroTabPage1.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.VerticalScrollbarSize = 10;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.helpProvider1.SetHelpKeyword(this.pictureBox1, "");
            this.helpProvider1.SetHelpString(this.pictureBox1, "Sağ tık ile güncelleme ve sil işlemlerini yapabilirsiniz.");
            this.pictureBox1.Image = global::Emlak_Yonetim_Sistemi_Projesi.Properties.Resources.help;
            this.pictureBox1.Location = new System.Drawing.Point(8, 24);
            this.pictureBox1.Name = "pictureBox1";
            this.helpProvider1.SetShowHelp(this.pictureBox1, true);
            this.pictureBox1.Size = new System.Drawing.Size(20, 20);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            this.metroToolTip1.SetToolTip(this.pictureBox1, "Sağ tık ile güncelleme ve sil işlemlerini yapabilirsiniz.");
            // 
            // lblToplam
            // 
            this.lblToplam.AutoSize = true;
            this.lblToplam.BackColor = System.Drawing.Color.White;
            this.lblToplam.Location = new System.Drawing.Point(614, 382);
            this.lblToplam.Name = "lblToplam";
            this.lblToplam.Size = new System.Drawing.Size(13, 13);
            this.lblToplam.TabIndex = 6;
            this.lblToplam.Text = "0";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(560, 382);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(54, 13);
            this.label33.TabIndex = 6;
            this.label33.Text = "Toplam = ";
            // 
            // dGwIlanlar
            // 
            this.dGwIlanlar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGwIlanlar.ContextMenuStrip = this.contextMenuStripIlan;
            this.dGwIlanlar.Location = new System.Drawing.Point(8, 50);
            this.dGwIlanlar.Name = "dGwIlanlar";
            this.dGwIlanlar.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dGwIlanlar.Size = new System.Drawing.Size(650, 329);
            this.dGwIlanlar.TabIndex = 5;
            this.dGwIlanlar.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGwIlanlar_CellClick);
            // 
            // contextMenuStripIlan
            // 
            this.contextMenuStripIlan.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.önizlemeToolStripMenuItem,
            this.toolStripSeparator1,
            this.güncelleToolStripMenuItem,
            this.silToolStripMenuItem});
            this.contextMenuStripIlan.Name = "contextMenuStripIlan";
            this.contextMenuStripIlan.Size = new System.Drawing.Size(125, 76);
            // 
            // önizlemeToolStripMenuItem
            // 
            this.önizlemeToolStripMenuItem.Image = global::Emlak_Yonetim_Sistemi_Projesi.Properties.Resources.preview;
            this.önizlemeToolStripMenuItem.Name = "önizlemeToolStripMenuItem";
            this.önizlemeToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.önizlemeToolStripMenuItem.Text = "Önizleme";
            this.önizlemeToolStripMenuItem.Click += new System.EventHandler(this.önizlemeToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(121, 6);
            // 
            // güncelleToolStripMenuItem
            // 
            this.güncelleToolStripMenuItem.Image = global::Emlak_Yonetim_Sistemi_Projesi.Properties.Resources.update;
            this.güncelleToolStripMenuItem.Name = "güncelleToolStripMenuItem";
            this.güncelleToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.güncelleToolStripMenuItem.Text = "Güncelle";
            this.güncelleToolStripMenuItem.Click += new System.EventHandler(this.güncelleToolStripMenuItem_Click);
            // 
            // silToolStripMenuItem
            // 
            this.silToolStripMenuItem.Image = global::Emlak_Yonetim_Sistemi_Projesi.Properties.Resources.trash1;
            this.silToolStripMenuItem.Name = "silToolStripMenuItem";
            this.silToolStripMenuItem.Size = new System.Drawing.Size(124, 22);
            this.silToolStripMenuItem.Text = "Sil";
            this.silToolStripMenuItem.Click += new System.EventHandler(this.silToolStripMenuItem_Click);
            // 
            // txtSearch
            // 
            // 
            // 
            // 
            this.txtSearch.CustomButton.Image = null;
            this.txtSearch.CustomButton.Location = new System.Drawing.Point(111, 1);
            this.txtSearch.CustomButton.Name = "";
            this.txtSearch.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtSearch.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtSearch.CustomButton.TabIndex = 1;
            this.txtSearch.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtSearch.CustomButton.UseSelectable = true;
            this.txtSearch.CustomButton.Visible = false;
            this.txtSearch.Lines = new string[0];
            this.txtSearch.Location = new System.Drawing.Point(525, 9);
            this.txtSearch.MaxLength = 32767;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.PasswordChar = '\0';
            this.txtSearch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSearch.SelectedText = "";
            this.txtSearch.SelectionLength = 0;
            this.txtSearch.SelectionStart = 0;
            this.txtSearch.ShortcutsEnabled = true;
            this.txtSearch.Size = new System.Drawing.Size(133, 23);
            this.txtSearch.TabIndex = 3;
            this.txtSearch.UseSelectable = true;
            this.txtSearch.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtSearch.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(481, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Ara :";
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.btnAdd);
            this.metroTabPage2.Controls.Add(this.metroTabControl2);
            this.metroTabPage2.Controls.Add(this.txtAddIlanAciklama);
            this.metroTabPage2.Controls.Add(this.label11);
            this.metroTabPage2.Controls.Add(this.nUdAddIlanNet);
            this.metroTabPage2.Controls.Add(this.nUdAddIlanBrut);
            this.metroTabPage2.Controls.Add(this.label7);
            this.metroTabPage2.Controls.Add(this.label10);
            this.metroTabPage2.Controls.Add(this.label9);
            this.metroTabPage2.Controls.Add(this.label8);
            this.metroTabPage2.Controls.Add(this.dTpAddIlanTarihi);
            this.metroTabPage2.Controls.Add(this.cbAddAltKategori);
            this.metroTabPage2.Controls.Add(this.cbAddIlanVeren);
            this.metroTabPage2.Controls.Add(this.cbAddSemtler);
            this.metroTabPage2.Controls.Add(this.cbAddKategori);
            this.metroTabPage2.Controls.Add(this.cbAddIlceler);
            this.metroTabPage2.Controls.Add(this.cbAddIlanTuru);
            this.metroTabPage2.Controls.Add(this.cbAddIller);
            this.metroTabPage2.Controls.Add(this.label14);
            this.metroTabPage2.Controls.Add(this.label34);
            this.metroTabPage2.Controls.Add(this.txtAddIlanNo);
            this.metroTabPage2.Controls.Add(this.label5);
            this.metroTabPage2.Controls.Add(this.label6);
            this.metroTabPage2.Controls.Add(this.label13);
            this.metroTabPage2.Controls.Add(this.label2);
            this.metroTabPage2.Controls.Add(this.label4);
            this.metroTabPage2.Controls.Add(this.label12);
            this.metroTabPage2.Controls.Add(this.txtAddFiyat);
            this.metroTabPage2.Controls.Add(this.txtAddTitle);
            this.metroTabPage2.Controls.Add(this.label36);
            this.metroTabPage2.Controls.Add(this.label3);
            this.metroTabPage2.Controls.Add(this.lblAdi);
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.HorizontalScrollbarSize = 10;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(679, 567);
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "İlan Ekle";
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.VerticalScrollbarSize = 10;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(201, 525);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(281, 37);
            this.btnAdd.TabIndex = 43;
            this.btnAdd.Text = "EKLE";
            this.btnAdd.UseSelectable = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // metroTabControl2
            // 
            this.metroTabControl2.AllowDrop = true;
            this.metroTabControl2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroTabControl2.Controls.Add(this.metroTabPage7);
            this.metroTabControl2.Controls.Add(this.metroTabPage4);
            this.metroTabControl2.Controls.Add(this.metroTabPage5);
            this.metroTabControl2.Controls.Add(this.metroTabPage6);
            this.metroTabControl2.Controls.Add(this.metroTabPage12);
            this.metroTabControl2.Location = new System.Drawing.Point(31, 277);
            this.metroTabControl2.Name = "metroTabControl2";
            this.metroTabControl2.SelectedIndex = 4;
            this.metroTabControl2.Size = new System.Drawing.Size(626, 242);
            this.metroTabControl2.TabIndex = 42;
            this.metroTabControl2.UseSelectable = true;
            this.metroTabControl2.SelectedIndexChanged += new System.EventHandler(this.metroTabControl2_SelectedIndexChanged);
            // 
            // metroTabPage7
            // 
            this.metroTabPage7.Controls.Add(this.lstAddEkOzellikler);
            this.metroTabPage7.Controls.Add(this.btnAddEkOzellikSil);
            this.metroTabPage7.Controls.Add(this.btnAddEkOzellikGuncelle);
            this.metroTabPage7.Controls.Add(this.btnAddEkOzellikEkle);
            this.metroTabPage7.Controls.Add(this.txtAddEkOzellikAciklama);
            this.metroTabPage7.Controls.Add(this.metroLabel5);
            this.metroTabPage7.Controls.Add(this.txtAddEkOzellikName);
            this.metroTabPage7.Controls.Add(this.metroLabel3);
            this.metroTabPage7.HorizontalScrollbarBarColor = true;
            this.metroTabPage7.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage7.HorizontalScrollbarSize = 10;
            this.metroTabPage7.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage7.Name = "metroTabPage7";
            this.metroTabPage7.Size = new System.Drawing.Size(618, 200);
            this.metroTabPage7.TabIndex = 3;
            this.metroTabPage7.Text = "Ek Özellikler";
            this.metroTabPage7.VerticalScrollbarBarColor = true;
            this.metroTabPage7.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage7.VerticalScrollbarSize = 10;
            // 
            // lstAddEkOzellikler
            // 
            this.lstAddEkOzellikler.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lstAddEkOzellikler.FormattingEnabled = true;
            this.lstAddEkOzellikler.ItemHeight = 16;
            this.lstAddEkOzellikler.Location = new System.Drawing.Point(293, 16);
            this.lstAddEkOzellikler.MultiColumn = true;
            this.lstAddEkOzellikler.Name = "lstAddEkOzellikler";
            this.lstAddEkOzellikler.Size = new System.Drawing.Size(242, 164);
            this.lstAddEkOzellikler.TabIndex = 69;
            this.lstAddEkOzellikler.SelectedIndexChanged += new System.EventHandler(this.lstAddEkOzellikler_SelectedIndexChanged);
            // 
            // btnAddEkOzellikSil
            // 
            this.btnAddEkOzellikSil.Location = new System.Drawing.Point(198, 82);
            this.btnAddEkOzellikSil.Name = "btnAddEkOzellikSil";
            this.btnAddEkOzellikSil.Size = new System.Drawing.Size(68, 23);
            this.btnAddEkOzellikSil.TabIndex = 66;
            this.btnAddEkOzellikSil.Text = "Çıkar";
            this.btnAddEkOzellikSil.UseSelectable = true;
            this.btnAddEkOzellikSil.Click += new System.EventHandler(this.btnAddEkOzellikSil_Click);
            // 
            // btnAddEkOzellikGuncelle
            // 
            this.btnAddEkOzellikGuncelle.Location = new System.Drawing.Point(124, 82);
            this.btnAddEkOzellikGuncelle.Name = "btnAddEkOzellikGuncelle";
            this.btnAddEkOzellikGuncelle.Size = new System.Drawing.Size(68, 23);
            this.btnAddEkOzellikGuncelle.TabIndex = 67;
            this.btnAddEkOzellikGuncelle.Text = "Güncelle";
            this.btnAddEkOzellikGuncelle.UseSelectable = true;
            this.btnAddEkOzellikGuncelle.Click += new System.EventHandler(this.btnAddEkOzellikGuncelle_Click);
            // 
            // btnAddEkOzellikEkle
            // 
            this.btnAddEkOzellikEkle.Location = new System.Drawing.Point(51, 82);
            this.btnAddEkOzellikEkle.Name = "btnAddEkOzellikEkle";
            this.btnAddEkOzellikEkle.Size = new System.Drawing.Size(67, 23);
            this.btnAddEkOzellikEkle.TabIndex = 68;
            this.btnAddEkOzellikEkle.Text = "Ekle";
            this.btnAddEkOzellikEkle.UseSelectable = true;
            this.btnAddEkOzellikEkle.Click += new System.EventHandler(this.btnAddEkOzellikEkle_Click);
            // 
            // txtAddEkOzellikAciklama
            // 
            // 
            // 
            // 
            this.txtAddEkOzellikAciklama.CustomButton.Image = null;
            this.txtAddEkOzellikAciklama.CustomButton.Location = new System.Drawing.Point(122, 1);
            this.txtAddEkOzellikAciklama.CustomButton.Name = "";
            this.txtAddEkOzellikAciklama.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtAddEkOzellikAciklama.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtAddEkOzellikAciklama.CustomButton.TabIndex = 1;
            this.txtAddEkOzellikAciklama.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtAddEkOzellikAciklama.CustomButton.UseSelectable = true;
            this.txtAddEkOzellikAciklama.CustomButton.Visible = false;
            this.txtAddEkOzellikAciklama.Lines = new string[0];
            this.txtAddEkOzellikAciklama.Location = new System.Drawing.Point(120, 51);
            this.txtAddEkOzellikAciklama.MaxLength = 32767;
            this.txtAddEkOzellikAciklama.Name = "txtAddEkOzellikAciklama";
            this.txtAddEkOzellikAciklama.PasswordChar = '\0';
            this.txtAddEkOzellikAciklama.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAddEkOzellikAciklama.SelectedText = "";
            this.txtAddEkOzellikAciklama.SelectionLength = 0;
            this.txtAddEkOzellikAciklama.SelectionStart = 0;
            this.txtAddEkOzellikAciklama.ShortcutsEnabled = true;
            this.txtAddEkOzellikAciklama.Size = new System.Drawing.Size(146, 25);
            this.txtAddEkOzellikAciklama.TabIndex = 65;
            this.txtAddEkOzellikAciklama.UseSelectable = true;
            this.txtAddEkOzellikAciklama.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtAddEkOzellikAciklama.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel5.Location = new System.Drawing.Point(15, 51);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(79, 19);
            this.metroLabel5.TabIndex = 64;
            this.metroLabel5.Text = "Açıklama :";
            // 
            // txtAddEkOzellikName
            // 
            // 
            // 
            // 
            this.txtAddEkOzellikName.CustomButton.Image = null;
            this.txtAddEkOzellikName.CustomButton.Location = new System.Drawing.Point(122, 1);
            this.txtAddEkOzellikName.CustomButton.Name = "";
            this.txtAddEkOzellikName.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtAddEkOzellikName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtAddEkOzellikName.CustomButton.TabIndex = 1;
            this.txtAddEkOzellikName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtAddEkOzellikName.CustomButton.UseSelectable = true;
            this.txtAddEkOzellikName.CustomButton.Visible = false;
            this.txtAddEkOzellikName.Lines = new string[0];
            this.txtAddEkOzellikName.Location = new System.Drawing.Point(120, 20);
            this.txtAddEkOzellikName.MaxLength = 32767;
            this.txtAddEkOzellikName.Name = "txtAddEkOzellikName";
            this.txtAddEkOzellikName.PasswordChar = '\0';
            this.txtAddEkOzellikName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAddEkOzellikName.SelectedText = "";
            this.txtAddEkOzellikName.SelectionLength = 0;
            this.txtAddEkOzellikName.SelectionStart = 0;
            this.txtAddEkOzellikName.ShortcutsEnabled = true;
            this.txtAddEkOzellikName.Size = new System.Drawing.Size(146, 25);
            this.txtAddEkOzellikName.TabIndex = 65;
            this.txtAddEkOzellikName.UseSelectable = true;
            this.txtAddEkOzellikName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtAddEkOzellikName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.Location = new System.Drawing.Point(15, 20);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(40, 19);
            this.metroLabel3.TabIndex = 64;
            this.metroLabel3.Text = "Adı :";
            // 
            // metroTabPage4
            // 
            this.metroTabPage4.Controls.Add(this.lstAddDisOzellikler);
            this.metroTabPage4.Controls.Add(this.btnAddDisSil);
            this.metroTabPage4.Controls.Add(this.btnAddDisGüncelle);
            this.metroTabPage4.Controls.Add(this.btnAddDisEkle);
            this.metroTabPage4.Controls.Add(this.txtAddDisName);
            this.metroTabPage4.Controls.Add(this.metroLabel4);
            this.metroTabPage4.HorizontalScrollbarBarColor = true;
            this.metroTabPage4.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage4.HorizontalScrollbarSize = 10;
            this.metroTabPage4.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage4.Name = "metroTabPage4";
            this.metroTabPage4.Size = new System.Drawing.Size(618, 200);
            this.metroTabPage4.TabIndex = 0;
            this.metroTabPage4.Text = "Dış Özellikler";
            this.metroTabPage4.VerticalScrollbarBarColor = true;
            this.metroTabPage4.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage4.VerticalScrollbarSize = 10;
            // 
            // lstAddDisOzellikler
            // 
            this.lstAddDisOzellikler.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lstAddDisOzellikler.FormattingEnabled = true;
            this.lstAddDisOzellikler.ItemHeight = 16;
            this.lstAddDisOzellikler.Location = new System.Drawing.Point(245, 16);
            this.lstAddDisOzellikler.MultiColumn = true;
            this.lstAddDisOzellikler.Name = "lstAddDisOzellikler";
            this.lstAddDisOzellikler.Size = new System.Drawing.Size(143, 164);
            this.lstAddDisOzellikler.TabIndex = 83;
            this.lstAddDisOzellikler.SelectedIndexChanged += new System.EventHandler(this.lstAddDisOzellikler_SelectedIndexChanged);
            // 
            // btnAddDisSil
            // 
            this.btnAddDisSil.Location = new System.Drawing.Point(162, 58);
            this.btnAddDisSil.Name = "btnAddDisSil";
            this.btnAddDisSil.Size = new System.Drawing.Size(68, 23);
            this.btnAddDisSil.TabIndex = 80;
            this.btnAddDisSil.Text = "Çıkar";
            this.btnAddDisSil.UseSelectable = true;
            this.btnAddDisSil.Click += new System.EventHandler(this.btnAddDisSil_Click);
            // 
            // btnAddDisGüncelle
            // 
            this.btnAddDisGüncelle.Location = new System.Drawing.Point(88, 58);
            this.btnAddDisGüncelle.Name = "btnAddDisGüncelle";
            this.btnAddDisGüncelle.Size = new System.Drawing.Size(68, 23);
            this.btnAddDisGüncelle.TabIndex = 81;
            this.btnAddDisGüncelle.Text = "Güncelle";
            this.btnAddDisGüncelle.UseSelectable = true;
            this.btnAddDisGüncelle.Click += new System.EventHandler(this.btnAddDisGüncelle_Click);
            // 
            // btnAddDisEkle
            // 
            this.btnAddDisEkle.Location = new System.Drawing.Point(15, 58);
            this.btnAddDisEkle.Name = "btnAddDisEkle";
            this.btnAddDisEkle.Size = new System.Drawing.Size(67, 23);
            this.btnAddDisEkle.TabIndex = 82;
            this.btnAddDisEkle.Text = "Ekle";
            this.btnAddDisEkle.UseSelectable = true;
            this.btnAddDisEkle.Click += new System.EventHandler(this.btnAddDisEkle_Click);
            // 
            // txtAddDisName
            // 
            // 
            // 
            // 
            this.txtAddDisName.CustomButton.Image = null;
            this.txtAddDisName.CustomButton.Location = new System.Drawing.Point(110, 1);
            this.txtAddDisName.CustomButton.Name = "";
            this.txtAddDisName.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtAddDisName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtAddDisName.CustomButton.TabIndex = 1;
            this.txtAddDisName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtAddDisName.CustomButton.UseSelectable = true;
            this.txtAddDisName.CustomButton.Visible = false;
            this.txtAddDisName.Lines = new string[0];
            this.txtAddDisName.Location = new System.Drawing.Point(96, 16);
            this.txtAddDisName.MaxLength = 32767;
            this.txtAddDisName.Name = "txtAddDisName";
            this.txtAddDisName.PasswordChar = '\0';
            this.txtAddDisName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAddDisName.SelectedText = "";
            this.txtAddDisName.SelectionLength = 0;
            this.txtAddDisName.SelectionStart = 0;
            this.txtAddDisName.ShortcutsEnabled = true;
            this.txtAddDisName.Size = new System.Drawing.Size(134, 25);
            this.txtAddDisName.TabIndex = 79;
            this.txtAddDisName.UseSelectable = true;
            this.txtAddDisName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtAddDisName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel4.Location = new System.Drawing.Point(3, 22);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(87, 19);
            this.metroLabel4.TabIndex = 78;
            this.metroLabel4.Text = "Dış Özellik :";
            // 
            // metroTabPage5
            // 
            this.metroTabPage5.Controls.Add(this.lstAddIcOzellikler);
            this.metroTabPage5.Controls.Add(this.btnAddIcSil);
            this.metroTabPage5.Controls.Add(this.btnAddIcGuncelle);
            this.metroTabPage5.Controls.Add(this.btnAddIcEkle);
            this.metroTabPage5.Controls.Add(this.txtAddIcName);
            this.metroTabPage5.Controls.Add(this.metroLabel1);
            this.metroTabPage5.HorizontalScrollbarBarColor = true;
            this.metroTabPage5.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage5.HorizontalScrollbarSize = 10;
            this.metroTabPage5.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage5.Name = "metroTabPage5";
            this.metroTabPage5.Size = new System.Drawing.Size(618, 200);
            this.metroTabPage5.TabIndex = 1;
            this.metroTabPage5.Text = "İç Özellikler";
            this.metroTabPage5.VerticalScrollbarBarColor = true;
            this.metroTabPage5.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage5.VerticalScrollbarSize = 10;
            // 
            // lstAddIcOzellikler
            // 
            this.lstAddIcOzellikler.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lstAddIcOzellikler.FormattingEnabled = true;
            this.lstAddIcOzellikler.ItemHeight = 16;
            this.lstAddIcOzellikler.Location = new System.Drawing.Point(259, 12);
            this.lstAddIcOzellikler.MultiColumn = true;
            this.lstAddIcOzellikler.Name = "lstAddIcOzellikler";
            this.lstAddIcOzellikler.Size = new System.Drawing.Size(148, 164);
            this.lstAddIcOzellikler.TabIndex = 85;
            this.lstAddIcOzellikler.SelectedIndexChanged += new System.EventHandler(this.lstAddIcOzellikler_SelectedIndexChanged);
            // 
            // btnAddIcSil
            // 
            this.btnAddIcSil.Location = new System.Drawing.Point(175, 54);
            this.btnAddIcSil.Name = "btnAddIcSil";
            this.btnAddIcSil.Size = new System.Drawing.Size(68, 23);
            this.btnAddIcSil.TabIndex = 82;
            this.btnAddIcSil.Text = "Sil";
            this.btnAddIcSil.UseSelectable = true;
            this.btnAddIcSil.Click += new System.EventHandler(this.btnAddIcSil_Click);
            // 
            // btnAddIcGuncelle
            // 
            this.btnAddIcGuncelle.Location = new System.Drawing.Point(97, 54);
            this.btnAddIcGuncelle.Name = "btnAddIcGuncelle";
            this.btnAddIcGuncelle.Size = new System.Drawing.Size(68, 23);
            this.btnAddIcGuncelle.TabIndex = 83;
            this.btnAddIcGuncelle.Text = "Güncelle";
            this.btnAddIcGuncelle.UseSelectable = true;
            this.btnAddIcGuncelle.Click += new System.EventHandler(this.btnAddIcGuncelle_Click);
            // 
            // btnAddIcEkle
            // 
            this.btnAddIcEkle.Location = new System.Drawing.Point(20, 54);
            this.btnAddIcEkle.Name = "btnAddIcEkle";
            this.btnAddIcEkle.Size = new System.Drawing.Size(67, 23);
            this.btnAddIcEkle.TabIndex = 84;
            this.btnAddIcEkle.Text = "Ekle";
            this.btnAddIcEkle.UseSelectable = true;
            this.btnAddIcEkle.Click += new System.EventHandler(this.btnAddIcEkle_Click);
            // 
            // txtAddIcName
            // 
            // 
            // 
            // 
            this.txtAddIcName.CustomButton.Image = null;
            this.txtAddIcName.CustomButton.Location = new System.Drawing.Point(131, 1);
            this.txtAddIcName.CustomButton.Name = "";
            this.txtAddIcName.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtAddIcName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtAddIcName.CustomButton.TabIndex = 1;
            this.txtAddIcName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtAddIcName.CustomButton.UseSelectable = true;
            this.txtAddIcName.CustomButton.Visible = false;
            this.txtAddIcName.Lines = new string[0];
            this.txtAddIcName.Location = new System.Drawing.Point(88, 12);
            this.txtAddIcName.MaxLength = 32767;
            this.txtAddIcName.Name = "txtAddIcName";
            this.txtAddIcName.PasswordChar = '\0';
            this.txtAddIcName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAddIcName.SelectedText = "";
            this.txtAddIcName.SelectionLength = 0;
            this.txtAddIcName.SelectionStart = 0;
            this.txtAddIcName.ShortcutsEnabled = true;
            this.txtAddIcName.Size = new System.Drawing.Size(155, 25);
            this.txtAddIcName.TabIndex = 79;
            this.txtAddIcName.UseSelectable = true;
            this.txtAddIcName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtAddIcName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.Location = new System.Drawing.Point(4, 18);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(78, 19);
            this.metroLabel1.TabIndex = 78;
            this.metroLabel1.Text = "İç Özellik :";
            // 
            // metroTabPage6
            // 
            this.metroTabPage6.Controls.Add(this.lstAddKonumOzellikler);
            this.metroTabPage6.Controls.Add(this.btnAddKonumSil);
            this.metroTabPage6.Controls.Add(this.btnAddKonumGuncelle);
            this.metroTabPage6.Controls.Add(this.btnAddKonumEkle);
            this.metroTabPage6.Controls.Add(this.txtAddKonumName);
            this.metroTabPage6.Controls.Add(this.metroLabel2);
            this.metroTabPage6.HorizontalScrollbarBarColor = true;
            this.metroTabPage6.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage6.HorizontalScrollbarSize = 10;
            this.metroTabPage6.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage6.Name = "metroTabPage6";
            this.metroTabPage6.Size = new System.Drawing.Size(618, 200);
            this.metroTabPage6.TabIndex = 2;
            this.metroTabPage6.Text = "Konum Özellikleri";
            this.metroTabPage6.VerticalScrollbarBarColor = true;
            this.metroTabPage6.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage6.VerticalScrollbarSize = 10;
            // 
            // lstAddKonumOzellikler
            // 
            this.lstAddKonumOzellikler.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lstAddKonumOzellikler.FormattingEnabled = true;
            this.lstAddKonumOzellikler.ItemHeight = 16;
            this.lstAddKonumOzellikler.Location = new System.Drawing.Point(272, 16);
            this.lstAddKonumOzellikler.MultiColumn = true;
            this.lstAddKonumOzellikler.Name = "lstAddKonumOzellikler";
            this.lstAddKonumOzellikler.Size = new System.Drawing.Size(160, 164);
            this.lstAddKonumOzellikler.TabIndex = 90;
            this.lstAddKonumOzellikler.SelectedIndexChanged += new System.EventHandler(this.lstAddKonumOzellikler_SelectedIndexChanged);
            // 
            // btnAddKonumSil
            // 
            this.btnAddKonumSil.Location = new System.Drawing.Point(198, 47);
            this.btnAddKonumSil.Name = "btnAddKonumSil";
            this.btnAddKonumSil.Size = new System.Drawing.Size(68, 23);
            this.btnAddKonumSil.TabIndex = 87;
            this.btnAddKonumSil.Text = "Çıkar";
            this.btnAddKonumSil.UseSelectable = true;
            this.btnAddKonumSil.Click += new System.EventHandler(this.btnAddKonumSil_Click);
            // 
            // btnAddKonumGuncelle
            // 
            this.btnAddKonumGuncelle.Location = new System.Drawing.Point(124, 47);
            this.btnAddKonumGuncelle.Name = "btnAddKonumGuncelle";
            this.btnAddKonumGuncelle.Size = new System.Drawing.Size(68, 23);
            this.btnAddKonumGuncelle.TabIndex = 88;
            this.btnAddKonumGuncelle.Text = "Güncelle";
            this.btnAddKonumGuncelle.UseSelectable = true;
            this.btnAddKonumGuncelle.Click += new System.EventHandler(this.btnAddKonumGuncelle_Click);
            // 
            // btnAddKonumEkle
            // 
            this.btnAddKonumEkle.Location = new System.Drawing.Point(47, 47);
            this.btnAddKonumEkle.Name = "btnAddKonumEkle";
            this.btnAddKonumEkle.Size = new System.Drawing.Size(67, 23);
            this.btnAddKonumEkle.TabIndex = 89;
            this.btnAddKonumEkle.Text = "Ekle";
            this.btnAddKonumEkle.UseSelectable = true;
            this.btnAddKonumEkle.Click += new System.EventHandler(this.btnAddKonumEkle_Click);
            // 
            // txtAddKonumName
            // 
            // 
            // 
            // 
            this.txtAddKonumName.CustomButton.Image = null;
            this.txtAddKonumName.CustomButton.Location = new System.Drawing.Point(116, 1);
            this.txtAddKonumName.CustomButton.Name = "";
            this.txtAddKonumName.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtAddKonumName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtAddKonumName.CustomButton.TabIndex = 1;
            this.txtAddKonumName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtAddKonumName.CustomButton.UseSelectable = true;
            this.txtAddKonumName.CustomButton.Visible = false;
            this.txtAddKonumName.Lines = new string[0];
            this.txtAddKonumName.Location = new System.Drawing.Point(126, 16);
            this.txtAddKonumName.MaxLength = 32767;
            this.txtAddKonumName.Name = "txtAddKonumName";
            this.txtAddKonumName.PasswordChar = '\0';
            this.txtAddKonumName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAddKonumName.SelectedText = "";
            this.txtAddKonumName.SelectionLength = 0;
            this.txtAddKonumName.SelectionStart = 0;
            this.txtAddKonumName.ShortcutsEnabled = true;
            this.txtAddKonumName.Size = new System.Drawing.Size(140, 25);
            this.txtAddKonumName.TabIndex = 79;
            this.txtAddKonumName.UseSelectable = true;
            this.txtAddKonumName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtAddKonumName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel2.Location = new System.Drawing.Point(0, 20);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(114, 19);
            this.metroLabel2.TabIndex = 78;
            this.metroLabel2.Text = "Konum Özellik :";
            // 
            // metroTabPage12
            // 
            this.metroTabPage12.AllowDrop = true;
            this.metroTabPage12.AutoScroll = true;
            this.metroTabPage12.Controls.Add(this.btnAddResimSil);
            this.metroTabPage12.Controls.Add(this.btnAddResimEkle);
            this.metroTabPage12.Controls.Add(this.label30);
            this.metroTabPage12.Controls.Add(this.fLpAddResimler);
            this.metroTabPage12.Controls.Add(this.label29);
            this.metroTabPage12.HorizontalScrollbar = true;
            this.metroTabPage12.HorizontalScrollbarBarColor = true;
            this.metroTabPage12.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage12.HorizontalScrollbarSize = 10;
            this.metroTabPage12.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage12.Name = "metroTabPage12";
            this.metroTabPage12.Size = new System.Drawing.Size(618, 200);
            this.metroTabPage12.TabIndex = 4;
            this.metroTabPage12.Text = "Resim Ekle";
            this.metroTabPage12.VerticalScrollbar = true;
            this.metroTabPage12.VerticalScrollbarBarColor = true;
            this.metroTabPage12.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage12.VerticalScrollbarSize = 10;
            // 
            // btnAddResimSil
            // 
            this.btnAddResimSil.Location = new System.Drawing.Point(536, 160);
            this.btnAddResimSil.Name = "btnAddResimSil";
            this.btnAddResimSil.Size = new System.Drawing.Size(79, 37);
            this.btnAddResimSil.TabIndex = 46;
            this.btnAddResimSil.Text = "Resmi Sil";
            this.btnAddResimSil.UseSelectable = true;
            this.btnAddResimSil.Click += new System.EventHandler(this.btnAddResimSil_Click);
            // 
            // btnAddResimEkle
            // 
            this.btnAddResimEkle.Location = new System.Drawing.Point(431, 160);
            this.btnAddResimEkle.Name = "btnAddResimEkle";
            this.btnAddResimEkle.Size = new System.Drawing.Size(79, 37);
            this.btnAddResimEkle.TabIndex = 44;
            this.btnAddResimEkle.Text = "Resim Ekle";
            this.btnAddResimEkle.UseSelectable = true;
            this.btnAddResimEkle.Click += new System.EventHandler(this.btnAddResimEkle_Click);
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.Black;
            this.label30.Location = new System.Drawing.Point(6, 31);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(611, 1);
            this.label30.TabIndex = 5;
            // 
            // fLpAddResimler
            // 
            this.fLpAddResimler.AutoScroll = true;
            this.fLpAddResimler.Location = new System.Drawing.Point(6, 35);
            this.fLpAddResimler.Name = "fLpAddResimler";
            this.fLpAddResimler.Size = new System.Drawing.Size(609, 119);
            this.fLpAddResimler.TabIndex = 4;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.White;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label29.Location = new System.Drawing.Point(3, 11);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(71, 17);
            this.label29.TabIndex = 3;
            this.label29.Text = "Resimler";
            // 
            // txtAddIlanAciklama
            // 
            // 
            // 
            // 
            this.txtAddIlanAciklama.CustomButton.Image = null;
            this.txtAddIlanAciklama.CustomButton.Location = new System.Drawing.Point(141, 1);
            this.txtAddIlanAciklama.CustomButton.Name = "";
            this.txtAddIlanAciklama.CustomButton.Size = new System.Drawing.Size(45, 45);
            this.txtAddIlanAciklama.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtAddIlanAciklama.CustomButton.TabIndex = 1;
            this.txtAddIlanAciklama.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtAddIlanAciklama.CustomButton.UseSelectable = true;
            this.txtAddIlanAciklama.CustomButton.Visible = false;
            this.txtAddIlanAciklama.Lines = new string[0];
            this.txtAddIlanAciklama.Location = new System.Drawing.Point(463, 221);
            this.txtAddIlanAciklama.MaxLength = 32767;
            this.txtAddIlanAciklama.Multiline = true;
            this.txtAddIlanAciklama.Name = "txtAddIlanAciklama";
            this.txtAddIlanAciklama.PasswordChar = '\0';
            this.txtAddIlanAciklama.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAddIlanAciklama.SelectedText = "";
            this.txtAddIlanAciklama.SelectionLength = 0;
            this.txtAddIlanAciklama.SelectionStart = 0;
            this.txtAddIlanAciklama.ShortcutsEnabled = true;
            this.txtAddIlanAciklama.Size = new System.Drawing.Size(187, 47);
            this.txtAddIlanAciklama.TabIndex = 41;
            this.txtAddIlanAciklama.UseSelectable = true;
            this.txtAddIlanAciklama.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtAddIlanAciklama.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(360, 221);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 17);
            this.label11.TabIndex = 40;
            this.label11.Text = "Açıklama :";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nUdAddIlanNet
            // 
            this.nUdAddIlanNet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.nUdAddIlanNet.Location = new System.Drawing.Point(463, 189);
            this.nUdAddIlanNet.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nUdAddIlanNet.Name = "nUdAddIlanNet";
            this.nUdAddIlanNet.Size = new System.Drawing.Size(104, 26);
            this.nUdAddIlanNet.TabIndex = 39;
            // 
            // nUdAddIlanBrut
            // 
            this.nUdAddIlanBrut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.nUdAddIlanBrut.Location = new System.Drawing.Point(463, 157);
            this.nUdAddIlanBrut.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nUdAddIlanBrut.Name = "nUdAddIlanBrut";
            this.nUdAddIlanBrut.Size = new System.Drawing.Size(104, 26);
            this.nUdAddIlanBrut.TabIndex = 39;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(360, 195);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(38, 17);
            this.label7.TabIndex = 36;
            this.label7.Text = "Net :";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.Location = new System.Drawing.Point(578, 194);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 17);
            this.label10.TabIndex = 37;
            this.label10.Text = "metrekare";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(578, 162);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(72, 17);
            this.label9.TabIndex = 37;
            this.label9.Text = "metrekare";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(360, 162);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 17);
            this.label8.TabIndex = 37;
            this.label8.Text = "Brüt :";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dTpAddIlanTarihi
            // 
            this.dTpAddIlanTarihi.Location = new System.Drawing.Point(462, 117);
            this.dTpAddIlanTarihi.MinimumSize = new System.Drawing.Size(4, 29);
            this.dTpAddIlanTarihi.Name = "dTpAddIlanTarihi";
            this.dTpAddIlanTarihi.Size = new System.Drawing.Size(188, 29);
            this.dTpAddIlanTarihi.TabIndex = 35;
            // 
            // cbAddAltKategori
            // 
            this.cbAddAltKategori.FormattingEnabled = true;
            this.cbAddAltKategori.ItemHeight = 23;
            this.cbAddAltKategori.Location = new System.Drawing.Point(123, 97);
            this.cbAddAltKategori.Name = "cbAddAltKategori";
            this.cbAddAltKategori.Size = new System.Drawing.Size(178, 29);
            this.cbAddAltKategori.TabIndex = 34;
            this.cbAddAltKategori.UseSelectable = true;
            // 
            // cbAddIlanVeren
            // 
            this.cbAddIlanVeren.FormattingEnabled = true;
            this.cbAddIlanVeren.ItemHeight = 23;
            this.cbAddIlanVeren.Location = new System.Drawing.Point(123, 242);
            this.cbAddIlanVeren.Name = "cbAddIlanVeren";
            this.cbAddIlanVeren.Size = new System.Drawing.Size(178, 29);
            this.cbAddIlanVeren.TabIndex = 34;
            this.cbAddIlanVeren.UseSelectable = true;
            // 
            // cbAddSemtler
            // 
            this.cbAddSemtler.FormattingEnabled = true;
            this.cbAddSemtler.ItemHeight = 23;
            this.cbAddSemtler.Location = new System.Drawing.Point(123, 207);
            this.cbAddSemtler.Name = "cbAddSemtler";
            this.cbAddSemtler.Size = new System.Drawing.Size(178, 29);
            this.cbAddSemtler.TabIndex = 34;
            this.cbAddSemtler.UseSelectable = true;
            // 
            // cbAddKategori
            // 
            this.cbAddKategori.FormattingEnabled = true;
            this.cbAddKategori.ItemHeight = 23;
            this.cbAddKategori.Location = new System.Drawing.Point(123, 63);
            this.cbAddKategori.Name = "cbAddKategori";
            this.cbAddKategori.Size = new System.Drawing.Size(178, 29);
            this.cbAddKategori.TabIndex = 34;
            this.cbAddKategori.UseSelectable = true;
            this.cbAddKategori.SelectionChangeCommitted += new System.EventHandler(this.cbAddKategori_SelectionChangeCommitted);
            // 
            // cbAddIlceler
            // 
            this.cbAddIlceler.FormattingEnabled = true;
            this.cbAddIlceler.ItemHeight = 23;
            this.cbAddIlceler.Location = new System.Drawing.Point(123, 172);
            this.cbAddIlceler.Name = "cbAddIlceler";
            this.cbAddIlceler.Size = new System.Drawing.Size(178, 29);
            this.cbAddIlceler.TabIndex = 34;
            this.cbAddIlceler.UseSelectable = true;
            this.cbAddIlceler.SelectionChangeCommitted += new System.EventHandler(this.cbAddIlceler_SelectionChangeCommitted);
            // 
            // cbAddIlanTuru
            // 
            this.cbAddIlanTuru.FormattingEnabled = true;
            this.cbAddIlanTuru.ItemHeight = 23;
            this.cbAddIlanTuru.Location = new System.Drawing.Point(123, 25);
            this.cbAddIlanTuru.Name = "cbAddIlanTuru";
            this.cbAddIlanTuru.Size = new System.Drawing.Size(178, 29);
            this.cbAddIlanTuru.TabIndex = 34;
            this.cbAddIlanTuru.UseSelectable = true;
            this.cbAddIlanTuru.SelectionChangeCommitted += new System.EventHandler(this.cbAddIlanTuru_SelectionChangeCommitted);
            // 
            // cbAddIller
            // 
            this.cbAddIller.FormattingEnabled = true;
            this.cbAddIller.ItemHeight = 23;
            this.cbAddIller.Location = new System.Drawing.Point(123, 135);
            this.cbAddIller.Name = "cbAddIller";
            this.cbAddIller.Size = new System.Drawing.Size(178, 29);
            this.cbAddIller.TabIndex = 34;
            this.cbAddIller.UseSelectable = true;
            this.cbAddIller.SelectionChangeCommitted += new System.EventHandler(this.cbAddIller_SelectionChangeCommitted);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.Location = new System.Drawing.Point(24, 104);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(89, 17);
            this.label14.TabIndex = 32;
            this.label14.Text = "Kategori Alt :";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.White;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label34.Location = new System.Drawing.Point(24, 247);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(80, 17);
            this.label34.TabIndex = 32;
            this.label34.Text = "İlan Veren :";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtAddIlanNo
            // 
            // 
            // 
            // 
            this.txtAddIlanNo.CustomButton.Image = null;
            this.txtAddIlanNo.CustomButton.Location = new System.Drawing.Point(164, 2);
            this.txtAddIlanNo.CustomButton.Name = "";
            this.txtAddIlanNo.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtAddIlanNo.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtAddIlanNo.CustomButton.TabIndex = 1;
            this.txtAddIlanNo.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtAddIlanNo.CustomButton.UseSelectable = true;
            this.txtAddIlanNo.CustomButton.Visible = false;
            this.txtAddIlanNo.Enabled = false;
            this.txtAddIlanNo.Lines = new string[0];
            this.txtAddIlanNo.Location = new System.Drawing.Point(462, 85);
            this.txtAddIlanNo.MaxLength = 32767;
            this.txtAddIlanNo.Name = "txtAddIlanNo";
            this.txtAddIlanNo.PasswordChar = '\0';
            this.txtAddIlanNo.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAddIlanNo.SelectedText = "";
            this.txtAddIlanNo.SelectionLength = 0;
            this.txtAddIlanNo.SelectionStart = 0;
            this.txtAddIlanNo.ShortcutsEnabled = true;
            this.txtAddIlanNo.Size = new System.Drawing.Size(188, 26);
            this.txtAddIlanNo.TabIndex = 33;
            this.txtAddIlanNo.UseSelectable = true;
            this.txtAddIlanNo.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtAddIlanNo.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.Location = new System.Drawing.Point(24, 212);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 17);
            this.label5.TabIndex = 32;
            this.label5.Text = "Semt :";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(360, 125);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 17);
            this.label6.TabIndex = 32;
            this.label6.Text = "İlan Tarihi :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.Location = new System.Drawing.Point(24, 69);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 17);
            this.label13.TabIndex = 32;
            this.label13.Text = "Kategori :";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(360, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 17);
            this.label2.TabIndex = 32;
            this.label2.Text = "İlan No :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(24, 177);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 17);
            this.label4.TabIndex = 32;
            this.label4.Text = "İlçe :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.Location = new System.Drawing.Point(24, 32);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(46, 17);
            this.label12.TabIndex = 32;
            this.label12.Text = "Türü :";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtAddFiyat
            // 
            // 
            // 
            // 
            this.txtAddFiyat.CustomButton.Image = null;
            this.txtAddFiyat.CustomButton.Location = new System.Drawing.Point(164, 2);
            this.txtAddFiyat.CustomButton.Name = "";
            this.txtAddFiyat.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtAddFiyat.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtAddFiyat.CustomButton.TabIndex = 1;
            this.txtAddFiyat.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtAddFiyat.CustomButton.UseSelectable = true;
            this.txtAddFiyat.CustomButton.Visible = false;
            this.txtAddFiyat.Lines = new string[0];
            this.txtAddFiyat.Location = new System.Drawing.Point(462, 53);
            this.txtAddFiyat.MaxLength = 32767;
            this.txtAddFiyat.Name = "txtAddFiyat";
            this.txtAddFiyat.PasswordChar = '\0';
            this.txtAddFiyat.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAddFiyat.SelectedText = "";
            this.txtAddFiyat.SelectionLength = 0;
            this.txtAddFiyat.SelectionStart = 0;
            this.txtAddFiyat.ShortcutsEnabled = true;
            this.txtAddFiyat.Size = new System.Drawing.Size(188, 26);
            this.txtAddFiyat.TabIndex = 33;
            this.txtAddFiyat.UseSelectable = true;
            this.txtAddFiyat.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtAddFiyat.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtAddTitle
            // 
            // 
            // 
            // 
            this.txtAddTitle.CustomButton.Image = null;
            this.txtAddTitle.CustomButton.Location = new System.Drawing.Point(164, 2);
            this.txtAddTitle.CustomButton.Name = "";
            this.txtAddTitle.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtAddTitle.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtAddTitle.CustomButton.TabIndex = 1;
            this.txtAddTitle.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtAddTitle.CustomButton.UseSelectable = true;
            this.txtAddTitle.CustomButton.Visible = false;
            this.txtAddTitle.Lines = new string[0];
            this.txtAddTitle.Location = new System.Drawing.Point(462, 21);
            this.txtAddTitle.MaxLength = 32767;
            this.txtAddTitle.Name = "txtAddTitle";
            this.txtAddTitle.PasswordChar = '\0';
            this.txtAddTitle.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAddTitle.SelectedText = "";
            this.txtAddTitle.SelectionLength = 0;
            this.txtAddTitle.SelectionStart = 0;
            this.txtAddTitle.ShortcutsEnabled = true;
            this.txtAddTitle.Size = new System.Drawing.Size(188, 26);
            this.txtAddTitle.TabIndex = 33;
            this.txtAddTitle.UseSelectable = true;
            this.txtAddTitle.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtAddTitle.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.White;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label36.Location = new System.Drawing.Point(360, 57);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(72, 17);
            this.label36.TabIndex = 32;
            this.label36.Text = "İlan Fiyat :";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(28, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(22, 17);
            this.label3.TabIndex = 32;
            this.label3.Text = "İl :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAdi
            // 
            this.lblAdi.AutoSize = true;
            this.lblAdi.BackColor = System.Drawing.Color.White;
            this.lblAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAdi.Location = new System.Drawing.Point(360, 26);
            this.lblAdi.Name = "lblAdi";
            this.lblAdi.Size = new System.Drawing.Size(79, 17);
            this.lblAdi.TabIndex = 32;
            this.lblAdi.Text = "İlan Başlık :";
            this.lblAdi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // metroTabPage3
            // 
            this.metroTabPage3.Controls.Add(this.txtUpdateFiyat);
            this.metroTabPage3.Controls.Add(this.label37);
            this.metroTabPage3.Controls.Add(this.cbUpdateIlanVeren);
            this.metroTabPage3.Controls.Add(this.label35);
            this.metroTabPage3.Controls.Add(this.btnUpdate);
            this.metroTabPage3.Controls.Add(this.metroTabControl3);
            this.metroTabPage3.Controls.Add(this.txtUpdateIlanAciklama);
            this.metroTabPage3.Controls.Add(this.label15);
            this.metroTabPage3.Controls.Add(this.nUdUpdateIlanNet);
            this.metroTabPage3.Controls.Add(this.nUdUpdateIlanBrut);
            this.metroTabPage3.Controls.Add(this.label16);
            this.metroTabPage3.Controls.Add(this.label17);
            this.metroTabPage3.Controls.Add(this.label18);
            this.metroTabPage3.Controls.Add(this.label19);
            this.metroTabPage3.Controls.Add(this.dTpUpdateIlanTarihi);
            this.metroTabPage3.Controls.Add(this.cbUpdateIlanAltKategori);
            this.metroTabPage3.Controls.Add(this.cbUpdateIlanSemt);
            this.metroTabPage3.Controls.Add(this.cbUpdateIlanKategori);
            this.metroTabPage3.Controls.Add(this.cbUpdateIlanIlceler);
            this.metroTabPage3.Controls.Add(this.cbUpdateIlanTuru);
            this.metroTabPage3.Controls.Add(this.cbUpdateIlanIller);
            this.metroTabPage3.Controls.Add(this.label20);
            this.metroTabPage3.Controls.Add(this.txtUpdateIlanNo);
            this.metroTabPage3.Controls.Add(this.label21);
            this.metroTabPage3.Controls.Add(this.label22);
            this.metroTabPage3.Controls.Add(this.label23);
            this.metroTabPage3.Controls.Add(this.label24);
            this.metroTabPage3.Controls.Add(this.label25);
            this.metroTabPage3.Controls.Add(this.label26);
            this.metroTabPage3.Controls.Add(this.txtUpdateIlanTitle);
            this.metroTabPage3.Controls.Add(this.label27);
            this.metroTabPage3.Controls.Add(this.label28);
            this.metroTabPage3.HorizontalScrollbarBarColor = true;
            this.metroTabPage3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.HorizontalScrollbarSize = 10;
            this.metroTabPage3.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage3.Name = "metroTabPage3";
            this.metroTabPage3.Size = new System.Drawing.Size(679, 567);
            this.metroTabPage3.TabIndex = 2;
            this.metroTabPage3.Text = "İlan Güncelle";
            this.metroTabPage3.VerticalScrollbarBarColor = true;
            this.metroTabPage3.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.VerticalScrollbarSize = 10;
            // 
            // txtUpdateFiyat
            // 
            // 
            // 
            // 
            this.txtUpdateFiyat.CustomButton.Image = null;
            this.txtUpdateFiyat.CustomButton.Location = new System.Drawing.Point(164, 2);
            this.txtUpdateFiyat.CustomButton.Name = "";
            this.txtUpdateFiyat.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtUpdateFiyat.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUpdateFiyat.CustomButton.TabIndex = 1;
            this.txtUpdateFiyat.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUpdateFiyat.CustomButton.UseSelectable = true;
            this.txtUpdateFiyat.CustomButton.Visible = false;
            this.txtUpdateFiyat.Lines = new string[0];
            this.txtUpdateFiyat.Location = new System.Drawing.Point(463, 59);
            this.txtUpdateFiyat.MaxLength = 32767;
            this.txtUpdateFiyat.Name = "txtUpdateFiyat";
            this.txtUpdateFiyat.PasswordChar = '\0';
            this.txtUpdateFiyat.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUpdateFiyat.SelectedText = "";
            this.txtUpdateFiyat.SelectionLength = 0;
            this.txtUpdateFiyat.SelectionStart = 0;
            this.txtUpdateFiyat.ShortcutsEnabled = true;
            this.txtUpdateFiyat.Size = new System.Drawing.Size(188, 26);
            this.txtUpdateFiyat.TabIndex = 74;
            this.txtUpdateFiyat.UseSelectable = true;
            this.txtUpdateFiyat.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUpdateFiyat.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.White;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label37.Location = new System.Drawing.Point(361, 63);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(72, 17);
            this.label37.TabIndex = 73;
            this.label37.Text = "İlan Fiyat :";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cbUpdateIlanVeren
            // 
            this.cbUpdateIlanVeren.FormattingEnabled = true;
            this.cbUpdateIlanVeren.ItemHeight = 23;
            this.cbUpdateIlanVeren.Location = new System.Drawing.Point(124, 244);
            this.cbUpdateIlanVeren.Name = "cbUpdateIlanVeren";
            this.cbUpdateIlanVeren.Size = new System.Drawing.Size(178, 29);
            this.cbUpdateIlanVeren.TabIndex = 72;
            this.cbUpdateIlanVeren.UseSelectable = true;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.Color.White;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label35.Location = new System.Drawing.Point(25, 249);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(80, 17);
            this.label35.TabIndex = 71;
            this.label35.Text = "İlan Veren :";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(209, 512);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(281, 37);
            this.btnUpdate.TabIndex = 70;
            this.btnUpdate.Text = "GÜNCELLE";
            this.btnUpdate.UseSelectable = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // metroTabControl3
            // 
            this.metroTabControl3.Controls.Add(this.metroTabPage8);
            this.metroTabControl3.Controls.Add(this.metroTabPage9);
            this.metroTabControl3.Controls.Add(this.metroTabPage10);
            this.metroTabControl3.Controls.Add(this.metroTabPage11);
            this.metroTabControl3.Controls.Add(this.metroTabPage13);
            this.metroTabControl3.Location = new System.Drawing.Point(30, 279);
            this.metroTabControl3.Name = "metroTabControl3";
            this.metroTabControl3.SelectedIndex = 4;
            this.metroTabControl3.Size = new System.Drawing.Size(626, 223);
            this.metroTabControl3.TabIndex = 69;
            this.metroTabControl3.UseSelectable = true;
            this.metroTabControl3.SelectedIndexChanged += new System.EventHandler(this.metroTabControl3_SelectedIndexChanged);
            // 
            // metroTabPage8
            // 
            this.metroTabPage8.Controls.Add(this.lstUpdateEkOzellikler);
            this.metroTabPage8.Controls.Add(this.btnUpdateEkOzellikSil);
            this.metroTabPage8.Controls.Add(this.btnUpdateEkOzellikGuncelle);
            this.metroTabPage8.Controls.Add(this.btnUpdateEkOzellikEkle);
            this.metroTabPage8.Controls.Add(this.txtUpdateEkOzellikAciklama);
            this.metroTabPage8.Controls.Add(this.metroLabel6);
            this.metroTabPage8.Controls.Add(this.txtUpdateEkOzellikName);
            this.metroTabPage8.Controls.Add(this.metroLabel7);
            this.metroTabPage8.HorizontalScrollbarBarColor = true;
            this.metroTabPage8.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage8.HorizontalScrollbarSize = 10;
            this.metroTabPage8.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage8.Name = "metroTabPage8";
            this.metroTabPage8.Size = new System.Drawing.Size(618, 181);
            this.metroTabPage8.TabIndex = 3;
            this.metroTabPage8.Text = "Ek Özellikler";
            this.metroTabPage8.VerticalScrollbarBarColor = true;
            this.metroTabPage8.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage8.VerticalScrollbarSize = 10;
            // 
            // lstUpdateEkOzellikler
            // 
            this.lstUpdateEkOzellikler.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lstUpdateEkOzellikler.FormattingEnabled = true;
            this.lstUpdateEkOzellikler.ItemHeight = 16;
            this.lstUpdateEkOzellikler.Location = new System.Drawing.Point(277, 14);
            this.lstUpdateEkOzellikler.MultiColumn = true;
            this.lstUpdateEkOzellikler.Name = "lstUpdateEkOzellikler";
            this.lstUpdateEkOzellikler.Size = new System.Drawing.Size(242, 164);
            this.lstUpdateEkOzellikler.TabIndex = 77;
            this.lstUpdateEkOzellikler.SelectedIndexChanged += new System.EventHandler(this.lstUpdateEkOzellikler_SelectedIndexChanged);
            // 
            // btnUpdateEkOzellikSil
            // 
            this.btnUpdateEkOzellikSil.Location = new System.Drawing.Point(182, 80);
            this.btnUpdateEkOzellikSil.Name = "btnUpdateEkOzellikSil";
            this.btnUpdateEkOzellikSil.Size = new System.Drawing.Size(68, 23);
            this.btnUpdateEkOzellikSil.TabIndex = 74;
            this.btnUpdateEkOzellikSil.Text = "Çıkar";
            this.btnUpdateEkOzellikSil.UseSelectable = true;
            this.btnUpdateEkOzellikSil.Click += new System.EventHandler(this.btnUpdateEkOzellikSil_Click);
            // 
            // btnUpdateEkOzellikGuncelle
            // 
            this.btnUpdateEkOzellikGuncelle.Location = new System.Drawing.Point(108, 80);
            this.btnUpdateEkOzellikGuncelle.Name = "btnUpdateEkOzellikGuncelle";
            this.btnUpdateEkOzellikGuncelle.Size = new System.Drawing.Size(68, 23);
            this.btnUpdateEkOzellikGuncelle.TabIndex = 75;
            this.btnUpdateEkOzellikGuncelle.Text = "Güncelle";
            this.btnUpdateEkOzellikGuncelle.UseSelectable = true;
            this.btnUpdateEkOzellikGuncelle.Click += new System.EventHandler(this.btnUpdateEkOzellikGuncelle_Click);
            // 
            // btnUpdateEkOzellikEkle
            // 
            this.btnUpdateEkOzellikEkle.Location = new System.Drawing.Point(35, 80);
            this.btnUpdateEkOzellikEkle.Name = "btnUpdateEkOzellikEkle";
            this.btnUpdateEkOzellikEkle.Size = new System.Drawing.Size(67, 23);
            this.btnUpdateEkOzellikEkle.TabIndex = 76;
            this.btnUpdateEkOzellikEkle.Text = "Ekle";
            this.btnUpdateEkOzellikEkle.UseSelectable = true;
            this.btnUpdateEkOzellikEkle.Click += new System.EventHandler(this.btnUpdateEkOzellikEkle_Click);
            // 
            // txtUpdateEkOzellikAciklama
            // 
            // 
            // 
            // 
            this.txtUpdateEkOzellikAciklama.CustomButton.Image = null;
            this.txtUpdateEkOzellikAciklama.CustomButton.Location = new System.Drawing.Point(122, 1);
            this.txtUpdateEkOzellikAciklama.CustomButton.Name = "";
            this.txtUpdateEkOzellikAciklama.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtUpdateEkOzellikAciklama.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUpdateEkOzellikAciklama.CustomButton.TabIndex = 1;
            this.txtUpdateEkOzellikAciklama.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUpdateEkOzellikAciklama.CustomButton.UseSelectable = true;
            this.txtUpdateEkOzellikAciklama.CustomButton.Visible = false;
            this.txtUpdateEkOzellikAciklama.Lines = new string[0];
            this.txtUpdateEkOzellikAciklama.Location = new System.Drawing.Point(104, 49);
            this.txtUpdateEkOzellikAciklama.MaxLength = 32767;
            this.txtUpdateEkOzellikAciklama.Name = "txtUpdateEkOzellikAciklama";
            this.txtUpdateEkOzellikAciklama.PasswordChar = '\0';
            this.txtUpdateEkOzellikAciklama.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUpdateEkOzellikAciklama.SelectedText = "";
            this.txtUpdateEkOzellikAciklama.SelectionLength = 0;
            this.txtUpdateEkOzellikAciklama.SelectionStart = 0;
            this.txtUpdateEkOzellikAciklama.ShortcutsEnabled = true;
            this.txtUpdateEkOzellikAciklama.Size = new System.Drawing.Size(146, 25);
            this.txtUpdateEkOzellikAciklama.TabIndex = 72;
            this.txtUpdateEkOzellikAciklama.UseSelectable = true;
            this.txtUpdateEkOzellikAciklama.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUpdateEkOzellikAciklama.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel6.Location = new System.Drawing.Point(-1, 49);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(79, 19);
            this.metroLabel6.TabIndex = 70;
            this.metroLabel6.Text = "Açıklama :";
            // 
            // txtUpdateEkOzellikName
            // 
            // 
            // 
            // 
            this.txtUpdateEkOzellikName.CustomButton.Image = null;
            this.txtUpdateEkOzellikName.CustomButton.Location = new System.Drawing.Point(122, 1);
            this.txtUpdateEkOzellikName.CustomButton.Name = "";
            this.txtUpdateEkOzellikName.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtUpdateEkOzellikName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUpdateEkOzellikName.CustomButton.TabIndex = 1;
            this.txtUpdateEkOzellikName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUpdateEkOzellikName.CustomButton.UseSelectable = true;
            this.txtUpdateEkOzellikName.CustomButton.Visible = false;
            this.txtUpdateEkOzellikName.Lines = new string[0];
            this.txtUpdateEkOzellikName.Location = new System.Drawing.Point(104, 18);
            this.txtUpdateEkOzellikName.MaxLength = 32767;
            this.txtUpdateEkOzellikName.Name = "txtUpdateEkOzellikName";
            this.txtUpdateEkOzellikName.PasswordChar = '\0';
            this.txtUpdateEkOzellikName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUpdateEkOzellikName.SelectedText = "";
            this.txtUpdateEkOzellikName.SelectionLength = 0;
            this.txtUpdateEkOzellikName.SelectionStart = 0;
            this.txtUpdateEkOzellikName.ShortcutsEnabled = true;
            this.txtUpdateEkOzellikName.Size = new System.Drawing.Size(146, 25);
            this.txtUpdateEkOzellikName.TabIndex = 73;
            this.txtUpdateEkOzellikName.UseSelectable = true;
            this.txtUpdateEkOzellikName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUpdateEkOzellikName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel7.Location = new System.Drawing.Point(-1, 18);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(40, 19);
            this.metroLabel7.TabIndex = 71;
            this.metroLabel7.Text = "Adı :";
            // 
            // metroTabPage9
            // 
            this.metroTabPage9.Controls.Add(this.lstUpdateDisOzellikler);
            this.metroTabPage9.Controls.Add(this.btnUpdateDisSil);
            this.metroTabPage9.Controls.Add(this.btnUpdateDisGuncelle);
            this.metroTabPage9.Controls.Add(this.btnUpdateDisEkle);
            this.metroTabPage9.Controls.Add(this.txtUpdateDisName);
            this.metroTabPage9.Controls.Add(this.metroLabel8);
            this.metroTabPage9.HorizontalScrollbarBarColor = true;
            this.metroTabPage9.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage9.HorizontalScrollbarSize = 10;
            this.metroTabPage9.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage9.Name = "metroTabPage9";
            this.metroTabPage9.Size = new System.Drawing.Size(618, 181);
            this.metroTabPage9.TabIndex = 0;
            this.metroTabPage9.Text = "Dış Özellikler";
            this.metroTabPage9.VerticalScrollbarBarColor = true;
            this.metroTabPage9.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage9.VerticalScrollbarSize = 10;
            // 
            // lstUpdateDisOzellikler
            // 
            this.lstUpdateDisOzellikler.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lstUpdateDisOzellikler.FormattingEnabled = true;
            this.lstUpdateDisOzellikler.ItemHeight = 16;
            this.lstUpdateDisOzellikler.Location = new System.Drawing.Point(247, 14);
            this.lstUpdateDisOzellikler.MultiColumn = true;
            this.lstUpdateDisOzellikler.Name = "lstUpdateDisOzellikler";
            this.lstUpdateDisOzellikler.Size = new System.Drawing.Size(143, 164);
            this.lstUpdateDisOzellikler.TabIndex = 89;
            this.lstUpdateDisOzellikler.SelectedIndexChanged += new System.EventHandler(this.lstUpdateDisOzellikler_SelectedIndexChanged);
            // 
            // btnUpdateDisSil
            // 
            this.btnUpdateDisSil.Location = new System.Drawing.Point(164, 56);
            this.btnUpdateDisSil.Name = "btnUpdateDisSil";
            this.btnUpdateDisSil.Size = new System.Drawing.Size(68, 23);
            this.btnUpdateDisSil.TabIndex = 86;
            this.btnUpdateDisSil.Text = "Çıkar";
            this.btnUpdateDisSil.UseSelectable = true;
            this.btnUpdateDisSil.Click += new System.EventHandler(this.btnUpdateDisSil_Click);
            // 
            // btnUpdateDisGuncelle
            // 
            this.btnUpdateDisGuncelle.Location = new System.Drawing.Point(90, 56);
            this.btnUpdateDisGuncelle.Name = "btnUpdateDisGuncelle";
            this.btnUpdateDisGuncelle.Size = new System.Drawing.Size(68, 23);
            this.btnUpdateDisGuncelle.TabIndex = 87;
            this.btnUpdateDisGuncelle.Text = "Güncelle";
            this.btnUpdateDisGuncelle.UseSelectable = true;
            this.btnUpdateDisGuncelle.Click += new System.EventHandler(this.btnUpdateDisGuncelle_Click);
            // 
            // btnUpdateDisEkle
            // 
            this.btnUpdateDisEkle.Location = new System.Drawing.Point(17, 56);
            this.btnUpdateDisEkle.Name = "btnUpdateDisEkle";
            this.btnUpdateDisEkle.Size = new System.Drawing.Size(67, 23);
            this.btnUpdateDisEkle.TabIndex = 88;
            this.btnUpdateDisEkle.Text = "Ekle";
            this.btnUpdateDisEkle.UseSelectable = true;
            this.btnUpdateDisEkle.Click += new System.EventHandler(this.btnUpdateDisEkle_Click);
            // 
            // txtUpdateDisName
            // 
            // 
            // 
            // 
            this.txtUpdateDisName.CustomButton.Image = null;
            this.txtUpdateDisName.CustomButton.Location = new System.Drawing.Point(110, 1);
            this.txtUpdateDisName.CustomButton.Name = "";
            this.txtUpdateDisName.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtUpdateDisName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUpdateDisName.CustomButton.TabIndex = 1;
            this.txtUpdateDisName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUpdateDisName.CustomButton.UseSelectable = true;
            this.txtUpdateDisName.CustomButton.Visible = false;
            this.txtUpdateDisName.Lines = new string[0];
            this.txtUpdateDisName.Location = new System.Drawing.Point(98, 14);
            this.txtUpdateDisName.MaxLength = 32767;
            this.txtUpdateDisName.Name = "txtUpdateDisName";
            this.txtUpdateDisName.PasswordChar = '\0';
            this.txtUpdateDisName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUpdateDisName.SelectedText = "";
            this.txtUpdateDisName.SelectionLength = 0;
            this.txtUpdateDisName.SelectionStart = 0;
            this.txtUpdateDisName.ShortcutsEnabled = true;
            this.txtUpdateDisName.Size = new System.Drawing.Size(134, 25);
            this.txtUpdateDisName.TabIndex = 85;
            this.txtUpdateDisName.UseSelectable = true;
            this.txtUpdateDisName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUpdateDisName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel8
            // 
            this.metroLabel8.AutoSize = true;
            this.metroLabel8.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel8.Location = new System.Drawing.Point(5, 20);
            this.metroLabel8.Name = "metroLabel8";
            this.metroLabel8.Size = new System.Drawing.Size(87, 19);
            this.metroLabel8.TabIndex = 84;
            this.metroLabel8.Text = "Dış Özellik :";
            // 
            // metroTabPage10
            // 
            this.metroTabPage10.Controls.Add(this.lstUpdateIcOzellikler);
            this.metroTabPage10.Controls.Add(this.btnUpdateIcSil);
            this.metroTabPage10.Controls.Add(this.btnUpdateIcGuncelle);
            this.metroTabPage10.Controls.Add(this.btnUpdateIcEkle);
            this.metroTabPage10.Controls.Add(this.txtUpdateIcOzellikName);
            this.metroTabPage10.Controls.Add(this.metroLabel9);
            this.metroTabPage10.HorizontalScrollbarBarColor = true;
            this.metroTabPage10.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage10.HorizontalScrollbarSize = 10;
            this.metroTabPage10.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage10.Name = "metroTabPage10";
            this.metroTabPage10.Size = new System.Drawing.Size(618, 181);
            this.metroTabPage10.TabIndex = 1;
            this.metroTabPage10.Text = "İç Özellikler";
            this.metroTabPage10.VerticalScrollbarBarColor = true;
            this.metroTabPage10.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage10.VerticalScrollbarSize = 10;
            // 
            // lstUpdateIcOzellikler
            // 
            this.lstUpdateIcOzellikler.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lstUpdateIcOzellikler.FormattingEnabled = true;
            this.lstUpdateIcOzellikler.ItemHeight = 16;
            this.lstUpdateIcOzellikler.Location = new System.Drawing.Point(254, 12);
            this.lstUpdateIcOzellikler.MultiColumn = true;
            this.lstUpdateIcOzellikler.Name = "lstUpdateIcOzellikler";
            this.lstUpdateIcOzellikler.Size = new System.Drawing.Size(148, 164);
            this.lstUpdateIcOzellikler.TabIndex = 91;
            this.lstUpdateIcOzellikler.SelectedIndexChanged += new System.EventHandler(this.lstUpdateIcOzellikler_SelectedIndexChanged);
            // 
            // btnUpdateIcSil
            // 
            this.btnUpdateIcSil.Location = new System.Drawing.Point(170, 54);
            this.btnUpdateIcSil.Name = "btnUpdateIcSil";
            this.btnUpdateIcSil.Size = new System.Drawing.Size(68, 23);
            this.btnUpdateIcSil.TabIndex = 88;
            this.btnUpdateIcSil.Text = "Çıkar";
            this.btnUpdateIcSil.UseSelectable = true;
            this.btnUpdateIcSil.Click += new System.EventHandler(this.btnUpdateIcSil_Click);
            // 
            // btnUpdateIcGuncelle
            // 
            this.btnUpdateIcGuncelle.Location = new System.Drawing.Point(92, 54);
            this.btnUpdateIcGuncelle.Name = "btnUpdateIcGuncelle";
            this.btnUpdateIcGuncelle.Size = new System.Drawing.Size(68, 23);
            this.btnUpdateIcGuncelle.TabIndex = 89;
            this.btnUpdateIcGuncelle.Text = "Güncelle";
            this.btnUpdateIcGuncelle.UseSelectable = true;
            this.btnUpdateIcGuncelle.Click += new System.EventHandler(this.btnUpdateIcGuncelle_Click);
            // 
            // btnUpdateIcEkle
            // 
            this.btnUpdateIcEkle.Location = new System.Drawing.Point(15, 54);
            this.btnUpdateIcEkle.Name = "btnUpdateIcEkle";
            this.btnUpdateIcEkle.Size = new System.Drawing.Size(67, 23);
            this.btnUpdateIcEkle.TabIndex = 90;
            this.btnUpdateIcEkle.Text = "Ekle";
            this.btnUpdateIcEkle.UseSelectable = true;
            this.btnUpdateIcEkle.Click += new System.EventHandler(this.btnUpdateIcEkle_Click);
            // 
            // txtUpdateIcOzellikName
            // 
            // 
            // 
            // 
            this.txtUpdateIcOzellikName.CustomButton.Image = null;
            this.txtUpdateIcOzellikName.CustomButton.Location = new System.Drawing.Point(131, 1);
            this.txtUpdateIcOzellikName.CustomButton.Name = "";
            this.txtUpdateIcOzellikName.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtUpdateIcOzellikName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUpdateIcOzellikName.CustomButton.TabIndex = 1;
            this.txtUpdateIcOzellikName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUpdateIcOzellikName.CustomButton.UseSelectable = true;
            this.txtUpdateIcOzellikName.CustomButton.Visible = false;
            this.txtUpdateIcOzellikName.Lines = new string[0];
            this.txtUpdateIcOzellikName.Location = new System.Drawing.Point(83, 12);
            this.txtUpdateIcOzellikName.MaxLength = 32767;
            this.txtUpdateIcOzellikName.Name = "txtUpdateIcOzellikName";
            this.txtUpdateIcOzellikName.PasswordChar = '\0';
            this.txtUpdateIcOzellikName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUpdateIcOzellikName.SelectedText = "";
            this.txtUpdateIcOzellikName.SelectionLength = 0;
            this.txtUpdateIcOzellikName.SelectionStart = 0;
            this.txtUpdateIcOzellikName.ShortcutsEnabled = true;
            this.txtUpdateIcOzellikName.Size = new System.Drawing.Size(155, 25);
            this.txtUpdateIcOzellikName.TabIndex = 87;
            this.txtUpdateIcOzellikName.UseSelectable = true;
            this.txtUpdateIcOzellikName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUpdateIcOzellikName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel9
            // 
            this.metroLabel9.AutoSize = true;
            this.metroLabel9.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel9.Location = new System.Drawing.Point(-1, 15);
            this.metroLabel9.Name = "metroLabel9";
            this.metroLabel9.Size = new System.Drawing.Size(78, 19);
            this.metroLabel9.TabIndex = 86;
            this.metroLabel9.Text = "İç Özellik :";
            // 
            // metroTabPage11
            // 
            this.metroTabPage11.Controls.Add(this.lstUpdateKonumOzellikler);
            this.metroTabPage11.Controls.Add(this.btnUpdateKonumSil);
            this.metroTabPage11.Controls.Add(this.btnUpdateKonumGuncelle);
            this.metroTabPage11.Controls.Add(this.btnUpdateKonumEkle);
            this.metroTabPage11.Controls.Add(this.txtUpdateKonumName);
            this.metroTabPage11.Controls.Add(this.metroLabel10);
            this.metroTabPage11.HorizontalScrollbarBarColor = true;
            this.metroTabPage11.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage11.HorizontalScrollbarSize = 10;
            this.metroTabPage11.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage11.Name = "metroTabPage11";
            this.metroTabPage11.Size = new System.Drawing.Size(618, 181);
            this.metroTabPage11.TabIndex = 2;
            this.metroTabPage11.Text = "Konum Özellikleri";
            this.metroTabPage11.VerticalScrollbarBarColor = true;
            this.metroTabPage11.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage11.VerticalScrollbarSize = 10;
            // 
            // lstUpdateKonumOzellikler
            // 
            this.lstUpdateKonumOzellikler.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lstUpdateKonumOzellikler.FormattingEnabled = true;
            this.lstUpdateKonumOzellikler.ItemHeight = 16;
            this.lstUpdateKonumOzellikler.Location = new System.Drawing.Point(275, 9);
            this.lstUpdateKonumOzellikler.MultiColumn = true;
            this.lstUpdateKonumOzellikler.Name = "lstUpdateKonumOzellikler";
            this.lstUpdateKonumOzellikler.Size = new System.Drawing.Size(160, 164);
            this.lstUpdateKonumOzellikler.TabIndex = 96;
            this.lstUpdateKonumOzellikler.SelectedIndexChanged += new System.EventHandler(this.lstUpdateKonumOzellikler_SelectedIndexChanged);
            // 
            // btnUpdateKonumSil
            // 
            this.btnUpdateKonumSil.Location = new System.Drawing.Point(201, 40);
            this.btnUpdateKonumSil.Name = "btnUpdateKonumSil";
            this.btnUpdateKonumSil.Size = new System.Drawing.Size(68, 23);
            this.btnUpdateKonumSil.TabIndex = 93;
            this.btnUpdateKonumSil.Text = "Çıkar";
            this.btnUpdateKonumSil.UseSelectable = true;
            this.btnUpdateKonumSil.Click += new System.EventHandler(this.btnUpdateKonumSil_Click);
            // 
            // btnUpdateKonumGuncelle
            // 
            this.btnUpdateKonumGuncelle.Location = new System.Drawing.Point(127, 40);
            this.btnUpdateKonumGuncelle.Name = "btnUpdateKonumGuncelle";
            this.btnUpdateKonumGuncelle.Size = new System.Drawing.Size(68, 23);
            this.btnUpdateKonumGuncelle.TabIndex = 94;
            this.btnUpdateKonumGuncelle.Text = "Güncelle";
            this.btnUpdateKonumGuncelle.UseSelectable = true;
            this.btnUpdateKonumGuncelle.Click += new System.EventHandler(this.btnUpdateKonumGuncelle_Click);
            // 
            // btnUpdateKonumEkle
            // 
            this.btnUpdateKonumEkle.Location = new System.Drawing.Point(50, 40);
            this.btnUpdateKonumEkle.Name = "btnUpdateKonumEkle";
            this.btnUpdateKonumEkle.Size = new System.Drawing.Size(67, 23);
            this.btnUpdateKonumEkle.TabIndex = 95;
            this.btnUpdateKonumEkle.Text = "Ekle";
            this.btnUpdateKonumEkle.UseSelectable = true;
            this.btnUpdateKonumEkle.Click += new System.EventHandler(this.btnUpdateKonumEkle_Click);
            // 
            // txtUpdateKonumName
            // 
            // 
            // 
            // 
            this.txtUpdateKonumName.CustomButton.Image = null;
            this.txtUpdateKonumName.CustomButton.Location = new System.Drawing.Point(116, 1);
            this.txtUpdateKonumName.CustomButton.Name = "";
            this.txtUpdateKonumName.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtUpdateKonumName.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUpdateKonumName.CustomButton.TabIndex = 1;
            this.txtUpdateKonumName.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUpdateKonumName.CustomButton.UseSelectable = true;
            this.txtUpdateKonumName.CustomButton.Visible = false;
            this.txtUpdateKonumName.Lines = new string[0];
            this.txtUpdateKonumName.Location = new System.Drawing.Point(129, 9);
            this.txtUpdateKonumName.MaxLength = 32767;
            this.txtUpdateKonumName.Name = "txtUpdateKonumName";
            this.txtUpdateKonumName.PasswordChar = '\0';
            this.txtUpdateKonumName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUpdateKonumName.SelectedText = "";
            this.txtUpdateKonumName.SelectionLength = 0;
            this.txtUpdateKonumName.SelectionStart = 0;
            this.txtUpdateKonumName.ShortcutsEnabled = true;
            this.txtUpdateKonumName.Size = new System.Drawing.Size(140, 25);
            this.txtUpdateKonumName.TabIndex = 92;
            this.txtUpdateKonumName.UseSelectable = true;
            this.txtUpdateKonumName.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUpdateKonumName.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel10
            // 
            this.metroLabel10.AutoSize = true;
            this.metroLabel10.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel10.Location = new System.Drawing.Point(3, 12);
            this.metroLabel10.Name = "metroLabel10";
            this.metroLabel10.Size = new System.Drawing.Size(114, 19);
            this.metroLabel10.TabIndex = 91;
            this.metroLabel10.Text = "Konum Özellik :";
            // 
            // metroTabPage13
            // 
            this.metroTabPage13.AutoScroll = true;
            this.metroTabPage13.Controls.Add(this.brnUpdateResimCikar);
            this.metroTabPage13.Controls.Add(this.btnUpdateResimEkle);
            this.metroTabPage13.Controls.Add(this.label31);
            this.metroTabPage13.Controls.Add(this.fLpUpdateResimler);
            this.metroTabPage13.Controls.Add(this.label32);
            this.metroTabPage13.HorizontalScrollbar = true;
            this.metroTabPage13.HorizontalScrollbarBarColor = true;
            this.metroTabPage13.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage13.HorizontalScrollbarSize = 10;
            this.metroTabPage13.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage13.Name = "metroTabPage13";
            this.metroTabPage13.Size = new System.Drawing.Size(618, 181);
            this.metroTabPage13.TabIndex = 4;
            this.metroTabPage13.Text = "Resim Ekle";
            this.metroTabPage13.VerticalScrollbar = true;
            this.metroTabPage13.VerticalScrollbarBarColor = true;
            this.metroTabPage13.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage13.VerticalScrollbarSize = 10;
            // 
            // brnUpdateResimCikar
            // 
            this.brnUpdateResimCikar.Location = new System.Drawing.Point(536, 141);
            this.brnUpdateResimCikar.Name = "brnUpdateResimCikar";
            this.brnUpdateResimCikar.Size = new System.Drawing.Size(79, 37);
            this.brnUpdateResimCikar.TabIndex = 45;
            this.brnUpdateResimCikar.Text = "Resmi Sil";
            this.brnUpdateResimCikar.UseSelectable = true;
            this.brnUpdateResimCikar.Click += new System.EventHandler(this.brnUpdateResimCikar_Click);
            // 
            // btnUpdateResimEkle
            // 
            this.btnUpdateResimEkle.Location = new System.Drawing.Point(451, 141);
            this.btnUpdateResimEkle.Name = "btnUpdateResimEkle";
            this.btnUpdateResimEkle.Size = new System.Drawing.Size(79, 37);
            this.btnUpdateResimEkle.TabIndex = 45;
            this.btnUpdateResimEkle.Text = "Resim Ekle";
            this.btnUpdateResimEkle.UseSelectable = true;
            this.btnUpdateResimEkle.Click += new System.EventHandler(this.btnUpdateResimEkle_Click);
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.Black;
            this.label31.Location = new System.Drawing.Point(6, 32);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(611, 1);
            this.label31.TabIndex = 9;
            // 
            // fLpUpdateResimler
            // 
            this.fLpUpdateResimler.AutoScroll = true;
            this.fLpUpdateResimler.Location = new System.Drawing.Point(6, 36);
            this.fLpUpdateResimler.Name = "fLpUpdateResimler";
            this.fLpUpdateResimler.Size = new System.Drawing.Size(609, 102);
            this.fLpUpdateResimler.TabIndex = 8;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.White;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label32.Location = new System.Drawing.Point(3, 12);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(71, 17);
            this.label32.TabIndex = 7;
            this.label32.Text = "Resimler";
            // 
            // txtUpdateIlanAciklama
            // 
            // 
            // 
            // 
            this.txtUpdateIlanAciklama.CustomButton.Image = null;
            this.txtUpdateIlanAciklama.CustomButton.Location = new System.Drawing.Point(141, 2);
            this.txtUpdateIlanAciklama.CustomButton.Name = "";
            this.txtUpdateIlanAciklama.CustomButton.Size = new System.Drawing.Size(43, 43);
            this.txtUpdateIlanAciklama.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUpdateIlanAciklama.CustomButton.TabIndex = 1;
            this.txtUpdateIlanAciklama.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUpdateIlanAciklama.CustomButton.UseSelectable = true;
            this.txtUpdateIlanAciklama.CustomButton.Visible = false;
            this.txtUpdateIlanAciklama.Lines = new string[0];
            this.txtUpdateIlanAciklama.Location = new System.Drawing.Point(464, 227);
            this.txtUpdateIlanAciklama.MaxLength = 32767;
            this.txtUpdateIlanAciklama.Multiline = true;
            this.txtUpdateIlanAciklama.Name = "txtUpdateIlanAciklama";
            this.txtUpdateIlanAciklama.PasswordChar = '\0';
            this.txtUpdateIlanAciklama.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUpdateIlanAciklama.SelectedText = "";
            this.txtUpdateIlanAciklama.SelectionLength = 0;
            this.txtUpdateIlanAciklama.SelectionStart = 0;
            this.txtUpdateIlanAciklama.ShortcutsEnabled = true;
            this.txtUpdateIlanAciklama.Size = new System.Drawing.Size(187, 48);
            this.txtUpdateIlanAciklama.TabIndex = 68;
            this.txtUpdateIlanAciklama.UseSelectable = true;
            this.txtUpdateIlanAciklama.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUpdateIlanAciklama.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.White;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label15.Location = new System.Drawing.Point(361, 227);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(72, 17);
            this.label15.TabIndex = 67;
            this.label15.Text = "Açıklama :";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // nUdUpdateIlanNet
            // 
            this.nUdUpdateIlanNet.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.nUdUpdateIlanNet.Location = new System.Drawing.Point(464, 195);
            this.nUdUpdateIlanNet.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nUdUpdateIlanNet.Name = "nUdUpdateIlanNet";
            this.nUdUpdateIlanNet.Size = new System.Drawing.Size(104, 26);
            this.nUdUpdateIlanNet.TabIndex = 66;
            // 
            // nUdUpdateIlanBrut
            // 
            this.nUdUpdateIlanBrut.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.nUdUpdateIlanBrut.Location = new System.Drawing.Point(464, 163);
            this.nUdUpdateIlanBrut.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.nUdUpdateIlanBrut.Name = "nUdUpdateIlanBrut";
            this.nUdUpdateIlanBrut.Size = new System.Drawing.Size(104, 26);
            this.nUdUpdateIlanBrut.TabIndex = 65;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.White;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label16.Location = new System.Drawing.Point(361, 201);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(38, 17);
            this.label16.TabIndex = 61;
            this.label16.Text = "Net :";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.White;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label17.Location = new System.Drawing.Point(579, 200);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(72, 17);
            this.label17.TabIndex = 64;
            this.label17.Text = "metrekare";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.White;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.Location = new System.Drawing.Point(579, 168);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(72, 17);
            this.label18.TabIndex = 63;
            this.label18.Text = "metrekare";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.White;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label19.Location = new System.Drawing.Point(361, 168);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(42, 17);
            this.label19.TabIndex = 62;
            this.label19.Text = "Brüt :";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dTpUpdateIlanTarihi
            // 
            this.dTpUpdateIlanTarihi.Location = new System.Drawing.Point(463, 123);
            this.dTpUpdateIlanTarihi.MinimumSize = new System.Drawing.Size(0, 29);
            this.dTpUpdateIlanTarihi.Name = "dTpUpdateIlanTarihi";
            this.dTpUpdateIlanTarihi.Size = new System.Drawing.Size(188, 29);
            this.dTpUpdateIlanTarihi.TabIndex = 60;
            // 
            // cbUpdateIlanAltKategori
            // 
            this.cbUpdateIlanAltKategori.FormattingEnabled = true;
            this.cbUpdateIlanAltKategori.ItemHeight = 23;
            this.cbUpdateIlanAltKategori.Location = new System.Drawing.Point(124, 99);
            this.cbUpdateIlanAltKategori.Name = "cbUpdateIlanAltKategori";
            this.cbUpdateIlanAltKategori.Size = new System.Drawing.Size(178, 29);
            this.cbUpdateIlanAltKategori.TabIndex = 58;
            this.cbUpdateIlanAltKategori.UseSelectable = true;
            // 
            // cbUpdateIlanSemt
            // 
            this.cbUpdateIlanSemt.FormattingEnabled = true;
            this.cbUpdateIlanSemt.ItemHeight = 23;
            this.cbUpdateIlanSemt.Location = new System.Drawing.Point(124, 209);
            this.cbUpdateIlanSemt.Name = "cbUpdateIlanSemt";
            this.cbUpdateIlanSemt.Size = new System.Drawing.Size(178, 29);
            this.cbUpdateIlanSemt.TabIndex = 57;
            this.cbUpdateIlanSemt.UseSelectable = true;
            // 
            // cbUpdateIlanKategori
            // 
            this.cbUpdateIlanKategori.FormattingEnabled = true;
            this.cbUpdateIlanKategori.ItemHeight = 23;
            this.cbUpdateIlanKategori.Location = new System.Drawing.Point(124, 65);
            this.cbUpdateIlanKategori.Name = "cbUpdateIlanKategori";
            this.cbUpdateIlanKategori.Size = new System.Drawing.Size(178, 29);
            this.cbUpdateIlanKategori.TabIndex = 59;
            this.cbUpdateIlanKategori.UseSelectable = true;
            this.cbUpdateIlanKategori.SelectionChangeCommitted += new System.EventHandler(this.cbUpdateIlanKategori_SelectionChangeCommitted);
            // 
            // cbUpdateIlanIlceler
            // 
            this.cbUpdateIlanIlceler.FormattingEnabled = true;
            this.cbUpdateIlanIlceler.ItemHeight = 23;
            this.cbUpdateIlanIlceler.Location = new System.Drawing.Point(124, 174);
            this.cbUpdateIlanIlceler.Name = "cbUpdateIlanIlceler";
            this.cbUpdateIlanIlceler.Size = new System.Drawing.Size(178, 29);
            this.cbUpdateIlanIlceler.TabIndex = 56;
            this.cbUpdateIlanIlceler.UseSelectable = true;
            this.cbUpdateIlanIlceler.SelectionChangeCommitted += new System.EventHandler(this.cbUpdateIlanIlceler_SelectionChangeCommitted);
            // 
            // cbUpdateIlanTuru
            // 
            this.cbUpdateIlanTuru.FormattingEnabled = true;
            this.cbUpdateIlanTuru.ItemHeight = 23;
            this.cbUpdateIlanTuru.Location = new System.Drawing.Point(124, 27);
            this.cbUpdateIlanTuru.Name = "cbUpdateIlanTuru";
            this.cbUpdateIlanTuru.Size = new System.Drawing.Size(178, 29);
            this.cbUpdateIlanTuru.TabIndex = 55;
            this.cbUpdateIlanTuru.UseSelectable = true;
            this.cbUpdateIlanTuru.SelectionChangeCommitted += new System.EventHandler(this.cbUpdateIlanTuru_SelectionChangeCommitted);
            // 
            // cbUpdateIlanIller
            // 
            this.cbUpdateIlanIller.FormattingEnabled = true;
            this.cbUpdateIlanIller.ItemHeight = 23;
            this.cbUpdateIlanIller.Location = new System.Drawing.Point(124, 137);
            this.cbUpdateIlanIller.Name = "cbUpdateIlanIller";
            this.cbUpdateIlanIller.Size = new System.Drawing.Size(178, 29);
            this.cbUpdateIlanIller.TabIndex = 54;
            this.cbUpdateIlanIller.UseSelectable = true;
            this.cbUpdateIlanIller.SelectionChangeCommitted += new System.EventHandler(this.cbUpdateIlanIller_SelectionChangeCommitted);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.White;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label20.Location = new System.Drawing.Point(25, 106);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(89, 17);
            this.label20.TabIndex = 50;
            this.label20.Text = "Kategori Alt :";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtUpdateIlanNo
            // 
            // 
            // 
            // 
            this.txtUpdateIlanNo.CustomButton.Image = null;
            this.txtUpdateIlanNo.CustomButton.Location = new System.Drawing.Point(164, 2);
            this.txtUpdateIlanNo.CustomButton.Name = "";
            this.txtUpdateIlanNo.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtUpdateIlanNo.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUpdateIlanNo.CustomButton.TabIndex = 1;
            this.txtUpdateIlanNo.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUpdateIlanNo.CustomButton.UseSelectable = true;
            this.txtUpdateIlanNo.CustomButton.Visible = false;
            this.txtUpdateIlanNo.Enabled = false;
            this.txtUpdateIlanNo.Lines = new string[0];
            this.txtUpdateIlanNo.Location = new System.Drawing.Point(463, 91);
            this.txtUpdateIlanNo.MaxLength = 32767;
            this.txtUpdateIlanNo.Name = "txtUpdateIlanNo";
            this.txtUpdateIlanNo.PasswordChar = '\0';
            this.txtUpdateIlanNo.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUpdateIlanNo.SelectedText = "";
            this.txtUpdateIlanNo.SelectionLength = 0;
            this.txtUpdateIlanNo.SelectionStart = 0;
            this.txtUpdateIlanNo.ShortcutsEnabled = true;
            this.txtUpdateIlanNo.Size = new System.Drawing.Size(188, 26);
            this.txtUpdateIlanNo.TabIndex = 53;
            this.txtUpdateIlanNo.UseSelectable = true;
            this.txtUpdateIlanNo.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUpdateIlanNo.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.White;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.Location = new System.Drawing.Point(25, 214);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(48, 17);
            this.label21.TabIndex = 49;
            this.label21.Text = "Semt :";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.White;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label22.Location = new System.Drawing.Point(361, 131);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(78, 17);
            this.label22.TabIndex = 48;
            this.label22.Text = "İlan Tarihi :";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.White;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label23.Location = new System.Drawing.Point(25, 71);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(69, 17);
            this.label23.TabIndex = 47;
            this.label23.Text = "Kategori :";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.White;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label24.Location = new System.Drawing.Point(361, 99);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(60, 17);
            this.label24.TabIndex = 46;
            this.label24.Text = "İlan No :";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.White;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label25.Location = new System.Drawing.Point(25, 179);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(37, 17);
            this.label25.TabIndex = 45;
            this.label25.Text = "İlçe :";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.White;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label26.Location = new System.Drawing.Point(25, 36);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(46, 17);
            this.label26.TabIndex = 44;
            this.label26.Text = "Türü :";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtUpdateIlanTitle
            // 
            // 
            // 
            // 
            this.txtUpdateIlanTitle.CustomButton.Image = null;
            this.txtUpdateIlanTitle.CustomButton.Location = new System.Drawing.Point(164, 2);
            this.txtUpdateIlanTitle.CustomButton.Name = "";
            this.txtUpdateIlanTitle.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtUpdateIlanTitle.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUpdateIlanTitle.CustomButton.TabIndex = 1;
            this.txtUpdateIlanTitle.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUpdateIlanTitle.CustomButton.UseSelectable = true;
            this.txtUpdateIlanTitle.CustomButton.Visible = false;
            this.txtUpdateIlanTitle.Lines = new string[0];
            this.txtUpdateIlanTitle.Location = new System.Drawing.Point(463, 27);
            this.txtUpdateIlanTitle.MaxLength = 32767;
            this.txtUpdateIlanTitle.Name = "txtUpdateIlanTitle";
            this.txtUpdateIlanTitle.PasswordChar = '\0';
            this.txtUpdateIlanTitle.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUpdateIlanTitle.SelectedText = "";
            this.txtUpdateIlanTitle.SelectionLength = 0;
            this.txtUpdateIlanTitle.SelectionStart = 0;
            this.txtUpdateIlanTitle.ShortcutsEnabled = true;
            this.txtUpdateIlanTitle.Size = new System.Drawing.Size(188, 26);
            this.txtUpdateIlanTitle.TabIndex = 52;
            this.txtUpdateIlanTitle.UseSelectable = true;
            this.txtUpdateIlanTitle.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUpdateIlanTitle.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.White;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label27.Location = new System.Drawing.Point(27, 144);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(22, 17);
            this.label27.TabIndex = 51;
            this.label27.Text = "İl :";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.White;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label28.Location = new System.Drawing.Point(361, 32);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(79, 17);
            this.label28.TabIndex = 43;
            this.label28.Text = "İlan Başlık :";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // metroToolTip1
            // 
            this.metroToolTip1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroToolTip1.StyleManager = null;
            this.metroToolTip1.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // frmIlan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(687, 609);
            this.Controls.Add(this.metroTabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmIlan";
            this.Text = "İlan";
            this.Load += new System.EventHandler(this.frmIlan_Load);
            this.metroTabControl1.ResumeLayout(false);
            this.metroTabPage1.ResumeLayout(false);
            this.metroTabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGwIlanlar)).EndInit();
            this.contextMenuStripIlan.ResumeLayout(false);
            this.metroTabPage2.ResumeLayout(false);
            this.metroTabPage2.PerformLayout();
            this.metroTabControl2.ResumeLayout(false);
            this.metroTabPage7.ResumeLayout(false);
            this.metroTabPage7.PerformLayout();
            this.metroTabPage4.ResumeLayout(false);
            this.metroTabPage4.PerformLayout();
            this.metroTabPage5.ResumeLayout(false);
            this.metroTabPage5.PerformLayout();
            this.metroTabPage6.ResumeLayout(false);
            this.metroTabPage6.PerformLayout();
            this.metroTabPage12.ResumeLayout(false);
            this.metroTabPage12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nUdAddIlanNet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nUdAddIlanBrut)).EndInit();
            this.metroTabPage3.ResumeLayout(false);
            this.metroTabPage3.PerformLayout();
            this.metroTabControl3.ResumeLayout(false);
            this.metroTabPage8.ResumeLayout(false);
            this.metroTabPage8.PerformLayout();
            this.metroTabPage9.ResumeLayout(false);
            this.metroTabPage9.PerformLayout();
            this.metroTabPage10.ResumeLayout(false);
            this.metroTabPage10.PerformLayout();
            this.metroTabPage11.ResumeLayout(false);
            this.metroTabPage11.PerformLayout();
            this.metroTabPage13.ResumeLayout(false);
            this.metroTabPage13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nUdUpdateIlanNet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nUdUpdateIlanBrut)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroTabPage metroTabPage1;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private MetroFramework.Controls.MetroTabPage metroTabPage3;
        private System.Windows.Forms.DataGridView dGwIlanlar;
        private MetroFramework.Controls.MetroTextBox txtSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripIlan;
        private System.Windows.Forms.ToolStripMenuItem güncelleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem silToolStripMenuItem;
        private System.Windows.Forms.Label lblAdi;
        private MetroFramework.Controls.MetroTextBox txtAddTitle;
        private MetroFramework.Controls.MetroTextBox txtAddIlanNo;
        private System.Windows.Forms.Label label2;
        private MetroFramework.Controls.MetroComboBox cbAddIller;
        private System.Windows.Forms.Label label3;
        private MetroFramework.Controls.MetroComboBox cbAddSemtler;
        private MetroFramework.Controls.MetroComboBox cbAddIlceler;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private MetroFramework.Controls.MetroDateTime dTpAddIlanTarihi;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown nUdAddIlanNet;
        private System.Windows.Forms.NumericUpDown nUdAddIlanBrut;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private MetroFramework.Controls.MetroTextBox txtAddIlanAciklama;
        private System.Windows.Forms.Label label11;
        private MetroFramework.Controls.MetroComboBox cbAddAltKategori;
        private MetroFramework.Controls.MetroComboBox cbAddKategori;
        private MetroFramework.Controls.MetroComboBox cbAddIlanTuru;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private MetroFramework.Controls.MetroTabControl metroTabControl2;
        private MetroFramework.Controls.MetroTabPage metroTabPage4;
        private MetroFramework.Controls.MetroTabPage metroTabPage5;
        private MetroFramework.Controls.MetroTabPage metroTabPage6;
        private MetroFramework.Controls.MetroTabPage metroTabPage7;
        private MetroFramework.Controls.MetroButton btnAdd;
        private MetroFramework.Controls.MetroButton btnUpdate;
        private MetroFramework.Controls.MetroTabControl metroTabControl3;
        private MetroFramework.Controls.MetroTabPage metroTabPage8;
        private MetroFramework.Controls.MetroTabPage metroTabPage9;
        private MetroFramework.Controls.MetroTabPage metroTabPage10;
        private MetroFramework.Controls.MetroTabPage metroTabPage11;
        private MetroFramework.Controls.MetroTextBox txtUpdateIlanAciklama;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.NumericUpDown nUdUpdateIlanNet;
        private System.Windows.Forms.NumericUpDown nUdUpdateIlanBrut;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private MetroFramework.Controls.MetroDateTime dTpUpdateIlanTarihi;
        private MetroFramework.Controls.MetroComboBox cbUpdateIlanAltKategori;
        private MetroFramework.Controls.MetroComboBox cbUpdateIlanSemt;
        private MetroFramework.Controls.MetroComboBox cbUpdateIlanKategori;
        private MetroFramework.Controls.MetroComboBox cbUpdateIlanIlceler;
        private MetroFramework.Controls.MetroComboBox cbUpdateIlanTuru;
        private MetroFramework.Controls.MetroComboBox cbUpdateIlanIller;
        private System.Windows.Forms.Label label20;
        private MetroFramework.Controls.MetroTextBox txtUpdateIlanNo;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private MetroFramework.Controls.MetroTextBox txtUpdateIlanTitle;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ToolStripMenuItem önizlemeToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private MetroFramework.Controls.MetroTabPage metroTabPage12;
        private System.Windows.Forms.FlowLayoutPanel fLpAddResimler;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private MetroFramework.Controls.MetroTabPage metroTabPage13;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.FlowLayoutPanel fLpUpdateResimler;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label lblToplam;
        private System.Windows.Forms.Label label33;
        private MetroFramework.Controls.MetroComboBox cbAddIlanVeren;
        private System.Windows.Forms.Label label34;
        private MetroFramework.Controls.MetroButton btnAddResimEkle;
        private MetroFramework.Controls.MetroButton btnUpdateResimEkle;
        private MetroFramework.Controls.MetroComboBox cbUpdateIlanVeren;
        private System.Windows.Forms.Label label35;
        private MetroFramework.Controls.MetroTextBox txtAddDisName;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroButton btnAddDisSil;
        private MetroFramework.Controls.MetroButton btnAddDisGüncelle;
        private MetroFramework.Controls.MetroButton btnAddDisEkle;
        private System.Windows.Forms.ListBox lstAddDisOzellikler;
        private MetroFramework.Controls.MetroTextBox txtAddIcName;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroButton btnAddIcSil;
        private MetroFramework.Controls.MetroButton btnAddIcGuncelle;
        private MetroFramework.Controls.MetroButton btnAddIcEkle;
        private System.Windows.Forms.ListBox lstAddIcOzellikler;
        private MetroFramework.Controls.MetroTextBox txtAddKonumName;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroButton btnAddKonumSil;
        private MetroFramework.Controls.MetroButton btnAddKonumGuncelle;
        private MetroFramework.Controls.MetroButton btnAddKonumEkle;
        private System.Windows.Forms.ListBox lstAddKonumOzellikler;
        private MetroFramework.Controls.MetroTextBox txtAddEkOzellikAciklama;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroTextBox txtAddEkOzellikName;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroButton btnAddEkOzellikSil;
        private MetroFramework.Controls.MetroButton btnAddEkOzellikGuncelle;
        private MetroFramework.Controls.MetroButton btnAddEkOzellikEkle;
        private System.Windows.Forms.ListBox lstAddEkOzellikler;
        private System.Windows.Forms.ListBox lstUpdateEkOzellikler;
        private MetroFramework.Controls.MetroButton btnUpdateEkOzellikSil;
        private MetroFramework.Controls.MetroButton btnUpdateEkOzellikGuncelle;
        private MetroFramework.Controls.MetroButton btnUpdateEkOzellikEkle;
        private MetroFramework.Controls.MetroTextBox txtUpdateEkOzellikAciklama;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroTextBox txtUpdateEkOzellikName;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private System.Windows.Forms.ListBox lstUpdateDisOzellikler;
        private MetroFramework.Controls.MetroButton btnUpdateDisSil;
        private MetroFramework.Controls.MetroButton btnUpdateDisGuncelle;
        private MetroFramework.Controls.MetroButton btnUpdateDisEkle;
        private MetroFramework.Controls.MetroTextBox txtUpdateDisName;
        private MetroFramework.Controls.MetroLabel metroLabel8;
        private System.Windows.Forms.ListBox lstUpdateIcOzellikler;
        private MetroFramework.Controls.MetroButton btnUpdateIcSil;
        private MetroFramework.Controls.MetroButton btnUpdateIcGuncelle;
        private MetroFramework.Controls.MetroButton btnUpdateIcEkle;
        private MetroFramework.Controls.MetroTextBox txtUpdateIcOzellikName;
        private MetroFramework.Controls.MetroLabel metroLabel9;
        private System.Windows.Forms.ListBox lstUpdateKonumOzellikler;
        private MetroFramework.Controls.MetroButton btnUpdateKonumSil;
        private MetroFramework.Controls.MetroButton btnUpdateKonumGuncelle;
        private MetroFramework.Controls.MetroButton btnUpdateKonumEkle;
        private MetroFramework.Controls.MetroTextBox txtUpdateKonumName;
        private MetroFramework.Controls.MetroLabel metroLabel10;
        private MetroFramework.Controls.MetroButton brnUpdateResimCikar;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.HelpProvider helpProvider1;
        private MetroFramework.Components.MetroToolTip metroToolTip1;
        private MetroFramework.Controls.MetroButton btnAddResimSil;
        private MetroFramework.Controls.MetroTextBox txtAddFiyat;
        private System.Windows.Forms.Label label36;
        private MetroFramework.Controls.MetroTextBox txtUpdateFiyat;
        private System.Windows.Forms.Label label37;
    }
}