﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Controls;

namespace Emlak_Yonetim_Sistemi_Projesi.Forms
{
    public partial class frmKategori : Form
    {
        public frmKategori()
        {
            InitializeComponent();
        }
        EmlakContext db = new EmlakContext();
        int secilenID;
        private void frmKategori_Load(object sender, EventArgs e)
        {
            metroTabControl1.SelectedIndex = 0;
            // Kategori
            TumKategorileriGetir(); // metodu altta...
            TurlerComboxiDoldur(cbTurler); // Türleri combobox'a doldurur ...
            //---------------------------
            // Alt Kategori
            TumAltKategorileriGetir();// metodu altta...
            TurlerComboxiDoldur(cbAltTurler); // Türleri combobox'a doldurur ...
        }


        private void TumKategorileriGetir()
        {
            lstKategoriler.Items.Clear();

            var catList = db.Kategoriler.OrderBy(ct => ct.KategoriAdi).ToList();

            foreach (Kategori cat in catList)
            {
                lstKategoriler.Items.Add(cat);
                lstKategoriler.DisplayMember = "KategoriAdi";
            }
            lblToplam.Text = "Toplam = " + lstKategoriler.Items.Count.ToString();
        }
        
        private void TumAltKategorileriGetir()
        {
            lstAltKategoriler.Items.Clear();

            var altCatList = db.AltKategorileri.OrderBy(a=>a.AltKategoriAdi).ToList();

            foreach (AltKategori altcat in altCatList)
            {
                lstAltKategoriler.Items.Add(altcat);
                lstAltKategoriler.DisplayMember = "AltKategoriAdi";
            }
            lblToplamAlt.Text = "Toplam = " + lstAltKategoriler.Items.Count.ToString();
        }
        

        private void TurlerComboxiDoldur(MetroComboBox cb)
        {
            cb.DataSource = db.IlanTurleri.OrderBy(t => t.IlanTuruAdi).ToList();
            cb.DisplayMember = "IlanTuruAdi";
            cb.ValueMember = "IlanTuruID";
        }

        #region Kategori

        private void cbTurler_SelectionChangeCommitted(object sender, EventArgs e)
        {
            KategorileriGetir();
            Temizle();
        }

        private void lstKategoriler_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstKategoriler.SelectedItem != null)
            {
                Kategori kategori = lstKategoriler.SelectedItem as Kategori;
                secilenID = Convert.ToInt32(kategori.KategoriID);

                txtName.Text = kategori.KategoriAdi;
                cbTurler.SelectedValue = kategori.IlanTuruID;
            }
        }
        //----------------------
        // Ekle
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Kategori cat = new Kategori();

                cat.KategoriAdi = txtName.Text;
                cat.IlanTuruID = (int)cbTurler.SelectedValue;

                if (txtName.Text == "" || cbTurler.SelectedItem == null)
                {
                    frmCustomMsgBx.Show("Lütfen Tüm Alanları Doldurunuz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                db.Kategoriler.Add(cat);
                db.SaveChanges();

                KategorileriGetir(); // Kategorileri listbox'a doldur. Metodu altta ...

            Temizle();
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //----------------------
        // Güncelle
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstKategoriler.SelectedItem == null)
                {
                    frmCustomMsgBx.Show("Lütfen Bir Kategori Seçiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                Kategori cat = db.Kategoriler.Find(secilenID);
                cat.KategoriAdi = txtName.Text;
                cat.IlanTuruID = (int)cbTurler.SelectedValue;

                if (txtName.Text == "" || cbTurler.SelectedItem == null)
                {
                    frmCustomMsgBx.Show("Lütfen Tüm Alanları Doldurunuz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                db.SaveChanges();

                KategorileriGetir(); // Kategorileri listbox'a doldur. Metodu altta ...

                Temizle();
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }

        //----------------------
        // Sil
        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstKategoriler.SelectedItem == null)
                {
                    frmCustomMsgBx.Show("Lütfen Bir Kategori Seçiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                Kategori cat = db.Kategoriler.Find(secilenID);
                if (frmCustomMsgBx.Show("Silmek İstediğinize Emin Misiniz?", frmCustomMsgBx.CustomMsgbxButtons.YesNo) == DialogResult.Yes)
                {
                    db.Kategoriler.Remove(cat);
                    db.SaveChanges();
                }
                KategorileriGetir(); // Kategorileri listbox'a doldur. Metodu altta ...

                Temizle();
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //----------------------
        // Temizle
        private void btnClear_Click(object sender, EventArgs e)
        {
            Temizle();
        }

        private void KategorileriGetir()
        {
            lstKategoriler.Items.Clear();

            var catList = db.Kategoriler.Where(c => c.IlanTuruID == (int)cbTurler.SelectedValue).ToList();

            foreach (Kategori ct in catList)
            {
                lstKategoriler.Items.Add(ct);
                lstKategoriler.DisplayMember = "KategoriAdi";
            }
            lblToplam.Text = "Toplam = " + lstKategoriler.Items.Count.ToString();
        }

        #endregion

        //------------------------------------------------------------------------------------------------

        #region Alt Kategori

        private void cbAltTurler_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cbKategoriler.SelectedIndex = -1;
            int id = (int)cbAltTurler.SelectedValue;
            KategoriComboxiDoldur(cbKategoriler,id); // Seçilen İlan Türüne göre , metodu altta
            Temizle();
        }

        private void cbKategoriler_SelectionChangeCommitted(object sender, EventArgs e)
        {
            AltKategorileriGetir(); // Seçilen Kategoriye göre , metodu altta
            Temizle();
        }

        private void AltKategorileriGetir()
        {
            lstAltKategoriler.Items.Clear();

            var altCats = db.AltKategorileri.Where(alt=>alt.KategoriID == (int)cbKategoriler.SelectedValue).ToList();

            foreach (AltKategori acat in altCats)
            {
                lstAltKategoriler.Items.Add(acat);
                lstAltKategoriler.DisplayMember = "AltKategoriAdi";

            }
            lblToplamAlt.Text = "Toplam = " + lstAltKategoriler.Items.Count.ToString();
        }

        private void lstAltKategoriler_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstAltKategoriler.SelectedItem != null)
            {
                AltKategori secilenItem = lstAltKategoriler.SelectedItem as AltKategori;

                secilenID = Convert.ToInt32(secilenItem.AltKategoriID);

                cbKategoriler.SelectedValue = secilenItem.KategoriID;
                cbAltTurler.SelectedValue = db.Kategoriler.Find(secilenItem.KategoriID).IlanTuruID;
                txtAltName.Text = secilenItem.AltKategoriAdi;
            }
        }
        //----------------------
        // Ekle
        private void btnAltAdd_Click(object sender, EventArgs e)
        {
            try
            {
                AltKategori acat = new AltKategori();

                acat.AltKategoriAdi = txtAltName.Text;
                acat.KategoriID = (int)cbKategoriler.SelectedValue;

                if (txtAltName.Text == "" || cbAltTurler.SelectedItem == null || cbKategoriler.SelectedItem == null)
                {
                    frmCustomMsgBx.Show("Lütfen Tüm Alanları Doldurunuz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                db.AltKategorileri.Add(acat);
                db.SaveChanges();

                AltKategorileriGetir();
                Temizle();
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //----------------------
        // Güncelle
        private void btnAltUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstAltKategoriler.SelectedItem == null)
                {
                    frmCustomMsgBx.Show("Lütfen Bir Alt Kategori Seçiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }
                AltKategori acat = db.AltKategorileri.Find(secilenID);

                acat.AltKategoriAdi = txtAltName.Text;
                acat.KategoriID = (int)cbKategoriler.SelectedValue;

                if (txtAltName.Text == "" || cbAltTurler.SelectedItem == null || cbKategoriler.SelectedItem == null)
                {
                    frmCustomMsgBx.Show("Lütfen Tüm Alanları Doldurunuz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                
                db.SaveChanges();

                AltKategorileriGetir();
                Temizle();
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //----------------------
        // Sil
        private void btnAltDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstAltKategoriler.SelectedItem == null)
                {
                    frmCustomMsgBx.Show("Lütfen Bir Alt Kategori Seçiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }
                AltKategori acat = db.AltKategorileri.Find(secilenID);

                if (frmCustomMsgBx.Show("Silmek İstediğinize Emin Misiniz?", frmCustomMsgBx.CustomMsgbxButtons.YesNo) == DialogResult.Yes)
                {
                    db.AltKategorileri.Remove(acat);
                    db.SaveChanges();
                }
                AltKategorileriGetir();
                Temizle();
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //----------------------
        // Temizle
        private void btnAltClear_Click(object sender, EventArgs e)
        {
            Temizle();
        }

        #endregion

        //------------------------------------------------------------------------------------------------

        private void KategoriComboxiDoldur(MetroComboBox cbCat, int id)
        {
            var list = db.Kategoriler.Where(c => c.IlanTuruID == id).OrderBy(c => c.KategoriAdi).ToList();
            cbCat.DataSource = list;
            cbCat.DisplayMember = "KategoriAdi";
            cbCat.ValueMember = "KategoriID";
        }

        private void Temizle()
        {
            txtName.Clear();
            txtAltName.Clear();

            lstKategoriler.SelectedIndex = -1;
            lstAltKategoriler.SelectedIndex = -1;

            secilenID = 0;
        }

        private void metroTabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Kategori
            TumKategorileriGetir(); // metodu altta...
            TurlerComboxiDoldur(cbTurler); // Türleri combobox'a doldurur ...
            //---------------------------
            // Alt Kategori
            TumAltKategorileriGetir();// metodu altta...
            TurlerComboxiDoldur(cbAltTurler); // Türleri combobox'a doldurur ...

            // Combobox'ların seçilenini kaldırma
            cbTurler.SelectedIndex = -1;
            cbKategoriler.SelectedIndex = -1;
            cbAltTurler.SelectedIndex = -1;
        }
    }
}
