﻿namespace Emlak_Yonetim_Sistemi_Projesi.Forms
{
    partial class frmOnizleme
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fLpOzellikler = new System.Windows.Forms.FlowLayoutPanel();
            this.fLpKategoriOzellik = new System.Windows.Forms.FlowLayoutPanel();
            this.lblNetMetreKare = new System.Windows.Forms.Label();
            this.lblNav = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblBrutMetre = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblIlanTarih = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblIlanVerenAdi = new System.Windows.Forms.Label();
            this.lblAdres = new System.Windows.Forms.Label();
            this.lblAciklama = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblIlanNo = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblFiyat = new System.Windows.Forms.Label();
            this.fLpSlayt = new System.Windows.Forms.FlowLayoutPanel();
            this.btnClose = new MetroFramework.Controls.MetroButton();
            this.pbIlanVerenResim = new System.Windows.Forms.PictureBox();
            this.pbMainPic = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbIlanVerenResim)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMainPic)).BeginInit();
            this.SuspendLayout();
            // 
            // fLpOzellikler
            // 
            this.fLpOzellikler.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fLpOzellikler.AutoScroll = true;
            this.fLpOzellikler.BackColor = System.Drawing.Color.Transparent;
            this.fLpOzellikler.Location = new System.Drawing.Point(29, 548);
            this.fLpOzellikler.Name = "fLpOzellikler";
            this.fLpOzellikler.Size = new System.Drawing.Size(543, 156);
            this.fLpOzellikler.TabIndex = 44;
            // 
            // fLpKategoriOzellik
            // 
            this.fLpKategoriOzellik.AutoScroll = true;
            this.fLpKategoriOzellik.BackColor = System.Drawing.Color.Transparent;
            this.fLpKategoriOzellik.Location = new System.Drawing.Point(353, 295);
            this.fLpKategoriOzellik.Name = "fLpKategoriOzellik";
            this.fLpKategoriOzellik.Size = new System.Drawing.Size(213, 125);
            this.fLpKategoriOzellik.TabIndex = 43;
            // 
            // lblNetMetreKare
            // 
            this.lblNetMetreKare.AutoSize = true;
            this.lblNetMetreKare.BackColor = System.Drawing.Color.Transparent;
            this.lblNetMetreKare.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblNetMetreKare.Location = new System.Drawing.Point(457, 271);
            this.lblNetMetreKare.Name = "lblNetMetreKare";
            this.lblNetMetreKare.Size = new System.Drawing.Size(53, 15);
            this.lblNetMetreKare.TabIndex = 41;
            this.lblNetMetreKare.Text = "net previ";
            // 
            // lblNav
            // 
            this.lblNav.AutoSize = true;
            this.lblNav.BackColor = System.Drawing.Color.Transparent;
            this.lblNav.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblNav.Location = new System.Drawing.Point(24, 63);
            this.lblNav.Name = "lblNav";
            this.lblNav.Size = new System.Drawing.Size(65, 15);
            this.lblNav.TabIndex = 40;
            this.lblNav.Text = "Navigation";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(350, 271);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(91, 15);
            this.label3.TabIndex = 39;
            this.label3.Text = "Net Metrekare :";
            // 
            // lblBrutMetre
            // 
            this.lblBrutMetre.AutoSize = true;
            this.lblBrutMetre.BackColor = System.Drawing.Color.Transparent;
            this.lblBrutMetre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblBrutMetre.Location = new System.Drawing.Point(457, 253);
            this.lblBrutMetre.Name = "lblBrutMetre";
            this.lblBrutMetre.Size = new System.Drawing.Size(28, 15);
            this.lblBrutMetre.TabIndex = 38;
            this.lblBrutMetre.Text = "brüt";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(350, 253);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 15);
            this.label2.TabIndex = 37;
            this.label2.Text = "Bürüt Metrekare :";
            // 
            // lblIlanTarih
            // 
            this.lblIlanTarih.AutoSize = true;
            this.lblIlanTarih.BackColor = System.Drawing.Color.Transparent;
            this.lblIlanTarih.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblIlanTarih.Location = new System.Drawing.Point(457, 233);
            this.lblIlanTarih.Name = "lblIlanTarih";
            this.lblIlanTarih.Size = new System.Drawing.Size(35, 15);
            this.lblIlanTarih.TabIndex = 36;
            this.lblIlanTarih.Text = "Tarih";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(350, 234);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 42;
            this.label1.Text = "İlan Tarihi :";
            // 
            // lblIlanVerenAdi
            // 
            this.lblIlanVerenAdi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblIlanVerenAdi.Location = new System.Drawing.Point(583, 246);
            this.lblIlanVerenAdi.Name = "lblIlanVerenAdi";
            this.lblIlanVerenAdi.Size = new System.Drawing.Size(173, 31);
            this.lblIlanVerenAdi.TabIndex = 35;
            this.lblIlanVerenAdi.Text = "İlan Veren";
            this.lblIlanVerenAdi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAdres
            // 
            this.lblAdres.BackColor = System.Drawing.SystemColors.Control;
            this.lblAdres.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAdres.Location = new System.Drawing.Point(346, 172);
            this.lblAdres.Name = "lblAdres";
            this.lblAdres.Size = new System.Drawing.Size(221, 42);
            this.lblAdres.TabIndex = 34;
            this.lblAdres.Text = "Adres";
            this.lblAdres.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblAciklama
            // 
            this.lblAciklama.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblAciklama.BackColor = System.Drawing.Color.Transparent;
            this.lblAciklama.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblAciklama.Location = new System.Drawing.Point(25, 457);
            this.lblAciklama.Name = "lblAciklama";
            this.lblAciklama.Size = new System.Drawing.Size(543, 75);
            this.lblAciklama.TabIndex = 33;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(26, 435);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 22);
            this.label6.TabIndex = 32;
            this.label6.Text = "Açıklama :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblIlanNo
            // 
            this.lblIlanNo.BackColor = System.Drawing.Color.Transparent;
            this.lblIlanNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblIlanNo.Location = new System.Drawing.Point(345, 130);
            this.lblIlanNo.Name = "lblIlanNo";
            this.lblIlanNo.Size = new System.Drawing.Size(221, 42);
            this.lblIlanNo.TabIndex = 31;
            this.lblIlanNo.Text = "İlan No :";
            this.lblIlanNo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTitle
            // 
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblTitle.Location = new System.Drawing.Point(12, 17);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(744, 35);
            this.lblTitle.TabIndex = 30;
            this.lblTitle.Text = "Başlık";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblFiyat
            // 
            this.lblFiyat.BackColor = System.Drawing.SystemColors.Control;
            this.lblFiyat.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lblFiyat.Location = new System.Drawing.Point(345, 88);
            this.lblFiyat.Name = "lblFiyat";
            this.lblFiyat.Size = new System.Drawing.Size(221, 42);
            this.lblFiyat.TabIndex = 29;
            this.lblFiyat.Text = "Fiyat";
            this.lblFiyat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // fLpSlayt
            // 
            this.fLpSlayt.Location = new System.Drawing.Point(24, 335);
            this.fLpSlayt.Name = "fLpSlayt";
            this.fLpSlayt.Size = new System.Drawing.Size(306, 85);
            this.fLpSlayt.TabIndex = 28;
            // 
            // btnClose
            // 
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.Red;
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(751, 13);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(26, 23);
            this.btnClose.TabIndex = 45;
            this.btnClose.Text = "X";
            this.btnClose.UseCustomBackColor = true;
            this.btnClose.UseCustomForeColor = true;
            this.btnClose.UseSelectable = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // pbIlanVerenResim
            // 
            this.pbIlanVerenResim.Location = new System.Drawing.Point(583, 88);
            this.pbIlanVerenResim.Name = "pbIlanVerenResim";
            this.pbIlanVerenResim.Size = new System.Drawing.Size(173, 155);
            this.pbIlanVerenResim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbIlanVerenResim.TabIndex = 27;
            this.pbIlanVerenResim.TabStop = false;
            // 
            // pbMainPic
            // 
            this.pbMainPic.Location = new System.Drawing.Point(24, 88);
            this.pbMainPic.Name = "pbMainPic";
            this.pbMainPic.Size = new System.Drawing.Size(306, 241);
            this.pbMainPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbMainPic.TabIndex = 26;
            this.pbMainPic.TabStop = false;
            // 
            // frmOnizleme
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(800, 750);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.fLpOzellikler);
            this.Controls.Add(this.fLpKategoriOzellik);
            this.Controls.Add(this.lblNetMetreKare);
            this.Controls.Add(this.lblNav);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblBrutMetre);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblIlanTarih);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblIlanVerenAdi);
            this.Controls.Add(this.lblAdres);
            this.Controls.Add(this.lblAciklama);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lblIlanNo);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblFiyat);
            this.Controls.Add(this.fLpSlayt);
            this.Controls.Add(this.pbIlanVerenResim);
            this.Controls.Add(this.pbMainPic);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmOnizleme";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmOnizleme";
            this.Load += new System.EventHandler(this.frmOnizleme_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbIlanVerenResim)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbMainPic)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel fLpOzellikler;
        private System.Windows.Forms.FlowLayoutPanel fLpKategoriOzellik;
        private System.Windows.Forms.Label lblNetMetreKare;
        private System.Windows.Forms.Label lblNav;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblBrutMetre;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblIlanTarih;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblIlanVerenAdi;
        private System.Windows.Forms.Label lblAdres;
        private System.Windows.Forms.Label lblAciklama;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblIlanNo;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblFiyat;
        private System.Windows.Forms.FlowLayoutPanel fLpSlayt;
        private System.Windows.Forms.PictureBox pbIlanVerenResim;
        private System.Windows.Forms.PictureBox pbMainPic;
        private MetroFramework.Controls.MetroButton btnClose;
    }
}