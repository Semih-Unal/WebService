﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework.Controls;

namespace Emlak_Yonetim_Sistemi_Projesi.Forms
{
    public partial class frmIlan : Form
    {
        public frmIlan()
        {
            InitializeComponent();
        }

        EmlakContext db = new EmlakContext();
        int secilenID;
        bool contextmenu = false;

        private void frmIlan_Load(object sender, EventArgs e)
        {
            metroTabControl1.SelectedIndex = 0;
            metroTabControl2.SelectedIndex = 0;
            Listele();
            TurleriGetir(cbAddIlanTuru);
            IlleriGetir(cbAddIller);
            IlanVerenleriGetir(cbAddIlanVeren);
        }

        private void Listele()
        {
            var ilanLists = db.Ilanlar.Select(i => new
            {
                i.IlanID,
                ilanAdi= i.IlanAdi,
                No = i.IlanNo,
                Tarih = i.IlanTarihi,
                ilanVeren = i.ilanVeren.IlanVerenSirket,
                i.Aciklama
            }).ToList();

            dGwIlanlar.DataSource = ilanLists;
            lblToplam.Text = dGwIlanlar.Rows.Count.ToString();
        }


        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            var ilanLists = db.Ilanlar.Where(i=>i.IlanAdi.Contains(txtSearch.Text)).Select(i => new
            {
                i.IlanID,
                ilanAdi = i.IlanAdi,
                No = i.IlanNo,
                Tarih = i.IlanTarihi,
                ilanVeren = i.ilanVeren.IlanVerenSirket,
                i.Aciklama
            }).ToList();

            dGwIlanlar.DataSource = ilanLists;
            lblToplam.Text = dGwIlanlar.Rows.Count.ToString();
        }

        #region Combobox Commited Ekle için

        // Ekle İlan Türü
        private void cbAddIlanTuru_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cbAddKategori.SelectedIndex = -1;
            KategorileriGetir(cbAddKategori, (int)cbAddIlanTuru.SelectedValue); // Türe göre , metodu altta
        }
        // Ekle Kategori
        private void cbAddKategori_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cbAddAltKategori.SelectedIndex = -1;
            AltKategorileriGetir(cbAddAltKategori, (int)cbAddKategori.SelectedValue); // kategoriye göre, metodu altta
        }

        // Ekle İl
        private void cbAddIller_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cbAddIlceler.SelectedIndex = -1;
            IlceleriGetir(cbAddIlceler, (int)cbAddIller.SelectedValue); // İllere göre, metodu altta
        }
        // Ekle İlçe
        private void cbAddIlceler_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cbAddSemtler.SelectedIndex = -1;
            SemtleriGetir(cbAddSemtler, (int)cbAddIlceler.SelectedValue); // İlçelere göre, metodu altta
        }

        // Güncelle Türü
        private void cbUpdateIlanTuru_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cbUpdateIlanKategori.SelectedIndex = -1;
            KategorileriGetir(cbUpdateIlanKategori, (int)cbUpdateIlanTuru.SelectedValue); // Türe göre , metodu altta
        }
        // Güncelle Kategori
        private void cbUpdateIlanKategori_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cbUpdateIlanAltKategori.SelectedIndex = -1;
            AltKategorileriGetir(cbUpdateIlanAltKategori, (int)cbUpdateIlanKategori.SelectedValue); // kategoriye göre, metodu altta
        }
        // Güncelle İl
        private void cbUpdateIlanIller_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cbUpdateIlanIlceler.SelectedIndex = -1;
            IlceleriGetir(cbUpdateIlanIlceler, (int)cbUpdateIlanIller.SelectedValue); // İllere göre, metodu altta
        }
        // Güncelle İlçe
        private void cbUpdateIlanIlceler_SelectionChangeCommitted(object sender, EventArgs e)
        {
            cbUpdateIlanSemt.SelectedIndex = -1;
            SemtleriGetir(cbUpdateIlanSemt, (int)cbUpdateIlanIlceler.SelectedValue); // İlçelere göre, metodu altta
        }
        #endregion

        #region Combobox metotları
        // Tür
        private void TurleriGetir(MetroComboBox cb)
        {
            cb.DataSource = db.IlanTurleri.OrderBy(t => t.IlanTuruAdi).ToList();
            cb.DisplayMember = "IlanTuruAdi";
            cb.ValueMember = "IlanTuruID";
        }
        // Kategori
        private void KategorileriGetir(MetroComboBox cb, int id)
        {
            cb.DataSource = db.Kategoriler.Where(cat => cat.IlanTuruID == id).OrderBy(cat => cat.KategoriAdi).ToList();
            cb.DisplayMember = "KategoriAdi";
            cb.ValueMember = "KategoriID";
        }
        // Alt Kategori
        private void AltKategorileriGetir(MetroComboBox cb, int id)
        {
            cb.DataSource = db.AltKategorileri.Where(cat => cat.KategoriID == id).OrderBy(cat => cat.AltKategoriAdi).ToList();
            cb.DisplayMember = "AltKategoriAdi";
            cb.ValueMember = "AltKategoriID";
        }

        //--------------------------------------------

        // İl
        private void IlleriGetir(MetroComboBox cb)
        {
            cb.DataSource = db.Iller.OrderBy(i => i.IlAdi).ToList();
            cb.DisplayMember = "IlAdi";
            cb.ValueMember = "IlID";
        }
        // İlçe
        private void IlceleriGetir(MetroComboBox cb, int id)
        {
            cb.DataSource = db.Ilceler.Where(ilce => ilce.IlID == id).OrderBy(ilce => ilce.IlceAdi).ToList();
            cb.DisplayMember = "IlceAdi";
            cb.ValueMember = "IlceID";
        }
        // Semt
        private void SemtleriGetir(MetroComboBox cb, int id)
        {
            cb.DataSource = db.Semtler.Where(semt => semt.IlceID == id).OrderBy(semt => semt.SemtAdi).ToList();
            cb.DisplayMember = "SemtAdi";
            cb.ValueMember = "SemtID";
        }

        //---------------------------------------------
        // İlan Verenler
        private void IlanVerenleriGetir(MetroComboBox cb)
        {
            cb.DataSource = db.IlanVerenler.OrderBy(i => i.IlanVerenSirket).ToList();
            cb.DisplayMember = "IlanVerenSirket";
            cb.ValueMember = "IlanVerenID";
        }
        #endregion
        // -------------------------------------

        #region Ekleme

        #region Ek Özellik

        private void lstAddEkOzellikler_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstAddEkOzellikler.SelectedIndex != -1)
            {
                Ozellik ozellik = lstAddEkOzellikler.SelectedItem as Ozellik;

                txtAddEkOzellikName.Text = ozellik.Adi;
                txtAddEkOzellikAciklama.Text = ozellik.Aciklama;
            }
           
        }
        //-----------------
        // Ekle
        private void btnAddEkOzellikEkle_Click(object sender, EventArgs e)
        {
            if (txtAddEkOzellikName.Text != "" && txtAddEkOzellikAciklama.Text != "")
            {
                Ozellik ozellik = new Ozellik();
                ozellik.Adi = txtAddEkOzellikName.Text;
                ozellik.Aciklama = txtAddEkOzellikAciklama.Text;
                lstAddEkOzellikler.Items.Add(ozellik);

                txtAddEkOzellikName.Clear();
                txtAddEkOzellikAciklama.Clear();
                txtAddEkOzellikName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Alanları Doldurunuz!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //-----------------
        // Güncelle
        private void btnAddEkOzellikGuncelle_Click(object sender, EventArgs e)
        {
            if (lstAddEkOzellikler.SelectedIndex == -1)
            {
                frmCustomMsgBx.Show("Güncellemek İstediğiniz Veriyi Seçin!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                return;
            }
            if (txtAddEkOzellikName.Text != "" && txtAddEkOzellikAciklama.Text != "")
            {
                int index = lstAddEkOzellikler.SelectedIndex;
                lstAddEkOzellikler.Items.RemoveAt(index);

                Ozellik ozellik = new Ozellik();
                ozellik.Adi = txtAddEkOzellikName.Text;
                ozellik.Aciklama = txtAddEkOzellikAciklama.Text;

                lstAddEkOzellikler.Items.Insert(index, ozellik);

                txtAddEkOzellikName.Clear();
                txtAddEkOzellikAciklama.Clear();
                txtAddEkOzellikName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Alanları Doldurunuz!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //-----------------
        // Çıkar
        private void btnAddEkOzellikSil_Click(object sender, EventArgs e)
        {
            if (lstAddEkOzellikler.SelectedIndex > -1)
            {
                int index = lstAddEkOzellikler.SelectedIndex;
                lstAddEkOzellikler.Items.RemoveAt(index);

                txtAddEkOzellikName.Clear();
                txtAddEkOzellikAciklama.Clear();
                txtAddEkOzellikName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Silmek İstediğiniz Veriyi Seçin!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        #endregion
        //--------------------------------------
        #region Dış Özellik

        private void lstAddDisOzellikler_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstAddDisOzellikler.SelectedIndex == -1)
            {
                return;
            }

            txtAddDisName.Text = lstAddDisOzellikler.SelectedItem.ToString();
        }
        //-----------------
        // Ekle
        private void btnAddDisEkle_Click(object sender, EventArgs e)
        {
            if (txtAddDisName.Text != "")
            {
                lstAddDisOzellikler.Items.Add(txtAddDisName.Text);
                txtAddDisName.Clear();
                txtAddDisName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Alanları Doldurunuz!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //-----------------
        // Güncelle
        private void btnAddDisGüncelle_Click(object sender, EventArgs e)
        {
            if (lstAddDisOzellikler.SelectedIndex == -1)
            {
                frmCustomMsgBx.Show("Güncellemek İstediğiniz Veriyi Seçin!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                return;
            }
            if (txtAddDisName.Text != "")
            {
                int index = lstAddDisOzellikler.SelectedIndex;
                lstAddDisOzellikler.Items.RemoveAt(index);
                lstAddDisOzellikler.Items.Insert(index, txtAddDisName.Text);
                txtAddDisName.Clear();
                txtAddDisName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Alanları Doldurunuz!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //-----------------
        // Çıkar
        private void btnAddDisSil_Click(object sender, EventArgs e)
        {
            if (lstAddDisOzellikler.SelectedIndex > -1)
            {
                int index = lstAddDisOzellikler.SelectedIndex;
                lstAddDisOzellikler.Items.RemoveAt(index);

                txtAddDisName.Clear();
                txtAddDisName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Silmek İstediğiniz Veriyi Seçin!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        #endregion
        // --------------------------------------
        #region İç Özellik

        private void lstAddIcOzellikler_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstAddIcOzellikler.SelectedIndex != -1)
            {
                txtAddIcName.Text = lstAddIcOzellikler.SelectedItem.ToString();
            }
        }
        //-----------------
        // Ekle
        private void btnAddIcEkle_Click(object sender, EventArgs e)
        {
            if (txtAddIcName.Text != "")
            {
                lstAddIcOzellikler.Items.Add(txtAddIcName.Text);
                txtAddIcName.Clear();
                txtAddIcName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Alanları Doldurunuz!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //-----------------
        // Güncelle
        private void btnAddIcGuncelle_Click(object sender, EventArgs e)
        {
            if (lstAddIcOzellikler.SelectedIndex == -1)
            {
                frmCustomMsgBx.Show("Güncellemek İstediğiniz Veriyi Seçin!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                return;
            }
            if (txtAddIcName.Text != "")
            {
                int index = lstAddIcOzellikler.SelectedIndex;
                lstAddIcOzellikler.Items.RemoveAt(index);
                lstAddIcOzellikler.Items.Insert(index, txtAddIcName.Text);
                txtAddIcName.Clear();
                txtAddIcName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Alanları Doldurunuz!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //-----------------
        // Çıkar
        private void btnAddIcSil_Click(object sender, EventArgs e)
        {
            if (lstAddIcOzellikler.SelectedIndex > -1)
            {
                int index = lstAddIcOzellikler.SelectedIndex;
                lstAddIcOzellikler.Items.RemoveAt(index);

                txtAddIcName.Clear();
                txtAddIcName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Silmek İstediğiniz Veriyi Seçin!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        #endregion
        // ---------------------------------------
        #region Konum Özellik

        private void lstAddKonumOzellikler_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstAddKonumOzellikler.SelectedIndex == -1)
            {
                return;
            }

            txtAddKonumName.Text = lstAddKonumOzellikler.SelectedItem.ToString();
        }
        //-----------------
        // Ekle
        private void btnAddKonumEkle_Click(object sender, EventArgs e)
        {
            if (txtAddKonumName.Text != "")
            {
                lstAddKonumOzellikler.Items.Add(txtAddKonumName.Text);
                txtAddKonumName.Clear();
                txtAddKonumName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Alanları Doldurunuz!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //-----------------
        // Güncelle
        private void btnAddKonumGuncelle_Click(object sender, EventArgs e)
        {
            if (lstAddKonumOzellikler.SelectedIndex == -1)
            {
                frmCustomMsgBx.Show("Güncellemek İstediğiniz Veriyi Seçin!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                return;
            }
            if (txtAddKonumName.Text != "")
            {
                int index = lstAddKonumOzellikler.SelectedIndex;
                lstAddKonumOzellikler.Items.RemoveAt(index);
                lstAddKonumOzellikler.Items.Insert(index, txtAddKonumName.Text);
                txtAddKonumName.Clear();
                txtAddKonumName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Alanları Doldurunuz!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //-----------------
        // Çıkar
        private void btnAddKonumSil_Click(object sender, EventArgs e)
        {

            if (lstAddKonumOzellikler.SelectedIndex > -1)
            {
                int index = lstAddKonumOzellikler.SelectedIndex;
                lstAddKonumOzellikler.Items.RemoveAt(index);

                txtAddKonumName.Clear();
                txtAddKonumName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Silmek İstediğiniz Veriyi Seçin!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        #endregion
        //------------------------------------------
        #region Resim Ekle için
        string addpath;
        int i = 0;
        private void btnAddResimEkle_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "JPEG(*.jpg)|*.jpg|PNG(*.png)|*.png|All Files(*.*)|*.*";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                Picture foto = new Picture();
                foto.index = i++;

                addpath = ofd.FileName;
                foto.ResimPath = addpath;
                Image addimg = Image.FromFile(addpath);

                Button btn = new Button();
                btn.FlatStyle = FlatStyle.Flat;
                btn.BackgroundImage = addimg;
                btn.BackgroundImageLayout = ImageLayout.Stretch;
                btn.Size = new Size(50, 50);
                btn.Margin = new Padding(5);
                btn.Tag = foto;
                fLpAddResimler.Controls.Add(btn);
                btn.Click += Btn_Click;
            }
        }
        private void btnAddResimSil_Click(object sender, EventArgs e)
        {
            if (frmCustomMsgBx.Show("Silmek istediğinize emin misiniz?", frmCustomMsgBx.CustomMsgbxButtons.YesNo) == DialogResult.Yes)
            {
                foreach (Button btn in fLpAddResimler.Controls)
                {
                    Picture picture = btn.Tag as Picture;
                    if (picture.index == seciliBtnTag.index)
                    {
                        fLpAddResimler.Controls.Remove(btn);
                    }
                }
            }
        }
        #endregion
        // --------------------------------------------------------
        // Ekle
        Random rnd = new Random();
        private void btnAdd_Click(object sender, EventArgs e)
        {
            //try
            //{
                // İlan
                Ilan ilan = new Ilan();
                ilan.IlanAdi = txtAddTitle.Text;
                ilan.IlanNo = Convert.ToInt32(txtAddIlanNo.Text);
                ilan.IlanTarihi = dTpAddIlanTarihi.Value;
                ilan.IlanVerenID = (int)cbAddIlanVeren.SelectedValue;
                ilan.Aciklama = txtAddIlanAciklama.Text;
                ilan.IlanFiyat = Convert.ToDecimal(txtAddFiyat.Text);
                // İlan Detay
                IlanDetay detay = new IlanDetay();
                detay.BrütMetreKare = nUdAddIlanBrut.Value;
                detay.NetMetreKare = nUdAddIlanNet.Value;
                detay.SemtID = (int)cbAddSemtler.SelectedValue;
                detay.AltKategoriID = (int)cbAddAltKategori.SelectedValue;

                ilan.ilanDetay.Add(detay);

                db.Ilanlar.Add(ilan);

                db.SaveChanges();

                int maxId = db.IlanDetaylari.Max(k => k.IlanDetayID);
                // Ek Özellik
                foreach (Ozellik item in lstAddEkOzellikler.Items)
                {
                    KategoriOzellik cato = new KategoriOzellik();
                    cato.Adi = item.Adi;
                    cato.Aciklama = item.Aciklama;
                    cato.IlanDetayID = maxId;
                    db.KategoriOzellikleri.Add(cato);
                }
                // Dış Özellik
                foreach (var item in lstAddDisOzellikler.Items)
                {
                    DisOzellik dis = new DisOzellik();
                    dis.DisOzellikAdi = item.ToString();
                    dis.IlanDetayID = maxId;
                    db.DisOzellikleri.Add(dis);
                }
                // İç Özellik 
                foreach (var item in lstAddIcOzellikler.Items)
                {
                    IcOzellik ic = new IcOzellik();
                    ic.IcOzellikAdi = item.ToString();
                    ic.IlanDetayID = maxId;
                    db.IcOzellikleri.Add(ic);
                }
                // Konum Özellik
                foreach (var item in lstAddKonumOzellikler.Items)
                {
                    KonumOzellik konum = new KonumOzellik();
                    konum.KonumOzellikAdi = item.ToString();
                    konum.IlanDetayID = maxId;
                    db.KonumOzellikleri.Add(konum);
                }

                // Resim EKle
                int ilanmaxId = db.Ilanlar.Max(k => k.IlanID);

                foreach (Button btn in fLpAddResimler.Controls)
                {

                    Picture foto = btn.Tag as Picture;
                    string imgname = Path.GetFileName(foto.ResimPath);
                    string Resim = @"..\..\Images\Ilan\ilan_" + Guid.NewGuid().ToString().Replace("-", " ").Substring(0, 5) + Path.GetExtension(imgname);
                    Image img = Image.FromFile(foto.ResimPath);

                    img.Save(Resim); // resmi kaydettik

                    Resim pic = new Resim();
                    pic.ResimPath = Resim;
                    pic.IlanID = ilanmaxId;

                    db.Resimler.Add(pic);
                }
                db.SaveChanges();

                Temizle();
                Listele();
                metroTabControl1.SelectedIndex = 0;
            //}
            //catch (Exception)
            //{
            //    frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            //}
        }


        private void metroTabControl2_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstAddDisOzellikler.SelectedIndex = -1;
            lstAddEkOzellikler.SelectedIndex = -1;
            lstAddIcOzellikler.SelectedIndex = -1;
            lstAddKonumOzellikler.SelectedIndex = -1;

            txtAddKonumName.Clear();
            txtAddEkOzellikName.Clear();
            txtAddEkOzellikAciklama.Clear();
            txtAddDisName.Clear();
            txtAddIcName.Clear();
        }
        #endregion

        //-------------------------------------

        #region Güncelleme
        #region Ek Özellik

        private void lstUpdateEkOzellikler_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstUpdateEkOzellikler.SelectedItem != null)
            {
                Ozellik ozellik = lstUpdateEkOzellikler.SelectedItem as Ozellik;

                txtUpdateEkOzellikName.Text = ozellik.Adi;
                txtUpdateEkOzellikAciklama.Text = ozellik.Aciklama;
            }
        }
        // --------------------------------------------
        // Ekle
        private void btnUpdateEkOzellikEkle_Click(object sender, EventArgs e)
        {
            if (txtUpdateEkOzellikName.Text != "" && txtUpdateEkOzellikAciklama.Text != "")
            {
                Ozellik ozellik = new Ozellik();
                ozellik.Adi = txtUpdateEkOzellikName.Text;
                ozellik.Aciklama = txtUpdateEkOzellikAciklama.Text;
                lstUpdateEkOzellikler.Items.Add(ozellik);

                txtUpdateEkOzellikName.Clear();
                txtUpdateEkOzellikAciklama.Clear();
                txtUpdateEkOzellikName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Alanları Doldurunuz!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        // ----------------------------
        // Güncelle
        private void btnUpdateEkOzellikGuncelle_Click(object sender, EventArgs e)
        {
            if (lstUpdateEkOzellikler.SelectedIndex == -1)
            {
                frmCustomMsgBx.Show("Güncellemek İstediğiniz Veriyi Seçin!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                return;
            }
            if (txtUpdateEkOzellikName.Text != "" && txtUpdateEkOzellikAciklama.Text != "")
            {
                Ozellik secilenItem = lstUpdateEkOzellikler.SelectedItem as Ozellik;

                int index = lstUpdateEkOzellikler.SelectedIndex;
                if (secilenItem.KategoriOzellikID != 0)
                {
                    var guncellenecekItem = db.KategoriOzellikleri.Where(d => d.KategoriOzellikID == secilenItem.KategoriOzellikID).FirstOrDefault();

                    guncellenecekItem.Adi = txtUpdateEkOzellikName.Text;
                    guncellenecekItem.Aciklama = txtUpdateEkOzellikAciklama.Text;

                    db.SaveChanges();
                    Ozellik ozellik = new Ozellik();
                    ozellik.Adi = guncellenecekItem.Adi;
                    ozellik.Aciklama = guncellenecekItem.Aciklama;

                    lstUpdateEkOzellikler.Items.Insert(index, ozellik);

                    lstUpdateEkOzellikler.Items.RemoveAt(index);
                }
                else
                {
                    lstUpdateEkOzellikler.Items.RemoveAt(index);

                    Ozellik ozellik = new Ozellik();
                    ozellik.Adi = txtUpdateEkOzellikName.Text;
                    ozellik.Aciklama = txtUpdateEkOzellikAciklama.Text;

                    lstUpdateEkOzellikler.Items.Insert(index, ozellik);
                }

                txtUpdateEkOzellikName.Clear();
                txtUpdateEkOzellikAciklama.Clear();
                txtUpdateEkOzellikName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Alanları Doldurunuz!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        // --------------------------
        // Çıkar
        private void btnUpdateEkOzellikSil_Click(object sender, EventArgs e)
        {
            if (lstUpdateEkOzellikler.SelectedIndex > -1)
            {
                Ozellik secilenItem = lstUpdateEkOzellikler.SelectedItem as Ozellik;

                if (secilenItem.KategoriOzellikID != 0)
                {
                    var silinecekItem = db.KategoriOzellikleri.Where(d => d.KategoriOzellikID == secilenItem.KategoriOzellikID).FirstOrDefault();

                    db.KategoriOzellikleri.Remove(silinecekItem);

                    db.SaveChanges();
                }
                int index = lstUpdateEkOzellikler.SelectedIndex;
                lstUpdateEkOzellikler.Items.RemoveAt(index);

                txtUpdateEkOzellikName.Clear();
                txtUpdateEkOzellikAciklama.Clear();
                txtUpdateEkOzellikName.Focus();

                lstUpdateEkOzellikler.SelectedIndex = -1;
            }
            else
            {
                frmCustomMsgBx.Show("Silmek İstediğiniz Veriyi Seçin!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        #endregion
        // ----------------------------------------------
        #region Dış Özellik

        private void lstUpdateDisOzellikler_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstUpdateDisOzellikler.SelectedIndex == -1)
            {
                return;
            }
            DisOzellik ozellik = lstUpdateDisOzellikler.SelectedItem as DisOzellik;

            txtUpdateDisName.Text = ozellik.DisOzellikAdi;
        }
        // ----------------------
        // Ekle
        private void btnUpdateDisEkle_Click(object sender, EventArgs e)
        {
            if (txtUpdateDisName.Text != "")
            {
                DisOzellik dis = new DisOzellik();
                dis.DisOzellikAdi = txtUpdateDisName.Text;
                lstUpdateDisOzellikler.Items.Add(dis);
                lstUpdateDisOzellikler.DisplayMember = "DisOzellikAdi";
                txtUpdateDisName.Clear();
                txtUpdateDisName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Alanları Doldurunuz!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        // --------------------
        // Güncelle
        private void btnUpdateDisGuncelle_Click(object sender, EventArgs e)
        {
            if (lstUpdateDisOzellikler.SelectedIndex == -1)
            {
                frmCustomMsgBx.Show("Güncellemek İstediğiniz Veriyi Seçin!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                return;
            }
            if (txtUpdateDisName.Text != "")
            {
                DisOzellik secilenItem = lstUpdateDisOzellikler.SelectedItem as DisOzellik;
                int index = lstUpdateDisOzellikler.SelectedIndex;

                if (secilenItem.DisOzellikID != 0)
                {
                    var guncellenecekItem = db.DisOzellikleri.Where(d => d.DisOzellikID == secilenItem.DisOzellikID).FirstOrDefault();

                    guncellenecekItem.DisOzellikAdi = txtUpdateDisName.Text;
                    db.SaveChanges();

                    lstUpdateDisOzellikler.Items.RemoveAt(index);
                    lstUpdateDisOzellikler.Items.Insert(index, guncellenecekItem.DisOzellikAdi);
                }
                else
                {
                    lstUpdateDisOzellikler.Items.RemoveAt(index);
                    lstUpdateDisOzellikler.Items.Insert(index, txtUpdateDisName.Text);
                }
                txtUpdateDisName.Clear();
                txtUpdateDisName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Alanları Doldurunuz!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        // ----------------------
        // Çıkar
        private void btnUpdateDisSil_Click(object sender, EventArgs e)
        {
            if (lstUpdateDisOzellikler.SelectedIndex > -1)
            {
                DisOzellik secilenItem = lstUpdateDisOzellikler.SelectedItem as DisOzellik;

                if (secilenItem.DisOzellikID != 0)
                {
                    var silinecekItem = db.DisOzellikleri.Where(k => k.DisOzellikID == secilenItem.DisOzellikID).FirstOrDefault();
                    db.DisOzellikleri.Remove(silinecekItem);
                    db.SaveChanges();
                }

                int index = lstUpdateDisOzellikler.SelectedIndex;
                lstUpdateDisOzellikler.Items.RemoveAt(index);

                txtUpdateDisName.Clear();
                txtUpdateDisName.Focus();

                lstUpdateDisOzellikler.SelectedIndex = -1;
            }
            else
            {
                frmCustomMsgBx.Show("Silmek İstediğiniz Veriyi Seçin!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        #endregion
        // ------------------------------------------------------
        #region İç Özellik

        private void lstUpdateIcOzellikler_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstUpdateIcOzellikler.SelectedIndex == -1)
            {
                return;
            }
            IcOzellik ozellik = lstUpdateIcOzellikler.SelectedItem as IcOzellik;

            txtUpdateIcOzellikName.Text = ozellik.IcOzellikAdi;
        }
        // -------------------
        // Ekle
        private void btnUpdateIcEkle_Click(object sender, EventArgs e)
        {
            if (txtUpdateIcOzellikName.Text != "")
            {
                IcOzellik ic = new IcOzellik();
                ic.IcOzellikAdi = txtUpdateIcOzellikName.Text;
                lstUpdateIcOzellikler.Items.Add(ic);
                lstUpdateIcOzellikler.DisplayMember = "IcOzellikAdi";
                txtUpdateIcOzellikName.Clear();
                txtUpdateIcOzellikName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Alanları Doldurunuz!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        // -------------------
        // Güncelle
        private void btnUpdateIcGuncelle_Click(object sender, EventArgs e)
        {
            if (lstUpdateIcOzellikler.SelectedIndex == -1)
            {
                frmCustomMsgBx.Show("Güncellemek İstediğiniz Veriyi Seçin!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                return;
            }
            if (txtUpdateIcOzellikName.Text != "")
            {
                IcOzellik secilenKonum = lstUpdateIcOzellikler.SelectedItem as IcOzellik;

                int index = lstUpdateIcOzellikler.SelectedIndex;
                if (secilenKonum.IcOzellikID != 0)
                {
                    var guncellenecekItem = db.IcOzellikleri.Where(k => k.IcOzellikID == secilenKonum.IcOzellikID).FirstOrDefault();

                    guncellenecekItem.IcOzellikAdi = txtUpdateIcOzellikName.Text;
                    db.SaveChanges();

                    lstUpdateIcOzellikler.Items.RemoveAt(index);
                    lstUpdateIcOzellikler.Items.Insert(index, guncellenecekItem.IcOzellikAdi);
                }
                else
                {
                    lstUpdateIcOzellikler.Items.RemoveAt(index);
                    lstUpdateIcOzellikler.Items.Insert(index, txtUpdateKonumName.Text);
                }

                txtUpdateIcOzellikName.Clear();
                txtUpdateIcOzellikName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Alanları Doldurunuz!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        // -------------------
        // Çıkar
        private void btnUpdateIcSil_Click(object sender, EventArgs e)
        {
            if (lstUpdateIcOzellikler.SelectedIndex > -1)
            {
                IcOzellik secilenKonum = lstUpdateIcOzellikler.SelectedItem as IcOzellik;

                if (secilenKonum.IcOzellikID != 0)
                {
                    var silinecekItem = db.IcOzellikleri.Where(k => k.IcOzellikID == secilenKonum.IcOzellikID).FirstOrDefault();
                    db.IcOzellikleri.Remove(silinecekItem);
                    db.SaveChanges();
                }
                int index = lstUpdateIcOzellikler.SelectedIndex;
                lstUpdateIcOzellikler.Items.RemoveAt(index);

                txtUpdateIcOzellikName.Clear();
                txtUpdateIcOzellikName.Focus();

                lstUpdateIcOzellikler.SelectedIndex = -1;
            }
            else
            {
                frmCustomMsgBx.Show("Silmek İstediğiniz Veriyi Seçin!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        #endregion
        // ------------------------------------------------------
        #region Konum Özellik

        private void lstUpdateKonumOzellikler_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstUpdateKonumOzellikler.SelectedIndex == -1)
            {
                return;
            }
            KonumOzellik konum = lstUpdateKonumOzellikler.SelectedItem as KonumOzellik;

            txtUpdateKonumName.Text = konum.KonumOzellikAdi;
        }
        // ---------------------
        // Ekle
        private void btnUpdateKonumEkle_Click(object sender, EventArgs e)
        {
            if (txtUpdateKonumName.Text != "")
            {
                KonumOzellik konum = new KonumOzellik();
                konum.KonumOzellikAdi = txtUpdateKonumName.Text;
                lstUpdateKonumOzellikler.Items.Add(konum);
                lstUpdateKonumOzellikler.DisplayMember = "KonumOzellikAdi";
                txtUpdateKonumName.Clear();
                txtUpdateKonumName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Alanları Doldurunuz!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        // -----------------------
        // Güncelle
        private void btnUpdateKonumGuncelle_Click(object sender, EventArgs e)
        {
            if (lstUpdateKonumOzellikler.SelectedIndex == -1)
            {
                frmCustomMsgBx.Show("Güncellemek İstediğiniz Veriyi Seçin!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                return;
            }
            if (txtUpdateKonumName.Text != "")
            {
                KonumOzellik secilenKonum = lstUpdateKonumOzellikler.SelectedItem as KonumOzellik;

                int index = lstUpdateKonumOzellikler.SelectedIndex;
                if (secilenKonum.KonumOzellikID != 0)
                {
                    var guncellenecekItem = db.KonumOzellikleri.Where(k => k.KonumOzellikID == secilenKonum.KonumOzellikID).FirstOrDefault();

                    guncellenecekItem.KonumOzellikAdi = txtUpdateKonumName.Text;
                    db.SaveChanges();

                    lstUpdateKonumOzellikler.Items.RemoveAt(index);
                    lstUpdateKonumOzellikler.Items.Insert(index, guncellenecekItem.KonumOzellikAdi);
                }
                else
                {
                    lstUpdateKonumOzellikler.Items.RemoveAt(index);
                    lstUpdateKonumOzellikler.Items.Insert(index, txtUpdateKonumName.Text);
                }
                txtUpdateKonumName.Clear();
                txtUpdateKonumName.Focus();
            }
            else
            {
                frmCustomMsgBx.Show("Alanları Doldurunuz!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        // ----------------------
        // Çıkar
        private void btnUpdateKonumSil_Click(object sender, EventArgs e)
        {
            if (lstUpdateKonumOzellikler.SelectedIndex > -1)
            {
                KonumOzellik secilenKonum = lstUpdateKonumOzellikler.SelectedItem as KonumOzellik;

                if (secilenKonum.KonumOzellikID != 0)
                {
                    var silinecekItem = db.KonumOzellikleri.Where(k => k.KonumOzellikID == secilenKonum.KonumOzellikID).FirstOrDefault();
                    db.KonumOzellikleri.Remove(silinecekItem);
                    db.SaveChanges();
                }

                int index = lstUpdateKonumOzellikler.SelectedIndex;
                lstUpdateKonumOzellikler.Items.RemoveAt(index);

                txtUpdateKonumName.Clear();
                txtUpdateKonumName.Focus();

                lstAddKonumOzellikler.SelectedIndex = -1;
            }
            else
            {
                frmCustomMsgBx.Show("Silmek İstediğiniz Veriyi Seçin!!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        #endregion
        // ------------------------------------------------------
        #region Resim Ekle
        string updatepath;
        int piccount = 0;
        private void btnUpdateResimEkle_Click(object sender, EventArgs e)
        {
            int updateindex =  piccount;
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "JPEG(*.jpg)|*.jpg|PNG(*.png)|*.png|All Files(*.*)|*.*";

            if (ofd.ShowDialog() == DialogResult.OK)
            {

                updatepath = ofd.FileName;
                Picture foto = new Picture();
                foto.ResimPath = updatepath;
                foto.index = updateindex++;
                Image addimg = Image.FromFile(updatepath);

                Button btn = new Button();
                btn.FlatStyle = FlatStyle.Flat;
                btn.BackgroundImage = addimg;
                btn.BackgroundImageLayout = ImageLayout.Stretch;
                btn.Size = new Size(50, 50);
                btn.Margin = new Padding(5);
                btn.Tag = foto;
                fLpUpdateResimler.Controls.Add(btn);
                btn.Click += Btn_Click;
            }
        }

        private void brnUpdateResimCikar_Click(object sender, EventArgs e)
        {
            if (frmCustomMsgBx.Show("Silmek istediğinize emin misiniz?", frmCustomMsgBx.CustomMsgbxButtons.YesNo) == DialogResult.Yes)
            {

                var resim = db.Resimler.Where(r => r.ResimID == seciliBtnTag.ResimID).FirstOrDefault();
                if (resim != null)
                {
                    db.Resimler.Remove(resim);
                    db.SaveChanges();
                }
                foreach (Button btn in fLpUpdateResimler.Controls)
                {
                    Picture p = btn.Tag as Picture;
                    if (p.index == seciliBtnTag.index)
                    {
                        fLpUpdateResimler.Controls.Remove(btn);
                    }
                }
            }
        }
        #endregion

        //---------------------------------------------
        // Güncelle butonu
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                // İlan
                Ilan ilan = db.Ilanlar.Where(i => i.IlanID == secilenID).FirstOrDefault();
                ilan.IlanAdi = txtUpdateIlanTitle.Text;
                ilan.IlanNo = Convert.ToInt32(txtUpdateIlanNo.Text);
                ilan.IlanTarihi = dTpUpdateIlanTarihi.Value;
                ilan.IlanVerenID = (int)cbUpdateIlanVeren.SelectedValue;
                ilan.Aciklama = txtUpdateIlanAciklama.Text;
                ilan.IlanFiyat = Convert.ToDecimal(txtUpdateFiyat.Text);

                // İlan Detay
                IlanDetay detay = db.IlanDetaylari.Where(d => d.IlanID == secilenID).FirstOrDefault();
                detay.BrütMetreKare = nUdUpdateIlanBrut.Value;
                detay.NetMetreKare = nUdUpdateIlanNet.Value;
                detay.SemtID = (int)cbUpdateIlanSemt.SelectedValue;
                detay.AltKategoriID = (int)cbUpdateIlanAltKategori.SelectedValue;



                db.SaveChanges();

                int Id = detay.IlanDetayID;
                // Ek Özellik
                foreach (Ozellik item in lstUpdateEkOzellikler.Items)
                {
                    KategoriOzellik cato = new KategoriOzellik();
                    cato.Adi = item.Adi;
                    cato.Aciklama = item.Aciklama;
                    var controlEk = db.KategoriOzellikleri.Where(d => d.KategoriOzellikID == item.KategoriOzellikID).FirstOrDefault();
                    if (controlEk == null)
                    {
                        cato.IlanDetayID = Id;
                        db.KategoriOzellikleri.Add(cato);
                    }
                }
                // Dış Özellik
                foreach (DisOzellik item in lstUpdateDisOzellikler.Items)
                {
                    DisOzellik dis = new DisOzellik();
                    dis.DisOzellikAdi = item.DisOzellikAdi;
                    var controlDis = db.DisOzellikleri.Where(d => d.DisOzellikID == item.DisOzellikID).FirstOrDefault();
                    if (controlDis == null)
                    {
                        dis.IlanDetayID = Id;
                        db.DisOzellikleri.Add(dis);
                    }
                }
                // İç Özellik 
                foreach (IcOzellik item in lstUpdateIcOzellikler.Items)
                {
                    IcOzellik ic = new IcOzellik();
                    ic.IcOzellikAdi = item.IcOzellikAdi;
                    var controlIc = db.IcOzellikleri.Where(d => d.IcOzellikID == item.IcOzellikID).FirstOrDefault();
                    if (controlIc == null)
                    {
                        ic.IlanDetayID = Id;
                        db.IcOzellikleri.Add(ic);
                    }
                }
                // Konum Özellik
                foreach (KonumOzellik item in lstUpdateKonumOzellikler.Items)
                {
                    KonumOzellik konum = new KonumOzellik();
                    konum.KonumOzellikAdi = item.KonumOzellikAdi;
                    var controlKonum = db.KonumOzellikleri.Where(d => d.KonumOzellikID == item.KonumOzellikID).FirstOrDefault();
                    if (controlKonum == null)
                    {
                        konum.IlanDetayID = Id;
                        db.KonumOzellikleri.Add(konum);
                    }
                }

                // Resim Ekle

                foreach (Button btn in fLpUpdateResimler.Controls)
                {
                    Picture foto = btn.Tag as Picture;

                    var controlPics = db.Resimler.Where(r => r.ResimPath == foto.ResimPath).FirstOrDefault();
                    if (controlPics == null)
                    {
                        string imgname = Path.GetFileName(foto.ResimPath);
                        string Resim = @"..\..\Images\Ilan\ilan_" + Guid.NewGuid().ToString().Replace("-", " ").Substring(0, 5) + Path.GetExtension(imgname);
                        Image img = Image.FromFile(foto.ResimPath);

                        img.Save(Resim); // resmi kaydettik

                        Resim pic = new Resim();
                        pic.ResimPath = Resim;
                        pic.IlanID = secilenID;

                        db.Resimler.Add(pic);
                    }
                }
                db.SaveChanges();

                Temizle();
                Listele();
                metroTabControl1.SelectedIndex = 0;
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }

        #endregion


        private void metroTabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            metroTabControl2.SelectedIndex = 0;
            txtAddIlanNo.Text = rnd.Next(0, 10000).ToString();
            if (metroTabControl1.SelectedIndex == 2)
            {
                if (contextmenu == false)
                {
                    metroTabControl1.SelectedIndex = 0;
                    frmCustomMsgBx.Show("Lütfen Güncellemek İstediğiniz Veriyi Seçiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);

                }
            }
            metroTabControl2.SelectedIndex = 0;
            metroTabControl3.SelectedIndex = 0;
            contextmenu = false;
            Temizle();
        }

        #region ContextMenu / Sil

        private void önizlemeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (secilenID == 0)
            {
                frmCustomMsgBx.Show("Lütfen Önizlemek İstediğiniz Veriyi Seçiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                return;
            }
            Ilan secilenIlan = db.Ilanlar.Where(i => i.IlanID == secilenID).FirstOrDefault();

            Forms.frmOnizleme frm = new frmOnizleme(secilenIlan);

            frmMain anaForm = new frmMain();
            anaForm.Hide();
            frm.Show();
        }
        // -----------------------------------
        // Güncelle
        private void güncelleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (secilenID == 0)
            {
                frmCustomMsgBx.Show("Lütfen Güncellemek İstediğiniz Veriyi Seçiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                return;
            }
            contextmenu = true;
            metroTabControl1.SelectedIndex = 2;

            // ilan
            Ilan ilan = db.Ilanlar.Where(i => i.IlanID == secilenID).FirstOrDefault();

            txtUpdateIlanAciklama.Text = ilan.Aciklama;
            txtUpdateIlanNo.Text = ilan.IlanNo.ToString();
            txtUpdateIlanTitle.Text = ilan.IlanAdi;
            dTpUpdateIlanTarihi.Value = Convert.ToDateTime(ilan.IlanTarihi);
            txtUpdateFiyat.Text =ilan.IlanFiyat.ToString();
            IlanVerenleriGetir(cbUpdateIlanVeren);
            cbUpdateIlanVeren.SelectedValue = ilan.IlanVerenID;

            // Resimler
            var resims = db.Resimler.Where(r => r.IlanID == secilenID).ToList();

            if (resims != null)
            {
                foreach (Resim resim in resims)
                {
                    Picture pic = new Picture();
                    pic.index = piccount++;
                    pic.ResimID = resim.ResimID;
                    pic.ResimPath = resim.ResimPath;

                    Image addimg = Image.FromFile(resim.ResimPath);
                    Button btn = new Button();
                    btn.FlatStyle = FlatStyle.Flat;
                    btn.BackgroundImage = addimg;
                    btn.BackgroundImageLayout = ImageLayout.Stretch;
                    btn.Size = new Size(50, 50);
                    btn.Margin = new Padding(5);
                    btn.Tag = pic;
                    fLpUpdateResimler.Controls.Add(btn);

                    btn.Click += Btn_Click;
                }

            }

            // ilan detay
            IlanDetay ilanDetay = db.IlanDetaylari.Where(d => d.IlanID == ilan.IlanID).FirstOrDefault();


            TurleriGetir(cbUpdateIlanTuru);
            cbUpdateIlanTuru.SelectedValue = ilanDetay.AltKategori.kategori.IlanTuruID;
            KategorileriGetir(cbUpdateIlanKategori, ilanDetay.AltKategori.kategori.IlanTuruID);
            AltKategorileriGetir(cbUpdateIlanAltKategori, ilanDetay.AltKategori.KategoriID);

            IlleriGetir(cbUpdateIlanIller);
            cbUpdateIlanIller.SelectedValue = ilanDetay.semt.ilce.IlID;
            IlceleriGetir(cbUpdateIlanIlceler, ilanDetay.semt.ilce.IlID);
            SemtleriGetir(cbUpdateIlanSemt, ilanDetay.semt.IlceID);

            nUdUpdateIlanBrut.Value = ilanDetay.BrütMetreKare;
            nUdUpdateIlanNet.Value = ilanDetay.NetMetreKare;

            // Ek özellikler

            var ekLists = db.KategoriOzellikleri.Where(el => el.IlanDetayID == ilanDetay.IlanDetayID).ToList();

            foreach (KategoriOzellik ek in ekLists)
            {
                Ozellik oz = new Ozellik();
                oz.Adi = ek.Adi;
                oz.Aciklama = ek.Aciklama;
                oz.KategoriOzellikID = ek.KategoriOzellikID;
                oz.IlanDetayID = ek.IlanDetayID;
                lstUpdateEkOzellikler.Items.Add(oz);
            }

            // Dış Özellikler

            var disLists = db.DisOzellikleri.Where(el => el.IlanDetayID == ilanDetay.IlanDetayID).ToList();

            foreach (DisOzellik ds in disLists)
            {
                lstUpdateDisOzellikler.Items.Add(ds);
                lstUpdateDisOzellikler.DisplayMember = "DisOzellikAdi";
            }

            // İç Özellikler

            var icLists = db.IcOzellikleri.Where(el => el.IlanDetayID == ilanDetay.IlanDetayID).ToList();

            foreach (IcOzellik c in icLists)
            {
                lstUpdateIcOzellikler.Items.Add(c);
                lstUpdateIcOzellikler.DisplayMember = "IcOzellikAdi";
            }

            // konum Özellikler

            var konumLists = db.KonumOzellikleri.Where(el => el.IlanDetayID == ilanDetay.IlanDetayID).ToList();
            foreach (KonumOzellik k in konumLists)
            {
                lstUpdateKonumOzellikler.Items.Add(k);
                lstUpdateKonumOzellikler.DisplayMember = "KonumOzellikAdi";
            }
        }
    
        Picture seciliBtnTag;
        private void Btn_Click(object sender, EventArgs e)
        {
            Button tiklanan = sender as Button;
            seciliBtnTag = tiklanan.Tag as Picture;
        }
        //--------------------------
        // Sil
        private void silToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (frmCustomMsgBx.Show("Silmek istediğinize emin misiniz?", frmCustomMsgBx.CustomMsgbxButtons.YesNo) == DialogResult.Yes)
                {
                    // İlan
                    Ilan ilan = db.Ilanlar.Where(i => i.IlanID == secilenID).FirstOrDefault();

                    db.Ilanlar.Remove(ilan);
                    // İlan Detay
                    IlanDetay detay = db.IlanDetaylari.Where(d => d.IlanID == secilenID).FirstOrDefault();

                    db.IlanDetaylari.Remove(detay);
                    db.SaveChanges();


                    // Ek Özellik
                    var ozellilEks = db.KategoriOzellikleri.Where(k => k.IlanDetayID == detay.IlanDetayID).ToList();
                    foreach (KategoriOzellik ek in ozellilEks)
                    {
                       db.KategoriOzellikleri.Remove(ek);
                    }

                    // Dış Özellik
                    var ozellikDiss = db.DisOzellikleri.Where(k => k.IlanDetayID == detay.IlanDetayID).ToList();
                    foreach (DisOzellik dis in ozellikDiss)
                    {
                        db.DisOzellikleri.Remove(dis);
                    }

                    // İç Özellik 
                    var ozellikIcs = db.IcOzellikleri.Where(k => k.IlanDetayID == detay.IlanDetayID).ToList();
                    foreach (IcOzellik ic in ozellikIcs)
                    {
                        db.IcOzellikleri.Remove(ic);
                    }

                    // Konum Özellik
                    var ozellikKonums = db.KonumOzellikleri.Where(k => k.IlanDetayID == detay.IlanDetayID).ToList();
                    foreach (KonumOzellik konum in lstAddKonumOzellikler.Items)
                    {
                       db.KonumOzellikleri.Remove(konum);
                    }
                    
                    // Resim Ekle
                    var resims = db.Resimler.Where(r => r.IlanID == secilenID).ToList();
                    foreach (Resim pic in resims)
                    {
                        db.Resimler.Remove(pic);
                    }
                    db.SaveChanges();
                    
                    Listele();
                }
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        } 
        #endregion

        private void dGwIlanlar_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            secilenID = (int)dGwIlanlar.SelectedRows[0].Cells[0].Value;
        }

        private void Temizle()
        {
            // Ekle
            txtAddDisName.Clear();
            txtAddEkOzellikAciklama.Clear();
            txtAddEkOzellikName.Clear();
            txtAddIcName.Clear();
            txtAddIlanAciklama.Clear();
            txtAddKonumName.Clear();
            txtAddTitle.Clear();
            txtSearch.Clear();
            txtAddFiyat.Clear();
            nUdAddIlanBrut.Value = 0;
            nUdAddIlanNet.Value = 0;
            dTpAddIlanTarihi.Value = DateTime.Now;

            cbAddAltKategori.SelectedIndex = -1;
            cbAddIlanTuru.SelectedIndex = -1;
            cbAddIlanVeren.SelectedIndex = -1;
            cbAddIlceler.SelectedIndex = -1;
            cbAddIller.SelectedIndex = -1;
            cbAddSemtler.SelectedIndex = -1;
            cbAddKategori.SelectedIndex = -1;

            lstAddDisOzellikler.Items.Clear();
            lstAddEkOzellikler.Items.Clear();
            lstAddIcOzellikler.Items.Clear();
            lstAddKonumOzellikler.Items.Clear();

            fLpAddResimler.Controls.Clear();


            // Güncelle

            txtAddDisName.Clear();
            txtAddEkOzellikAciklama.Clear();
            txtAddEkOzellikName.Clear();
            txtAddIcName.Clear();
            txtAddIlanAciklama.Clear();
            txtAddKonumName.Clear();
            txtAddTitle.Clear();
            txtSearch.Clear();
            txtUpdateFiyat.Clear();
            nUdAddIlanBrut.Value = 0;
            nUdAddIlanNet.Value = 0;
            dTpUpdateIlanTarihi.Value = DateTime.Now;

            cbAddAltKategori.SelectedIndex = -1;
            cbAddIlanTuru.SelectedIndex = -1;
            cbAddIlanVeren.SelectedIndex = -1;
            cbAddIlceler.SelectedIndex = -1;
            cbAddIller.SelectedIndex = -1;
            cbAddSemtler.SelectedIndex = -1;
            cbAddKategori.SelectedIndex = -1;


            lstUpdateDisOzellikler.Items.Clear();
            lstUpdateEkOzellikler.Items.Clear();
            lstUpdateIcOzellikler.Items.Clear();
            lstUpdateKonumOzellikler.Items.Clear();

            fLpUpdateResimler.Controls.Clear();

            contextmenu = false;
        }

        private void metroTabControl3_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstUpdateKonumOzellikler.SelectedIndex = -1;
            lstUpdateIcOzellikler.SelectedIndex = -1;
            lstUpdateDisOzellikler.SelectedIndex = -1;
            lstUpdateEkOzellikler.SelectedIndex = -1;

            txtUpdateKonumName.Clear();
            txtUpdateEkOzellikName.Clear();
            txtUpdateEkOzellikAciklama.Clear();
            txtUpdateDisName.Clear();
            txtUpdateIcOzellikName.Clear();
        }
    }
}
