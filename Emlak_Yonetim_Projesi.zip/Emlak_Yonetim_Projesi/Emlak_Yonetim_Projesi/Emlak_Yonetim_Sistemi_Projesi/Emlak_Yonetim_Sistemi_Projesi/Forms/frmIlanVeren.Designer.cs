﻿namespace Emlak_Yonetim_Sistemi_Projesi.Forms
{
    partial class frmIlanVeren
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.metroTabControl1 = new MetroFramework.Controls.MetroTabControl();
            this.metroTabPage1 = new MetroFramework.Controls.MetroTabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblToplam = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.dGwIlanVerenler = new System.Windows.Forms.DataGridView();
            this.metroContextMenuIlanVeren = new MetroFramework.Controls.MetroContextMenu(this.components);
            this.güncelleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.silToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtSearch = new MetroFramework.Controls.MetroTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.metroTabPage2 = new MetroFramework.Controls.MetroTabPage();
            this.btnAddResimSec = new MetroFramework.Controls.MetroButton();
            this.label21 = new System.Windows.Forms.Label();
            this.txtAddSirket = new MetroFramework.Controls.MetroTextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.btnAdd = new MetroFramework.Controls.MetroButton();
            this.lblAddResim = new System.Windows.Forms.Label();
            this.txtAddAdress = new MetroFramework.Controls.MetroTextBox();
            this.txtAddAciklama = new MetroFramework.Controls.MetroTextBox();
            this.txtAddWeb = new MetroFramework.Controls.MetroTextBox();
            this.mtxtAddCepTel = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.mtxtAddTel = new System.Windows.Forms.MaskedTextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.metroTabPage3 = new MetroFramework.Controls.MetroTabPage();
            this.label19 = new System.Windows.Forms.Label();
            this.txtUpdateSirket = new MetroFramework.Controls.MetroTextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.btnUpdateResimSec = new MetroFramework.Controls.MetroButton();
            this.btnUpdate = new MetroFramework.Controls.MetroButton();
            this.lblUpdateResim = new System.Windows.Forms.Label();
            this.txtUpdateAdres = new MetroFramework.Controls.MetroTextBox();
            this.txtUpdateAciklama = new MetroFramework.Controls.MetroTextBox();
            this.txtUpdateWeb = new MetroFramework.Controls.MetroTextBox();
            this.mtxtUpdateCepTel = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.mtxtUpdateTel = new System.Windows.Forms.MaskedTextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.metroToolTip1 = new MetroFramework.Components.MetroToolTip();
            this.helpProvider1 = new System.Windows.Forms.HelpProvider();
            this.metroTabControl1.SuspendLayout();
            this.metroTabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGwIlanVerenler)).BeginInit();
            this.metroContextMenuIlanVeren.SuspendLayout();
            this.metroTabPage2.SuspendLayout();
            this.metroTabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroTabControl1
            // 
            this.metroTabControl1.Controls.Add(this.metroTabPage1);
            this.metroTabControl1.Controls.Add(this.metroTabPage2);
            this.metroTabControl1.Controls.Add(this.metroTabPage3);
            this.metroTabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroTabControl1.Location = new System.Drawing.Point(0, 0);
            this.metroTabControl1.Name = "metroTabControl1";
            this.metroTabControl1.SelectedIndex = 1;
            this.metroTabControl1.Size = new System.Drawing.Size(609, 494);
            this.metroTabControl1.TabIndex = 1;
            this.metroTabControl1.UseSelectable = true;
            this.metroTabControl1.SelectedIndexChanged += new System.EventHandler(this.metroTabControl1_SelectedIndexChanged);
            // 
            // metroTabPage1
            // 
            this.metroTabPage1.Controls.Add(this.pictureBox1);
            this.metroTabPage1.Controls.Add(this.lblToplam);
            this.metroTabPage1.Controls.Add(this.label33);
            this.metroTabPage1.Controls.Add(this.dGwIlanVerenler);
            this.metroTabPage1.Controls.Add(this.txtSearch);
            this.metroTabPage1.Controls.Add(this.label9);
            this.metroTabPage1.HorizontalScrollbarBarColor = true;
            this.metroTabPage1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.HorizontalScrollbarSize = 10;
            this.metroTabPage1.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage1.Name = "metroTabPage1";
            this.metroTabPage1.Size = new System.Drawing.Size(601, 452);
            this.metroTabPage1.TabIndex = 0;
            this.metroTabPage1.Text = "İlan Veren";
            this.metroTabPage1.VerticalScrollbarBarColor = true;
            this.metroTabPage1.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage1.VerticalScrollbarSize = 10;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.helpProvider1.SetHelpKeyword(this.pictureBox1, "");
            this.helpProvider1.SetHelpString(this.pictureBox1, "Sağ tık ile güncelleme ve sil işlemlerini yapabilirsiniz.");
            this.pictureBox1.Image = global::Emlak_Yonetim_Sistemi_Projesi.Properties.Resources.help;
            this.pictureBox1.Location = new System.Drawing.Point(8, 29);
            this.pictureBox1.Name = "pictureBox1";
            this.helpProvider1.SetShowHelp(this.pictureBox1, true);
            this.pictureBox1.Size = new System.Drawing.Size(20, 20);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            this.metroToolTip1.SetToolTip(this.pictureBox1, "Sağ tık ile güncelleme ve sil işlemlerini yapabilirsiniz.");
            // 
            // lblToplam
            // 
            this.lblToplam.AutoSize = true;
            this.lblToplam.BackColor = System.Drawing.Color.White;
            this.lblToplam.Location = new System.Drawing.Point(536, 399);
            this.lblToplam.Name = "lblToplam";
            this.lblToplam.Size = new System.Drawing.Size(13, 13);
            this.lblToplam.TabIndex = 10;
            this.lblToplam.Text = "0";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.White;
            this.label33.Location = new System.Drawing.Point(475, 399);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(54, 13);
            this.label33.TabIndex = 11;
            this.label33.Text = "Toplam = ";
            // 
            // dGwIlanVerenler
            // 
            this.dGwIlanVerenler.AllowUserToAddRows = false;
            this.dGwIlanVerenler.AllowUserToOrderColumns = true;
            this.dGwIlanVerenler.BackgroundColor = System.Drawing.Color.LightGray;
            this.dGwIlanVerenler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGwIlanVerenler.ContextMenuStrip = this.metroContextMenuIlanVeren;
            this.dGwIlanVerenler.Location = new System.Drawing.Point(8, 54);
            this.dGwIlanVerenler.Name = "dGwIlanVerenler";
            this.dGwIlanVerenler.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dGwIlanVerenler.Size = new System.Drawing.Size(585, 342);
            this.dGwIlanVerenler.TabIndex = 9;
            this.metroToolTip1.SetToolTip(this.dGwIlanVerenler, "Sağ tık ile güncelleme ve sil işlemlerini yapabilirsiniz.");
            this.dGwIlanVerenler.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGwIlanVerenler_CellClick);
            // 
            // metroContextMenuIlanVeren
            // 
            this.metroContextMenuIlanVeren.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.güncelleToolStripMenuItem,
            this.silToolStripMenuItem});
            this.metroContextMenuIlanVeren.Name = "metroContextMenuIlanVeren";
            this.metroContextMenuIlanVeren.Size = new System.Drawing.Size(121, 48);
            // 
            // güncelleToolStripMenuItem
            // 
            this.güncelleToolStripMenuItem.Image = global::Emlak_Yonetim_Sistemi_Projesi.Properties.Resources.update;
            this.güncelleToolStripMenuItem.Name = "güncelleToolStripMenuItem";
            this.güncelleToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.güncelleToolStripMenuItem.Text = "Güncelle";
            this.güncelleToolStripMenuItem.Click += new System.EventHandler(this.güncelleToolStripMenuItem_Click);
            // 
            // silToolStripMenuItem
            // 
            this.silToolStripMenuItem.Image = global::Emlak_Yonetim_Sistemi_Projesi.Properties.Resources.trash1;
            this.silToolStripMenuItem.Name = "silToolStripMenuItem";
            this.silToolStripMenuItem.Size = new System.Drawing.Size(120, 22);
            this.silToolStripMenuItem.Text = "Sil";
            this.silToolStripMenuItem.Click += new System.EventHandler(this.silToolStripMenuItem_Click);
            // 
            // txtSearch
            // 
            // 
            // 
            // 
            this.txtSearch.CustomButton.Image = null;
            this.txtSearch.CustomButton.Location = new System.Drawing.Point(120, 1);
            this.txtSearch.CustomButton.Name = "";
            this.txtSearch.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtSearch.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtSearch.CustomButton.TabIndex = 1;
            this.txtSearch.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtSearch.CustomButton.UseSelectable = true;
            this.txtSearch.CustomButton.Visible = false;
            this.txtSearch.Lines = new string[0];
            this.txtSearch.Location = new System.Drawing.Point(451, 25);
            this.txtSearch.MaxLength = 32767;
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.PasswordChar = '\0';
            this.txtSearch.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSearch.SelectedText = "";
            this.txtSearch.SelectionLength = 0;
            this.txtSearch.SelectionStart = 0;
            this.txtSearch.ShortcutsEnabled = true;
            this.txtSearch.Size = new System.Drawing.Size(142, 23);
            this.txtSearch.TabIndex = 8;
            this.txtSearch.UseSelectable = true;
            this.txtSearch.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtSearch.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            this.txtSearch.TextChanged += new System.EventHandler(this.txtSearch_TextChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.Location = new System.Drawing.Point(407, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 17);
            this.label9.TabIndex = 7;
            this.label9.Text = "Ara :";
            // 
            // metroTabPage2
            // 
            this.metroTabPage2.Controls.Add(this.btnAddResimSec);
            this.metroTabPage2.Controls.Add(this.label21);
            this.metroTabPage2.Controls.Add(this.txtAddSirket);
            this.metroTabPage2.Controls.Add(this.label6);
            this.metroTabPage2.Controls.Add(this.label22);
            this.metroTabPage2.Controls.Add(this.label20);
            this.metroTabPage2.Controls.Add(this.label18);
            this.metroTabPage2.Controls.Add(this.btnAdd);
            this.metroTabPage2.Controls.Add(this.lblAddResim);
            this.metroTabPage2.Controls.Add(this.txtAddAdress);
            this.metroTabPage2.Controls.Add(this.txtAddAciklama);
            this.metroTabPage2.Controls.Add(this.txtAddWeb);
            this.metroTabPage2.Controls.Add(this.mtxtAddCepTel);
            this.metroTabPage2.Controls.Add(this.label3);
            this.metroTabPage2.Controls.Add(this.mtxtAddTel);
            this.metroTabPage2.Controls.Add(this.label8);
            this.metroTabPage2.Controls.Add(this.label7);
            this.metroTabPage2.Controls.Add(this.label2);
            this.metroTabPage2.Controls.Add(this.label1);
            this.metroTabPage2.HorizontalScrollbarBarColor = true;
            this.metroTabPage2.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.HorizontalScrollbarSize = 10;
            this.metroTabPage2.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage2.Name = "metroTabPage2";
            this.metroTabPage2.Size = new System.Drawing.Size(601, 452);
            this.metroTabPage2.TabIndex = 1;
            this.metroTabPage2.Text = "İlan Veren Ekle";
            this.metroTabPage2.VerticalScrollbarBarColor = true;
            this.metroTabPage2.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage2.VerticalScrollbarSize = 10;
            // 
            // btnAddResimSec
            // 
            this.btnAddResimSec.Location = new System.Drawing.Point(528, 179);
            this.btnAddResimSec.Name = "btnAddResimSec";
            this.btnAddResimSec.Size = new System.Drawing.Size(32, 23);
            this.btnAddResimSec.TabIndex = 91;
            this.btnAddResimSec.Text = "...";
            this.btnAddResimSec.UseSelectable = true;
            this.btnAddResimSec.Click += new System.EventHandler(this.btnAddResimSec_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.White;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label21.Location = new System.Drawing.Point(333, 43);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(23, 17);
            this.label21.TabIndex = 75;
            this.label21.Text = "(*)";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtAddSirket
            // 
            // 
            // 
            // 
            this.txtAddSirket.CustomButton.Image = null;
            this.txtAddSirket.CustomButton.Location = new System.Drawing.Point(192, 2);
            this.txtAddSirket.CustomButton.Name = "";
            this.txtAddSirket.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtAddSirket.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtAddSirket.CustomButton.TabIndex = 1;
            this.txtAddSirket.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtAddSirket.CustomButton.UseSelectable = true;
            this.txtAddSirket.CustomButton.Visible = false;
            this.txtAddSirket.Lines = new string[0];
            this.txtAddSirket.Location = new System.Drawing.Point(111, 40);
            this.txtAddSirket.MaxLength = 32767;
            this.txtAddSirket.Name = "txtAddSirket";
            this.txtAddSirket.PasswordChar = '\0';
            this.txtAddSirket.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAddSirket.SelectedText = "";
            this.txtAddSirket.SelectionLength = 0;
            this.txtAddSirket.SelectionStart = 0;
            this.txtAddSirket.ShortcutsEnabled = true;
            this.txtAddSirket.Size = new System.Drawing.Size(216, 26);
            this.txtAddSirket.TabIndex = 74;
            this.txtAddSirket.UseSelectable = true;
            this.txtAddSirket.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtAddSirket.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.Location = new System.Drawing.Point(20, 43);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(80, 17);
            this.label6.TabIndex = 73;
            this.label6.Text = "İlan Veren :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.White;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label22.Location = new System.Drawing.Point(333, 249);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(23, 17);
            this.label22.TabIndex = 72;
            this.label22.Text = "(*)";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.White;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label20.Location = new System.Drawing.Point(333, 173);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(23, 17);
            this.label20.TabIndex = 72;
            this.label20.Text = "(*)";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.White;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label18.Location = new System.Drawing.Point(333, 109);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(23, 17);
            this.label18.TabIndex = 72;
            this.label18.Text = "(*)";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(158, 377);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(281, 37);
            this.btnAdd.TabIndex = 71;
            this.btnAdd.Text = "EKLE";
            this.btnAdd.UseSelectable = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblAddResim
            // 
            this.lblAddResim.AllowDrop = true;
            this.lblAddResim.Location = new System.Drawing.Point(398, 40);
            this.lblAddResim.Name = "lblAddResim";
            this.lblAddResim.Size = new System.Drawing.Size(162, 133);
            this.lblAddResim.TabIndex = 49;
            this.lblAddResim.Text = "Resmi Sürükle Bırak (*)";
            this.lblAddResim.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblAddResim.DragDrop += new System.Windows.Forms.DragEventHandler(this.lblAddResim_DragDrop);
            this.lblAddResim.DragEnter += new System.Windows.Forms.DragEventHandler(this.lblAddResim_DragEnter);
            // 
            // txtAddAdress
            // 
            // 
            // 
            // 
            this.txtAddAdress.CustomButton.Image = null;
            this.txtAddAdress.CustomButton.Location = new System.Drawing.Point(142, 1);
            this.txtAddAdress.CustomButton.Name = "";
            this.txtAddAdress.CustomButton.Size = new System.Drawing.Size(73, 73);
            this.txtAddAdress.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtAddAdress.CustomButton.TabIndex = 1;
            this.txtAddAdress.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtAddAdress.CustomButton.UseSelectable = true;
            this.txtAddAdress.CustomButton.Visible = false;
            this.txtAddAdress.Lines = new string[0];
            this.txtAddAdress.Location = new System.Drawing.Point(111, 249);
            this.txtAddAdress.MaxLength = 32767;
            this.txtAddAdress.Multiline = true;
            this.txtAddAdress.Name = "txtAddAdress";
            this.txtAddAdress.PasswordChar = '\0';
            this.txtAddAdress.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAddAdress.SelectedText = "";
            this.txtAddAdress.SelectionLength = 0;
            this.txtAddAdress.SelectionStart = 0;
            this.txtAddAdress.ShortcutsEnabled = true;
            this.txtAddAdress.Size = new System.Drawing.Size(216, 75);
            this.txtAddAdress.TabIndex = 48;
            this.txtAddAdress.UseSelectable = true;
            this.txtAddAdress.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtAddAdress.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtAddAciklama
            // 
            // 
            // 
            // 
            this.txtAddAciklama.CustomButton.Image = null;
            this.txtAddAciklama.CustomButton.Location = new System.Drawing.Point(142, 1);
            this.txtAddAciklama.CustomButton.Name = "";
            this.txtAddAciklama.CustomButton.Size = new System.Drawing.Size(73, 73);
            this.txtAddAciklama.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtAddAciklama.CustomButton.TabIndex = 1;
            this.txtAddAciklama.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtAddAciklama.CustomButton.UseSelectable = true;
            this.txtAddAciklama.CustomButton.Visible = false;
            this.txtAddAciklama.Lines = new string[0];
            this.txtAddAciklama.Location = new System.Drawing.Point(111, 168);
            this.txtAddAciklama.MaxLength = 32767;
            this.txtAddAciklama.Multiline = true;
            this.txtAddAciklama.Name = "txtAddAciklama";
            this.txtAddAciklama.PasswordChar = '\0';
            this.txtAddAciklama.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAddAciklama.SelectedText = "";
            this.txtAddAciklama.SelectionLength = 0;
            this.txtAddAciklama.SelectionStart = 0;
            this.txtAddAciklama.ShortcutsEnabled = true;
            this.txtAddAciklama.Size = new System.Drawing.Size(216, 75);
            this.txtAddAciklama.TabIndex = 48;
            this.txtAddAciklama.UseSelectable = true;
            this.txtAddAciklama.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtAddAciklama.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtAddWeb
            // 
            // 
            // 
            // 
            this.txtAddWeb.CustomButton.Image = null;
            this.txtAddWeb.CustomButton.Location = new System.Drawing.Point(192, 2);
            this.txtAddWeb.CustomButton.Name = "";
            this.txtAddWeb.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtAddWeb.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtAddWeb.CustomButton.TabIndex = 1;
            this.txtAddWeb.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtAddWeb.CustomButton.UseSelectable = true;
            this.txtAddWeb.CustomButton.Visible = false;
            this.txtAddWeb.Lines = new string[0];
            this.txtAddWeb.Location = new System.Drawing.Point(111, 136);
            this.txtAddWeb.MaxLength = 32767;
            this.txtAddWeb.Name = "txtAddWeb";
            this.txtAddWeb.PasswordChar = '\0';
            this.txtAddWeb.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtAddWeb.SelectedText = "";
            this.txtAddWeb.SelectionLength = 0;
            this.txtAddWeb.SelectionStart = 0;
            this.txtAddWeb.ShortcutsEnabled = true;
            this.txtAddWeb.Size = new System.Drawing.Size(216, 26);
            this.txtAddWeb.TabIndex = 48;
            this.txtAddWeb.UseSelectable = true;
            this.txtAddWeb.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtAddWeb.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // mtxtAddCepTel
            // 
            this.mtxtAddCepTel.BackColor = System.Drawing.SystemColors.Window;
            this.mtxtAddCepTel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mtxtAddCepTel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.mtxtAddCepTel.Location = new System.Drawing.Point(111, 104);
            this.mtxtAddCepTel.Mask = "(999) 000-00-00";
            this.mtxtAddCepTel.Name = "mtxtAddCepTel";
            this.mtxtAddCepTel.Size = new System.Drawing.Size(216, 26);
            this.mtxtAddCepTel.TabIndex = 47;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.Location = new System.Drawing.Point(20, 254);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 17);
            this.label3.TabIndex = 41;
            this.label3.Text = "Adres :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mtxtAddTel
            // 
            this.mtxtAddTel.BackColor = System.Drawing.SystemColors.Window;
            this.mtxtAddTel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mtxtAddTel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.mtxtAddTel.Location = new System.Drawing.Point(111, 72);
            this.mtxtAddTel.Mask = "(999) 000-00-00";
            this.mtxtAddTel.Name = "mtxtAddTel";
            this.mtxtAddTel.Size = new System.Drawing.Size(216, 26);
            this.mtxtAddTel.TabIndex = 47;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.Location = new System.Drawing.Point(20, 173);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(72, 17);
            this.label8.TabIndex = 41;
            this.label8.Text = "Açıklama :";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.Location = new System.Drawing.Point(22, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(45, 17);
            this.label7.TabIndex = 41;
            this.label7.Text = "Web :";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.Location = new System.Drawing.Point(20, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 17);
            this.label2.TabIndex = 41;
            this.label2.Text = "Cep Tel. :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(20, 81);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 17);
            this.label1.TabIndex = 41;
            this.label1.Text = "Tel. :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // metroTabPage3
            // 
            this.metroTabPage3.Controls.Add(this.label19);
            this.metroTabPage3.Controls.Add(this.txtUpdateSirket);
            this.metroTabPage3.Controls.Add(this.label13);
            this.metroTabPage3.Controls.Add(this.label25);
            this.metroTabPage3.Controls.Add(this.label24);
            this.metroTabPage3.Controls.Add(this.label23);
            this.metroTabPage3.Controls.Add(this.btnUpdateResimSec);
            this.metroTabPage3.Controls.Add(this.btnUpdate);
            this.metroTabPage3.Controls.Add(this.lblUpdateResim);
            this.metroTabPage3.Controls.Add(this.txtUpdateAdres);
            this.metroTabPage3.Controls.Add(this.txtUpdateAciklama);
            this.metroTabPage3.Controls.Add(this.txtUpdateWeb);
            this.metroTabPage3.Controls.Add(this.mtxtUpdateCepTel);
            this.metroTabPage3.Controls.Add(this.label4);
            this.metroTabPage3.Controls.Add(this.mtxtUpdateTel);
            this.metroTabPage3.Controls.Add(this.label10);
            this.metroTabPage3.Controls.Add(this.label11);
            this.metroTabPage3.Controls.Add(this.label12);
            this.metroTabPage3.Controls.Add(this.label14);
            this.metroTabPage3.HorizontalScrollbarBarColor = true;
            this.metroTabPage3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.HorizontalScrollbarSize = 10;
            this.metroTabPage3.Location = new System.Drawing.Point(4, 38);
            this.metroTabPage3.Name = "metroTabPage3";
            this.metroTabPage3.Size = new System.Drawing.Size(601, 452);
            this.metroTabPage3.TabIndex = 2;
            this.metroTabPage3.Text = "İlan Veren Güncelle";
            this.metroTabPage3.VerticalScrollbarBarColor = true;
            this.metroTabPage3.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.VerticalScrollbarSize = 10;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.White;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label19.Location = new System.Drawing.Point(331, 43);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(23, 17);
            this.label19.TabIndex = 94;
            this.label19.Text = "(*)";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtUpdateSirket
            // 
            // 
            // 
            // 
            this.txtUpdateSirket.CustomButton.Image = null;
            this.txtUpdateSirket.CustomButton.Location = new System.Drawing.Point(192, 2);
            this.txtUpdateSirket.CustomButton.Name = "";
            this.txtUpdateSirket.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtUpdateSirket.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUpdateSirket.CustomButton.TabIndex = 1;
            this.txtUpdateSirket.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUpdateSirket.CustomButton.UseSelectable = true;
            this.txtUpdateSirket.CustomButton.Visible = false;
            this.txtUpdateSirket.Lines = new string[0];
            this.txtUpdateSirket.Location = new System.Drawing.Point(109, 38);
            this.txtUpdateSirket.MaxLength = 32767;
            this.txtUpdateSirket.Name = "txtUpdateSirket";
            this.txtUpdateSirket.PasswordChar = '\0';
            this.txtUpdateSirket.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUpdateSirket.SelectedText = "";
            this.txtUpdateSirket.SelectionLength = 0;
            this.txtUpdateSirket.SelectionStart = 0;
            this.txtUpdateSirket.ShortcutsEnabled = true;
            this.txtUpdateSirket.Size = new System.Drawing.Size(216, 26);
            this.txtUpdateSirket.TabIndex = 93;
            this.txtUpdateSirket.UseSelectable = true;
            this.txtUpdateSirket.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUpdateSirket.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label13.Location = new System.Drawing.Point(18, 41);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(80, 17);
            this.label13.TabIndex = 92;
            this.label13.Text = "İlan Veren :";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.White;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label25.Location = new System.Drawing.Point(331, 247);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(23, 17);
            this.label25.TabIndex = 91;
            this.label25.Text = "(*)";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.White;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label24.Location = new System.Drawing.Point(331, 107);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(23, 17);
            this.label24.TabIndex = 91;
            this.label24.Text = "(*)";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.White;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label23.Location = new System.Drawing.Point(331, 166);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(23, 17);
            this.label23.TabIndex = 91;
            this.label23.Text = "(*)";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnUpdateResimSec
            // 
            this.btnUpdateResimSec.Location = new System.Drawing.Point(526, 177);
            this.btnUpdateResimSec.Name = "btnUpdateResimSec";
            this.btnUpdateResimSec.Size = new System.Drawing.Size(32, 23);
            this.btnUpdateResimSec.TabIndex = 90;
            this.btnUpdateResimSec.Text = "...";
            this.btnUpdateResimSec.UseSelectable = true;
            this.btnUpdateResimSec.Click += new System.EventHandler(this.btnUpdateResimSec_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(156, 379);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(281, 37);
            this.btnUpdate.TabIndex = 89;
            this.btnUpdate.Text = "GÜNCELLE";
            this.btnUpdate.UseSelectable = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // lblUpdateResim
            // 
            this.lblUpdateResim.AllowDrop = true;
            this.lblUpdateResim.Location = new System.Drawing.Point(396, 38);
            this.lblUpdateResim.Name = "lblUpdateResim";
            this.lblUpdateResim.Size = new System.Drawing.Size(162, 133);
            this.lblUpdateResim.TabIndex = 88;
            this.lblUpdateResim.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblUpdateResim.DragDrop += new System.Windows.Forms.DragEventHandler(this.lblUpdateResim_DragDrop);
            this.lblUpdateResim.DragEnter += new System.Windows.Forms.DragEventHandler(this.lblUpdateResim_DragEnter);
            // 
            // txtUpdateAdres
            // 
            // 
            // 
            // 
            this.txtUpdateAdres.CustomButton.Image = null;
            this.txtUpdateAdres.CustomButton.Location = new System.Drawing.Point(142, 1);
            this.txtUpdateAdres.CustomButton.Name = "";
            this.txtUpdateAdres.CustomButton.Size = new System.Drawing.Size(73, 73);
            this.txtUpdateAdres.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUpdateAdres.CustomButton.TabIndex = 1;
            this.txtUpdateAdres.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUpdateAdres.CustomButton.UseSelectable = true;
            this.txtUpdateAdres.CustomButton.Visible = false;
            this.txtUpdateAdres.Lines = new string[0];
            this.txtUpdateAdres.Location = new System.Drawing.Point(109, 247);
            this.txtUpdateAdres.MaxLength = 32767;
            this.txtUpdateAdres.Multiline = true;
            this.txtUpdateAdres.Name = "txtUpdateAdres";
            this.txtUpdateAdres.PasswordChar = '\0';
            this.txtUpdateAdres.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUpdateAdres.SelectedText = "";
            this.txtUpdateAdres.SelectionLength = 0;
            this.txtUpdateAdres.SelectionStart = 0;
            this.txtUpdateAdres.ShortcutsEnabled = true;
            this.txtUpdateAdres.Size = new System.Drawing.Size(216, 75);
            this.txtUpdateAdres.TabIndex = 87;
            this.txtUpdateAdres.UseSelectable = true;
            this.txtUpdateAdres.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUpdateAdres.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtUpdateAciklama
            // 
            // 
            // 
            // 
            this.txtUpdateAciklama.CustomButton.Image = null;
            this.txtUpdateAciklama.CustomButton.Location = new System.Drawing.Point(142, 1);
            this.txtUpdateAciklama.CustomButton.Name = "";
            this.txtUpdateAciklama.CustomButton.Size = new System.Drawing.Size(73, 73);
            this.txtUpdateAciklama.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUpdateAciklama.CustomButton.TabIndex = 1;
            this.txtUpdateAciklama.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUpdateAciklama.CustomButton.UseSelectable = true;
            this.txtUpdateAciklama.CustomButton.Visible = false;
            this.txtUpdateAciklama.Lines = new string[0];
            this.txtUpdateAciklama.Location = new System.Drawing.Point(109, 166);
            this.txtUpdateAciklama.MaxLength = 32767;
            this.txtUpdateAciklama.Multiline = true;
            this.txtUpdateAciklama.Name = "txtUpdateAciklama";
            this.txtUpdateAciklama.PasswordChar = '\0';
            this.txtUpdateAciklama.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUpdateAciklama.SelectedText = "";
            this.txtUpdateAciklama.SelectionLength = 0;
            this.txtUpdateAciklama.SelectionStart = 0;
            this.txtUpdateAciklama.ShortcutsEnabled = true;
            this.txtUpdateAciklama.Size = new System.Drawing.Size(216, 75);
            this.txtUpdateAciklama.TabIndex = 87;
            this.txtUpdateAciklama.UseSelectable = true;
            this.txtUpdateAciklama.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUpdateAciklama.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtUpdateWeb
            // 
            // 
            // 
            // 
            this.txtUpdateWeb.CustomButton.Image = null;
            this.txtUpdateWeb.CustomButton.Location = new System.Drawing.Point(192, 2);
            this.txtUpdateWeb.CustomButton.Name = "";
            this.txtUpdateWeb.CustomButton.Size = new System.Drawing.Size(21, 21);
            this.txtUpdateWeb.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUpdateWeb.CustomButton.TabIndex = 1;
            this.txtUpdateWeb.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUpdateWeb.CustomButton.UseSelectable = true;
            this.txtUpdateWeb.CustomButton.Visible = false;
            this.txtUpdateWeb.Lines = new string[0];
            this.txtUpdateWeb.Location = new System.Drawing.Point(109, 134);
            this.txtUpdateWeb.MaxLength = 32767;
            this.txtUpdateWeb.Name = "txtUpdateWeb";
            this.txtUpdateWeb.PasswordChar = '\0';
            this.txtUpdateWeb.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUpdateWeb.SelectedText = "";
            this.txtUpdateWeb.SelectionLength = 0;
            this.txtUpdateWeb.SelectionStart = 0;
            this.txtUpdateWeb.ShortcutsEnabled = true;
            this.txtUpdateWeb.Size = new System.Drawing.Size(216, 26);
            this.txtUpdateWeb.TabIndex = 86;
            this.txtUpdateWeb.UseSelectable = true;
            this.txtUpdateWeb.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUpdateWeb.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // mtxtUpdateCepTel
            // 
            this.mtxtUpdateCepTel.BackColor = System.Drawing.SystemColors.Window;
            this.mtxtUpdateCepTel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mtxtUpdateCepTel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.mtxtUpdateCepTel.Location = new System.Drawing.Point(109, 102);
            this.mtxtUpdateCepTel.Mask = "(999) 000-00-00";
            this.mtxtUpdateCepTel.Name = "mtxtUpdateCepTel";
            this.mtxtUpdateCepTel.Size = new System.Drawing.Size(216, 26);
            this.mtxtUpdateCepTel.TabIndex = 84;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.Location = new System.Drawing.Point(18, 252);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 17);
            this.label4.TabIndex = 77;
            this.label4.Text = "Adres :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mtxtUpdateTel
            // 
            this.mtxtUpdateTel.BackColor = System.Drawing.SystemColors.Window;
            this.mtxtUpdateTel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mtxtUpdateTel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.mtxtUpdateTel.Location = new System.Drawing.Point(109, 70);
            this.mtxtUpdateTel.Mask = "(999) 000-00-00";
            this.mtxtUpdateTel.Name = "mtxtUpdateTel";
            this.mtxtUpdateTel.Size = new System.Drawing.Size(216, 26);
            this.mtxtUpdateTel.TabIndex = 83;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.Location = new System.Drawing.Point(18, 171);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 17);
            this.label10.TabIndex = 77;
            this.label10.Text = "Açıklama :";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.Location = new System.Drawing.Point(20, 139);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 17);
            this.label11.TabIndex = 76;
            this.label11.Text = "Web :";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label12.Location = new System.Drawing.Point(18, 107);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 17);
            this.label12.TabIndex = 75;
            this.label12.Text = "Cep Tel. :";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label14.Location = new System.Drawing.Point(18, 79);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(40, 17);
            this.label14.TabIndex = 73;
            this.label14.Text = "Tel. :";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // metroToolTip1
            // 
            this.metroToolTip1.Style = MetroFramework.MetroColorStyle.Blue;
            this.metroToolTip1.StyleManager = null;
            this.metroToolTip1.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // frmIlanVeren
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(609, 494);
            this.Controls.Add(this.metroTabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmIlanVeren";
            this.Text = "frmIlanVeren";
            this.Load += new System.EventHandler(this.frmIlanVeren_Load);
            this.metroTabControl1.ResumeLayout(false);
            this.metroTabPage1.ResumeLayout(false);
            this.metroTabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dGwIlanVerenler)).EndInit();
            this.metroContextMenuIlanVeren.ResumeLayout(false);
            this.metroTabPage2.ResumeLayout(false);
            this.metroTabPage2.PerformLayout();
            this.metroTabPage3.ResumeLayout(false);
            this.metroTabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroTabControl metroTabControl1;
        private MetroFramework.Controls.MetroTabPage metroTabPage1;
        private MetroFramework.Controls.MetroTabPage metroTabPage2;
        private MetroFramework.Controls.MetroTabPage metroTabPage3;
        private System.Windows.Forms.MaskedTextBox mtxtAddTel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MaskedTextBox mtxtAddCepTel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblAddResim;
        private MetroFramework.Controls.MetroTextBox txtAddAciklama;
        private MetroFramework.Controls.MetroTextBox txtAddWeb;
        private System.Windows.Forms.Label label8;
        private MetroFramework.Controls.MetroButton btnAdd;
        private MetroFramework.Controls.MetroButton btnUpdate;
        private System.Windows.Forms.Label lblUpdateResim;
        private MetroFramework.Controls.MetroTextBox txtUpdateAciklama;
        private MetroFramework.Controls.MetroTextBox txtUpdateWeb;
        private System.Windows.Forms.MaskedTextBox mtxtUpdateCepTel;
        private System.Windows.Forms.MaskedTextBox mtxtUpdateTel;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblToplam;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.DataGridView dGwIlanVerenler;
        private MetroFramework.Controls.MetroTextBox txtSearch;
        private System.Windows.Forms.Label label9;
        private MetroFramework.Controls.MetroButton btnUpdateResimSec;
        private System.Windows.Forms.Label label21;
        private MetroFramework.Controls.MetroTextBox txtAddSirket;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private MetroFramework.Controls.MetroButton btnAddResimSec;
        private MetroFramework.Controls.MetroContextMenu metroContextMenuIlanVeren;
        private System.Windows.Forms.ToolStripMenuItem güncelleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem silToolStripMenuItem;
        private System.Windows.Forms.Label label19;
        private MetroFramework.Controls.MetroTextBox txtUpdateSirket;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private MetroFramework.Controls.MetroTextBox txtAddAdress;
        private System.Windows.Forms.Label label3;
        private MetroFramework.Controls.MetroTextBox txtUpdateAdres;
        private System.Windows.Forms.Label label4;
        private MetroFramework.Components.MetroToolTip metroToolTip1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.HelpProvider helpProvider1;
    }
}