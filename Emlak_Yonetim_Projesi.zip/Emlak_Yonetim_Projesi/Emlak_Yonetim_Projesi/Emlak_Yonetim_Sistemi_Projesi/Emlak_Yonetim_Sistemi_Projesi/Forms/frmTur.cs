﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Emlak_Yonetim_Sistemi_Projesi.Forms
{
    public partial class frmTur : Form
    {
        public frmTur()
        {
            InitializeComponent();
        }


        EmlakContext db = new EmlakContext();
        int secilenID;
        private void frmTur_Load(object sender, EventArgs e)
        {

            txtName.Focus();
            TipleriGetir();
        }

        private void TipleriGetir()
        {
            lstTipler.Items.Clear();

            // Linq dilini kullanarak Query Syntax yazı biçimini kullandık.

            var turler = db.IlanTurleri;
            var list = from t in turler select t;

            foreach (IlanTuru t in list)
            {
                lstTipler.Items.Add(t);
                lstTipler.DisplayMember = "IlanTuruAdi";
            }

            lblToplam.Text = "Toplam = " + lstTipler.Items.Count.ToString();
        }
        //------------------------------
        // Ekle
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                IlanTuru tip = new IlanTuru();

                tip.IlanTuruAdi = txtName.Text;

                if (txtName.Text == "") // Alan boş ise
                {
                    frmCustomMsgBx.Show("Lütfen Tüm Alanları Doldurunuz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                db.IlanTurleri.Add(tip);
                db.SaveChanges();

                TipleriGetir();

                txtName.Clear();
                txtName.Focus();
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //------------------------------
        // Güncelle
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                IlanTuru tip = db.IlanTurleri.Find(secilenID);

                tip.IlanTuruAdi = txtName.Text;

                if (txtName.Text == "") // Alan boş ise
                {
                    frmCustomMsgBx.Show("Lütfen Tüm Alanları Doldurunuz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }
                
                db.SaveChanges();

                TipleriGetir();

                txtName.Clear();
                txtName.Focus();
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                IlanTuru tip = db.IlanTurleri.Find(secilenID);

                if (frmCustomMsgBx.Show("Silmek İstediğinize Emin Misiniz?", frmCustomMsgBx.CustomMsgbxButtons.YesNo) == DialogResult.Yes)
                {
                    db.IlanTurleri.Remove(tip);
                    db.SaveChanges();
                }

                TipleriGetir();

                txtName.Clear();
                txtName.Focus();
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }

        private void lstTipler_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstTipler.SelectedItem != null)
            {
                IlanTuru secilenItem = lstTipler.SelectedItem as IlanTuru;
                secilenID = Convert.ToInt32(secilenItem.IlanTuruID);

                // Linq dilini kullanarak Query Syntax yazı biçimini kullandık.
                var tipler = db.IlanTurleri;
                var tip = from t in tipler where t.IlanTuruID == secilenID  select t;

                txtName.Text = tip.First().IlanTuruAdi;
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtName.Clear();
            txtName.Focus();
        }
    }
}
