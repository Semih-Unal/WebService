﻿namespace Emlak_Yonetim_Sistemi_Projesi.Forms
{
    partial class frmKullanici
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClear = new MetroFramework.Controls.MetroButton();
            this.btnDelete = new MetroFramework.Controls.MetroButton();
            this.btnUpdate = new MetroFramework.Controls.MetroButton();
            this.btnAdd = new MetroFramework.Controls.MetroButton();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.txtKullanici = new MetroFramework.Controls.MetroTextBox();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.txtSifre = new MetroFramework.Controls.MetroTextBox();
            this.tooltipSifre = new MetroFramework.Components.MetroToolTip();
            this.dGwKullanicilar = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dGwKullanicilar)).BeginInit();
            this.SuspendLayout();
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(104, 121);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(60, 23);
            this.btnClear.TabIndex = 37;
            this.btnClear.Text = "Temizle";
            this.btnClear.UseSelectable = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(317, 121);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(65, 23);
            this.btnDelete.TabIndex = 34;
            this.btnDelete.Text = "Sil";
            this.btnDelete.UseSelectable = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(243, 121);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(68, 23);
            this.btnUpdate.TabIndex = 35;
            this.btnUpdate.Text = "Güncelle";
            this.btnUpdate.UseSelectable = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(171, 121);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(67, 23);
            this.btnAdd.TabIndex = 36;
            this.btnAdd.Text = "Ekle";
            this.btnAdd.UseSelectable = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel3.Location = new System.Drawing.Point(39, 48);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(100, 19);
            this.metroLabel3.TabIndex = 31;
            this.metroLabel3.Text = "Kullanıcı Adı :";
            // 
            // txtKullanici
            // 
            // 
            // 
            // 
            this.txtKullanici.CustomButton.Image = null;
            this.txtKullanici.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtKullanici.CustomButton.Name = "";
            this.txtKullanici.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtKullanici.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtKullanici.CustomButton.TabIndex = 1;
            this.txtKullanici.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtKullanici.CustomButton.UseSelectable = true;
            this.txtKullanici.CustomButton.Visible = false;
            this.txtKullanici.Lines = new string[0];
            this.txtKullanici.Location = new System.Drawing.Point(145, 44);
            this.txtKullanici.MaxLength = 32767;
            this.txtKullanici.Name = "txtKullanici";
            this.txtKullanici.PasswordChar = '\0';
            this.txtKullanici.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtKullanici.SelectedText = "";
            this.txtKullanici.SelectionLength = 0;
            this.txtKullanici.SelectionStart = 0;
            this.txtKullanici.ShortcutsEnabled = true;
            this.txtKullanici.Size = new System.Drawing.Size(237, 25);
            this.txtKullanici.TabIndex = 32;
            this.tooltipSifre.SetToolTip(this.txtKullanici, "Giriş yapmak için kullanılacak");
            this.txtKullanici.UseSelectable = true;
            this.txtKullanici.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtKullanici.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel4.Location = new System.Drawing.Point(39, 79);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(48, 19);
            this.metroLabel4.TabIndex = 31;
            this.metroLabel4.Text = "Şifre :";
            // 
            // txtSifre
            // 
            // 
            // 
            // 
            this.txtSifre.CustomButton.Image = null;
            this.txtSifre.CustomButton.Location = new System.Drawing.Point(213, 1);
            this.txtSifre.CustomButton.Name = "";
            this.txtSifre.CustomButton.Size = new System.Drawing.Size(23, 23);
            this.txtSifre.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtSifre.CustomButton.TabIndex = 1;
            this.txtSifre.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtSifre.CustomButton.UseSelectable = true;
            this.txtSifre.CustomButton.Visible = false;
            this.txtSifre.Lines = new string[0];
            this.txtSifre.Location = new System.Drawing.Point(145, 75);
            this.txtSifre.MaxLength = 32767;
            this.txtSifre.Name = "txtSifre";
            this.txtSifre.PasswordChar = '\0';
            this.txtSifre.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtSifre.SelectedText = "";
            this.txtSifre.SelectionLength = 0;
            this.txtSifre.SelectionStart = 0;
            this.txtSifre.ShortcutsEnabled = true;
            this.txtSifre.Size = new System.Drawing.Size(237, 25);
            this.txtSifre.TabIndex = 32;
            this.tooltipSifre.SetToolTip(this.txtSifre, "En az 6 karakter içermelidir.");
            this.txtSifre.UseSelectable = true;
            this.txtSifre.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtSifre.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // tooltipSifre
            // 
            this.tooltipSifre.Style = MetroFramework.MetroColorStyle.Blue;
            this.tooltipSifre.StyleManager = null;
            this.tooltipSifre.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // dGwKullanicilar
            // 
            this.dGwKullanicilar.AllowUserToAddRows = false;
            this.dGwKullanicilar.AllowUserToOrderColumns = true;
            this.dGwKullanicilar.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            this.dGwKullanicilar.Location = new System.Drawing.Point(39, 169);
            this.dGwKullanicilar.MultiSelect = false;
            this.dGwKullanicilar.Name = "dGwKullanicilar";
            this.dGwKullanicilar.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dGwKullanicilar.Size = new System.Drawing.Size(343, 244);
            this.dGwKullanicilar.TabIndex = 39;
            this.dGwKullanicilar.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGwKullanicilar_CellClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "ID";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Kullanıcı Adı";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Şifre";
            this.Column3.Name = "Column3";
            // 
            // frmKullanici
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(412, 448);
            this.Controls.Add(this.dGwKullanicilar);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtSifre);
            this.Controls.Add(this.metroLabel4);
            this.Controls.Add(this.txtKullanici);
            this.Controls.Add(this.metroLabel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmKullanici";
            this.Text = "frmKullanici";
            this.Load += new System.EventHandler(this.frmKullanici_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dGwKullanicilar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Controls.MetroButton btnClear;
        private MetroFramework.Controls.MetroButton btnDelete;
        private MetroFramework.Controls.MetroButton btnUpdate;
        private MetroFramework.Controls.MetroButton btnAdd;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroTextBox txtKullanici;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroTextBox txtSifre;
        private MetroFramework.Components.MetroToolTip tooltipSifre;
        private System.Windows.Forms.DataGridView dGwKullanicilar;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
    }
}