﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Emlak_Yonetim_Sistemi_Projesi.Forms
{
    public partial class frmCustomMsgBx : Form
    {
        public frmCustomMsgBx()
        {
            InitializeComponent();
        }

        static frmCustomMsgBx MsgBox;

        static DialogResult result = DialogResult.OK;

        public enum CustomMsgbxButtons
        {
            YesNo = 1,
            OK = 2
        }

        public static DialogResult Show(string mesaj, CustomMsgbxButtons boxButtons) 
        {
            
            MsgBox = new frmCustomMsgBx();
            MsgBox.lblMessage.Text = mesaj;

            if ((int)boxButtons == 1) // YesNo seçilirse
            {
                MsgBox.btnMsgOk.Location = new Point(131, 127);
                MsgBox.btnMsgOk.Text = "Evet";
                MsgBox.btnNo.Text = "Hayır";

            }
            else if ((int)boxButtons == 2) // Ok seçilirse
            {
                MsgBox.btnMsgOk.Location = new Point(170, 127);
                MsgBox.btnMsgOk.Text = "Tamam";
                MsgBox.btnNo.Visible = false;
            }
            MsgBox.ShowDialog();
            return result;
        }
        private void btnMsgOk_Click(object sender, EventArgs e)
        {
            result = DialogResult.Yes; MsgBox.Close(); // Evet
        }

        private void btnNo_Click(object sender, EventArgs e)
        {
            result = DialogResult.No; MsgBox.Close(); // Hayır
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            MsgBox.Close();
        }

    }
}
