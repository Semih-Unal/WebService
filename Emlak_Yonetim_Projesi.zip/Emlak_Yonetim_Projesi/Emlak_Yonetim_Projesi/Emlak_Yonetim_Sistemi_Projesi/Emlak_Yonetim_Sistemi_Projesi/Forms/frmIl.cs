﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//-------------


namespace Emlak_Yonetim_Sistemi_Projesi.Forms
{
    public partial class frmIl : Form
    {
        public frmIl()
        {
            InitializeComponent();
        }
        
        // Linq dilini kullanarak Lambda Syntax yazı biçimini kullandık.

        EmlakContext db = new EmlakContext(); // Database'i çek ...

        int secilenID;


        private void frmIl_Load(object sender, EventArgs e)
        {
            metroTabControl1.SelectedIndex = 0;
            //---------------------
            // İl
            IlleriGetir(); // İller ListBox'ı için metodu altta ...
            //--------------------
            // İlçe
            TumIlceleriGetir(); // İlçeler ListBox'ı için metodu altta ...
            ComboBxIlDoldur(); // İller Combox'ı için metodu altta ...
            //--------------------
            // Semt
            TumSemtleriGetir(); // Semtler ListBox'ı için metodu altta ...
            ComboBxIlceDoldur(); // İlçeler Combox'ı için metodu altta ...

        }


        #region Load Metotları
        private void IlleriGetir()
        {
            lstCities.Items.Clear();

            var ilList = db.Iller.OrderBy(i => i.IlAdi).ToList();

            foreach (Il il in ilList)
            {
                lstCities.Items.Add(il);
                lstCities.DisplayMember = "IlAdi";
            }
            lblToplamIl.Text = "Toplam = " + ilList.Count().ToString();
        }
        private void TumIlceleriGetir()
        {
            lstCountries.Items.Clear();

            var ilceList = db.Ilceler.OrderBy(c => c.IlceAdi).ToList();

            foreach (Ilce ilce in ilceList)
            {
                lstCountries.Items.Add(ilce);
                lstCountries.DisplayMember = "IlceAdi";
            }

            lblToplamIlce.Text = "Toplam = " + lstCountries.Items.Count.ToString();
        }

        private void ComboBxIlDoldur()
        {
            cbCities.DataSource = db.Iller.OrderBy(i => i.IlAdi).ToList();
            cbCities.DisplayMember = "IlAdi";
            cbCities.ValueMember = "IlID";
        }

        private void TumSemtleriGetir()
        {
            lstParts.Items.Clear();

            var semtList = db.Semtler.ToList();

            foreach (Semt s in semtList)
            {
                lstParts.Items.Add(s);
                lstParts.DisplayMember = "SemtAdi";
            }
            lblToplamSemt.Text = "Toplam = " + lstParts.Items.Count.ToString();
        }

        private void ComboBxIlceDoldur()
        {
            cbCountries.DataSource = db.Ilceler.OrderBy(ic => ic.IlceAdi).ToList();
            cbCountries.DisplayMember = "IlceAdi";
            cbCountries.ValueMember = "IlceID";
        }
        #endregion

        //-------------------------------------------------

        #region İl
        private void lstCities_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstCities.SelectedItem != null)
            {
                Il secilenItem = lstCities.SelectedItem as Il;
                secilenID = Convert.ToInt32(secilenItem.IlID);

                Il il = db.Iller.Find(secilenID);

                txtCityName.Text = il.IlAdi;
            }
        }
        //--------------
        // Ekle
        private void btnCityAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Il il = new Il();

                il.IlAdi = txtCityName.Text;

                if (txtCityName.Text == "") // Alan boş ise
                {
                    frmCustomMsgBx.Show("Lütfen Tüm Alanları Doldurunuz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                db.Iller.Add(il);
                db.SaveChanges();

                IlleriGetir(); // ListBox'ı Doldur.
                Temizle(); // Tüm alanları temizler.
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //--------------
        // Güncelle
        private void btnCityUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstCities.SelectedItem == null)
                {
                    frmCustomMsgBx.Show("Lütfen Bir İl Seçiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                Il il = db.Iller.Find(secilenID);

                il.IlAdi = txtCityName.Text;

                if (txtCityName.Text == "")
                {
                    frmCustomMsgBx.Show("Lütfen Tüm Alanları Doldurunuz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                db.SaveChanges();

                IlleriGetir(); // ListBox'ı Doldur.
                Temizle(); // Tüm alanları temizler.
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //--------------
        // Sil
        private void btnCityDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstCities.SelectedItem == null)
                {
                    frmCustomMsgBx.Show("Lütfen Bir İl Seçiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                Il il = db.Iller.Find(secilenID);
                if (frmCustomMsgBx.Show("Silmek İstediğinize Emin Misiniz?", frmCustomMsgBx.CustomMsgbxButtons.YesNo) == DialogResult.Yes)
                {
                    db.Iller.Remove(il);
                    db.SaveChanges();
                }
                IlleriGetir(); // ListBox'ı Doldur.
                Temizle(); // Tüm alanları temizler.
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //--------------
        // Temizle
        private void btnCityClear_Click(object sender, EventArgs e)
        {
            Temizle(); // metodu Altta
        }

        #endregion

        //-------------------------------------------------

        #region İlce

        private void cbCities_SelectionChangeCommitted(object sender, EventArgs e)
        {
            IlceleriGetir(); // ListBox'ı Doldur.
            Temizle();
        }

        private void lstCountries_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstCountries.SelectedItem != null)
            {
                Ilce secilenItem = lstCountries.SelectedItem as Ilce;
                secilenID = Convert.ToInt32(secilenItem.IlceID);

                Ilce ilce = db.Ilceler.Find(secilenID);

                txtCountyName.Text = ilce.IlceAdi;
                cbCities.SelectedValue = ilce.IlID;
            }
        }
        //--------------
        // Ekle
        private void btnCountryAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Ilce ilce = new Ilce();

                ilce.IlceAdi = txtCountyName.Text;
                ilce.IlID = (int)cbCities.SelectedValue;

                if (txtCountyName.Text == "" || cbCities.SelectedItem == null) // Alan boş ise
                {
                    frmCustomMsgBx.Show("Lütfen Tüm Alanları Doldurunuz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }
                db.Ilceler.Add(ilce);
                db.SaveChanges();

                IlceleriGetir(); // ListBox'ı Doldur.
                Temizle(); // Tüm alanları temizler.
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
}
        //--------------
        // Güncelle
        private void btnCountryUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstCountries.SelectedItem == null)
                {
                    frmCustomMsgBx.Show("Lütfen Bir İlçe Seçiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                Ilce ilce = db.Ilceler.Find(secilenID);

                ilce.IlceAdi = txtCountyName.Text;
                ilce.IlID = (int)cbCities.SelectedValue;

                if (txtCountyName.Text == "" || cbCities.SelectedItem == null)
                {
                    frmCustomMsgBx.Show("Lütfen Tüm Alanları Doldurunuz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                db.SaveChanges();

                IlceleriGetir(); // ListBox'ı Doldur.
                Temizle(); // Tüm alanları temizler.
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //--------------
        // Sil
        private void btnCountryDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstCountries.SelectedItem == null)
                {
                    frmCustomMsgBx.Show("Lütfen Bir İlçe Seçiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                Ilce ilce = db.Ilceler.Find(secilenID);
                if (frmCustomMsgBx.Show("Silmek İstediğinize Emin Misiniz?", frmCustomMsgBx.CustomMsgbxButtons.YesNo) == DialogResult.Yes)
                {
                    db.Ilceler.Remove(ilce);
                    db.SaveChanges();
                }

                IlceleriGetir(); // ListBox'ı Doldur.
                Temizle(); // Tüm alanları temizler.
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //--------------
        // Temizle
        private void btnCountryClear_Click(object sender, EventArgs e)
        {
            Temizle();
        }
        //--------------
        // Metot
        private void IlceleriGetir()
        {
            lstCountries.Items.Clear();


            var ilceList = db.Ilceler.Where(c => c.IlID == (int)cbCities.SelectedValue).OrderBy(c => c.IlceAdi).ToList();

            foreach (Ilce ilce in ilceList)
            {
                lstCountries.Items.Add(ilce);
                lstCountries.DisplayMember = "IlceAdi";
            }
            
            lblToplamIlce.Text = "Toplam : " + lstCountries.Items.Count.ToString();
        }
        #endregion

        //-------------------------------------------------

        #region Semt

        private void cbCountries_SelectionChangeCommitted(object sender, EventArgs e)
        {
            SemtleriGetir();
            Temizle();
        }

        private void lstParts_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstParts.SelectedItem != null)
            {
                Semt secilenItem = lstParts.SelectedItem as Semt;
                secilenID = Convert.ToInt32(secilenItem.SemtID);

                Semt semt = db.Semtler.Find(secilenID);

                txtPartName.Text = semt.SemtAdi;
                cbCountries.SelectedValue = semt.IlceID;
            }
        }
        //--------------
        // Ekle
        private void btnPartAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Semt smt = new Semt();

                smt.SemtAdi = txtPartName.Text;
                smt.IlceID = (int)cbCountries.SelectedValue;

                if (txtPartName.Text == "" || cbCountries.SelectedItem == null) // Alan boş ise
                {
                    frmCustomMsgBx.Show("Lütfen Tüm Alanları Doldurunuz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }
                db.Semtler.Add(smt);
                db.SaveChanges();

                SemtleriGetir(); // ListBox'ı Doldur.
                Temizle(); // Tüm alanları temizler.
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //--------------
        // Güncelle
        private void btnPartUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstParts.SelectedItem == null)
                {
                    frmCustomMsgBx.Show("Lütfen Bir Semt Seçiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                Semt smt = db.Semtler.Find(secilenID);

                smt.SemtAdi = txtPartName.Text;
                smt.IlceID = (int)cbCountries.SelectedValue;

                if (txtPartName.Text == "" || cbCountries.SelectedItem == null)
                {
                    frmCustomMsgBx.Show("Lütfen Tüm Alanları Doldurunuz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                db.SaveChanges();

                SemtleriGetir(); // ListBox'ı Doldur.
                Temizle(); // Tüm alanları temizler.
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //--------------
        // Sil
        private void btnPartDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstParts.SelectedItem == null)
                {
                    frmCustomMsgBx.Show("Lütfen Bir Semt Seçiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
                    return;
                }

                Semt smt = db.Semtler.Find(secilenID);

                if (frmCustomMsgBx.Show("Silmek İstediğinize Emin Misiniz?", frmCustomMsgBx.CustomMsgbxButtons.YesNo) == DialogResult.Yes)
                {
                    db.Semtler.Remove(smt);
                    db.SaveChanges();
                }

                SemtleriGetir(); // ListBox'ı Doldur.
                Temizle(); // Tüm alanları temizler.
            }
            catch (Exception)
            {
                frmCustomMsgBx.Show("Hata ile karşılaşıldı, tekrar deneyiniz !!!", frmCustomMsgBx.CustomMsgbxButtons.OK);
            }
        }
        //--------------
        // Temizle
        private void btnPartClear_Click(object sender, EventArgs e)
        {
            Temizle();
        }
        //--------------
        // Metot
        private void SemtleriGetir()
        {
            lstParts.Items.Clear();


            var semtList = db.Semtler.Where(s => s.IlceID == (int)cbCountries.SelectedValue).OrderBy(s => s.SemtAdi).ToList();

            foreach (Semt s in semtList)
            {
                lstParts.Items.Add(s);
                lstParts.DisplayMember = "SemtAdi";
            }

            lblToplamSemt.Text = "Toplam : " + lstParts.Items.Count.ToString();
        }

        #endregion
        //-------------------------------------------------

        private void metroTabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Temizle();
            // İl
            IlleriGetir(); // İller ListBox'ı için 
            //--------------------
            // İlçe
            TumIlceleriGetir(); // İlçeler ListBox'ı için 
            ComboBxIlDoldur(); // İller Combox'ı için 
            //--------------------
            // Semt
            TumSemtleriGetir(); // Semtler ListBox'ı 
            ComboBxIlceDoldur(); // İlçeler Combox'ı 
            cbCities.SelectedIndex = -1;
            cbCountries.SelectedIndex = -1;
        }

        private void Temizle()
        {
            txtCityName.Clear();
            txtCountyName.Text = "";
            txtPartName.Clear();


            lstCities.SelectedIndex = -1;
            lstCountries.SelectedIndex = -1;
            lstParts.SelectedIndex = -1;

            secilenID = 0;
        }

    }
}
