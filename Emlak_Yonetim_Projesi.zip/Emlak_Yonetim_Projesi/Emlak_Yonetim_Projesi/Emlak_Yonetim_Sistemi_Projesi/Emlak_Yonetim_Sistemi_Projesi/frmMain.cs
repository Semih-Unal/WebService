﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MyLoginScreen;

namespace Emlak_Yonetim_Sistemi_Projesi
{
    public partial class frmMain : MetroFramework.Forms.MetroForm
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            splitContainer1.Panel2.AutoScroll = true;
            btnIlan.PerformClick();// Butona tıklandı olayını verme
        }
        //----------------------------------------
        // İlanlar
        private void btnIlan_Click(object sender, EventArgs e)
        {
            PaneliTemizle(); // Açık formları kapat ve Paneli Temizle

            Forms.frmIlan frm = new Forms.frmIlan();
            frm.TopLevel = false;
            metroPanelForm.Controls.Add(frm);
            frm.Show();
            frm.Dock = DockStyle.Fill;
            frm.BringToFront();
            
        }
        //----------------------------------------
        // İlan Verenler
        private void btnIlanVeren_Click(object sender, EventArgs e)
        {
            PaneliTemizle(); // Açık formları kapat ve Paneli Temizle

            Forms.frmIlanVeren frm = new Forms.frmIlanVeren();
            frm.TopLevel = false;
            metroPanelForm.Controls.Add(frm);
            frm.Show();
            frm.Dock = DockStyle.Fill;
            frm.BringToFront();
        }
        //----------------------------------------
        // İlan Kategorileri
        private void btnKategori_Click(object sender, EventArgs e)
        {
            PaneliTemizle(); // Açık formları kapat ve Paneli Temizle

            Forms.frmKategori frm = new Forms.frmKategori();
            frm.TopLevel = false;
            metroPanelForm.Controls.Add(frm);
            frm.Show();
            frm.Dock = DockStyle.Fill;
            frm.BringToFront();
        }
        //----------------------------------------
        // İlan Tipleri
        private void btnIlanTipi_Click(object sender, EventArgs e)
        {
            PaneliTemizle(); // Açık formları kapat ve Paneli Temizle

            Forms.frmTur frm = new Forms.frmTur();
            frm.TopLevel = false;
            metroPanelForm.Controls.Add(frm);
            frm.Show();
            frm.Dock = DockStyle.Fill;
            frm.BringToFront();
        }
        //----------------------------------------
        // İl/İlçe/Semt
        private void btnSemt_Click(object sender, EventArgs e)
        {
            PaneliTemizle(); // Açık formları kapat ve Paneli Temizle

            Forms.frmIl frm = new Forms.frmIl();
            frm.TopLevel = false;
            metroPanelForm.Controls.Add(frm);
            frm.Show();
            frm.Dock = DockStyle.Fill;
            frm.BringToFront();
        }
        //----------------------------------------
        // Kullanıcı
        private void btnKullanici_Click(object sender, EventArgs e)
        {
            PaneliTemizle(); // Açık formları kapat ve Paneli Temizle
            
            Forms.frmKullanici frm = new Forms.frmKullanici();
            frm.TopLevel = false;
            metroPanelForm.Controls.Add(frm);
            frm.Show();
            frm.Dock = DockStyle.Fill;
            frm.BringToFront();
        }
        //----------------------------------------
        // Çıkış
        private void btnCikis_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void PaneliTemizle()
        {
            if (metroPanelForm.Controls.Count > 0) // panelin içi dolu ise
            {

                foreach (var frm in metroPanelForm.Controls) // Panelin kontrolü
                {
                    if (frm is Form) // Form ise
                    {
                        Form f = frm as Form; // Form tipine çevir
                        f.Close();
                    }
                }
                metroPanelForm.Controls.Clear();
            }
        }

    }
}
