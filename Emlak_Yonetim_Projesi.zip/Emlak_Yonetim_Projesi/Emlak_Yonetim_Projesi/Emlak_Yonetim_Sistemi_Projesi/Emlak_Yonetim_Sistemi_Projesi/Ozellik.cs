﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Emlak_Yonetim_Sistemi_Projesi
{
    public class Ozellik
    {
        public int KategoriOzellikID { get; set; }
        public int IlanDetayID { get; set; }
        public string Adi { get; set; }
        public string Aciklama { get; set; }

        public override string ToString()
        {
            return this.Adi + " -> " + this.Aciklama;
        }
    }
}
