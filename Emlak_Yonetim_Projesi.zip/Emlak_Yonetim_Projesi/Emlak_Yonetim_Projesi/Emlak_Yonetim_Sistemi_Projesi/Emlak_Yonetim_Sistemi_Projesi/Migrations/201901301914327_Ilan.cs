namespace Emlak_Yonetim_Sistemi_Projesi.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Ilan : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.AltKategori",
                c => new
                    {
                        AltKategoriID = c.Int(nullable: false, identity: true),
                        KategoriID = c.Int(nullable: false),
                        AltKategoriAdi = c.String(),
                        KategoriOzellikID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.AltKategoriID)
                .ForeignKey("dbo.Kategori", t => t.KategoriID, cascadeDelete: true)
                .Index(t => t.KategoriID);
            
            CreateTable(
                "dbo.Kategori",
                c => new
                    {
                        KategoriID = c.Int(nullable: false, identity: true),
                        KategoriAdi = c.String(),
                        IlanTuruID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.KategoriID)
                .ForeignKey("dbo.IlanTuru", t => t.IlanTuruID, cascadeDelete: true)
                .Index(t => t.IlanTuruID);
            
            CreateTable(
                "dbo.IlanTuru",
                c => new
                    {
                        IlanTuruID = c.Int(nullable: false, identity: true),
                        IlanTuruAdi = c.String(),
                    })
                .PrimaryKey(t => t.IlanTuruID);
            
            CreateTable(
                "dbo.DisOzellik",
                c => new
                    {
                        DisOzellikID = c.Int(nullable: false, identity: true),
                        DisOzellikAdi = c.String(),
                        Goster = c.Boolean(nullable: false),
                        IlanDetayID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.DisOzellikID)
                .ForeignKey("dbo.IlanDetay", t => t.IlanDetayID, cascadeDelete: true)
                .Index(t => t.IlanDetayID);
            
            CreateTable(
                "dbo.IlanDetay",
                c => new
                    {
                        IlanDetayID = c.Int(nullable: false, identity: true),
                        IlanID = c.Int(nullable: false),
                        BrütMetreKare = c.Decimal(nullable: false, precision: 18, scale: 2),
                        NetMetreKare = c.Decimal(nullable: false, precision: 18, scale: 2),
                        AltKategoriID = c.Int(nullable: false),
                        SemtID = c.Int(nullable: false),
                        DisOzellikID = c.Int(nullable: false),
                        IcOzellikID = c.Int(nullable: false),
                        KonumOzellikID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.IlanDetayID)
                .ForeignKey("dbo.AltKategori", t => t.AltKategoriID, cascadeDelete: true)
                .ForeignKey("dbo.Ilan", t => t.IlanID, cascadeDelete: true)
                .ForeignKey("dbo.Semt", t => t.SemtID, cascadeDelete: true)
                .Index(t => t.IlanID)
                .Index(t => t.AltKategoriID)
                .Index(t => t.SemtID);
            
            CreateTable(
                "dbo.IcOzellik",
                c => new
                    {
                        IcOzellikID = c.Int(nullable: false, identity: true),
                        IcOzellikAdi = c.String(),
                        Goster = c.Boolean(nullable: false),
                        IlanDetayID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.IcOzellikID)
                .ForeignKey("dbo.IlanDetay", t => t.IlanDetayID, cascadeDelete: true)
                .Index(t => t.IlanDetayID);
            
            CreateTable(
                "dbo.Ilan",
                c => new
                    {
                        IlanID = c.Int(nullable: false, identity: true),
                        IlanAdi = c.String(),
                        IlanTarihi = c.DateTime(nullable: false),
                        IlanNo = c.Int(nullable: false),
                        IlanFiyat = c.Decimal(nullable: false, precision: 18, scale: 2),
                        Aciklama = c.String(),
                        IlanVerenID = c.Int(nullable: false),
                        Resim_ResimID = c.Int(),
                    })
                .PrimaryKey(t => t.IlanID)
                .ForeignKey("dbo.IlanVeren", t => t.IlanVerenID, cascadeDelete: true)
                .ForeignKey("dbo.Resim", t => t.Resim_ResimID)
                .Index(t => t.IlanVerenID)
                .Index(t => t.Resim_ResimID);
            
            CreateTable(
                "dbo.IlanVeren",
                c => new
                    {
                        IlanVerenID = c.Int(nullable: false, identity: true),
                        IlanVerenTel = c.String(maxLength: 20),
                        IlanVerenCepTel = c.String(maxLength: 20),
                        IlanVerenSirket = c.String(),
                        IlanVerenWeb = c.String(),
                        Aciklama = c.String(),
                        Adres = c.String(),
                        IlanVerenResim = c.String(),
                        Semt_SemtID = c.Int(),
                    })
                .PrimaryKey(t => t.IlanVerenID)
                .ForeignKey("dbo.Semt", t => t.Semt_SemtID)
                .Index(t => t.Semt_SemtID);
            
            CreateTable(
                "dbo.KonumOzellik",
                c => new
                    {
                        KonumOzellikID = c.Int(nullable: false, identity: true),
                        KonumOzellikAdi = c.String(),
                        Goster = c.Boolean(nullable: false),
                        IlanDetayID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.KonumOzellikID)
                .ForeignKey("dbo.IlanDetay", t => t.IlanDetayID, cascadeDelete: true)
                .Index(t => t.IlanDetayID);
            
            CreateTable(
                "dbo.Semt",
                c => new
                    {
                        SemtID = c.Int(nullable: false, identity: true),
                        SemtAdi = c.String(),
                        IlceID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.SemtID)
                .ForeignKey("dbo.Ilce", t => t.IlceID, cascadeDelete: true)
                .Index(t => t.IlceID);
            
            CreateTable(
                "dbo.Ilce",
                c => new
                    {
                        IlceID = c.Int(nullable: false, identity: true),
                        IlceAdi = c.String(),
                        IlID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.IlceID)
                .ForeignKey("dbo.Il", t => t.IlID, cascadeDelete: true)
                .Index(t => t.IlID);
            
            CreateTable(
                "dbo.Il",
                c => new
                    {
                        IlID = c.Int(nullable: false, identity: true),
                        IlAdi = c.String(),
                    })
                .PrimaryKey(t => t.IlID);
            
            CreateTable(
                "dbo.KategoriOzellik",
                c => new
                    {
                        KategoriOzellikID = c.Int(nullable: false, identity: true),
                        IlanDetayID = c.Int(nullable: false),
                        Adi = c.String(),
                        Aciklama = c.String(),
                    })
                .PrimaryKey(t => t.KategoriOzellikID)
                .ForeignKey("dbo.IlanDetay", t => t.IlanDetayID, cascadeDelete: true)
                .Index(t => t.IlanDetayID);
            
            CreateTable(
                "dbo.Resim",
                c => new
                    {
                        ResimID = c.Int(nullable: false, identity: true),
                        ResimPath = c.String(),
                        ResimAdi = c.String(),
                        AnaResim = c.Boolean(nullable: false),
                        IlanID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ResimID);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Ilan", "Resim_ResimID", "dbo.Resim");
            DropForeignKey("dbo.KategoriOzellik", "IlanDetayID", "dbo.IlanDetay");
            DropForeignKey("dbo.IlanDetay", "SemtID", "dbo.Semt");
            DropForeignKey("dbo.Semt", "IlceID", "dbo.Ilce");
            DropForeignKey("dbo.Ilce", "IlID", "dbo.Il");
            DropForeignKey("dbo.IlanVeren", "Semt_SemtID", "dbo.Semt");
            DropForeignKey("dbo.KonumOzellik", "IlanDetayID", "dbo.IlanDetay");
            DropForeignKey("dbo.Ilan", "IlanVerenID", "dbo.IlanVeren");
            DropForeignKey("dbo.IlanDetay", "IlanID", "dbo.Ilan");
            DropForeignKey("dbo.IcOzellik", "IlanDetayID", "dbo.IlanDetay");
            DropForeignKey("dbo.DisOzellik", "IlanDetayID", "dbo.IlanDetay");
            DropForeignKey("dbo.IlanDetay", "AltKategoriID", "dbo.AltKategori");
            DropForeignKey("dbo.Kategori", "IlanTuruID", "dbo.IlanTuru");
            DropForeignKey("dbo.AltKategori", "KategoriID", "dbo.Kategori");
            DropIndex("dbo.KategoriOzellik", new[] { "IlanDetayID" });
            DropIndex("dbo.Ilce", new[] { "IlID" });
            DropIndex("dbo.Semt", new[] { "IlceID" });
            DropIndex("dbo.KonumOzellik", new[] { "IlanDetayID" });
            DropIndex("dbo.IlanVeren", new[] { "Semt_SemtID" });
            DropIndex("dbo.Ilan", new[] { "Resim_ResimID" });
            DropIndex("dbo.Ilan", new[] { "IlanVerenID" });
            DropIndex("dbo.IcOzellik", new[] { "IlanDetayID" });
            DropIndex("dbo.IlanDetay", new[] { "SemtID" });
            DropIndex("dbo.IlanDetay", new[] { "AltKategoriID" });
            DropIndex("dbo.IlanDetay", new[] { "IlanID" });
            DropIndex("dbo.DisOzellik", new[] { "IlanDetayID" });
            DropIndex("dbo.Kategori", new[] { "IlanTuruID" });
            DropIndex("dbo.AltKategori", new[] { "KategoriID" });
            DropTable("dbo.Resim");
            DropTable("dbo.KategoriOzellik");
            DropTable("dbo.Il");
            DropTable("dbo.Ilce");
            DropTable("dbo.Semt");
            DropTable("dbo.KonumOzellik");
            DropTable("dbo.IlanVeren");
            DropTable("dbo.Ilan");
            DropTable("dbo.IcOzellik");
            DropTable("dbo.IlanDetay");
            DropTable("dbo.DisOzellik");
            DropTable("dbo.IlanTuru");
            DropTable("dbo.Kategori");
            DropTable("dbo.AltKategori");
        }
    }
}
