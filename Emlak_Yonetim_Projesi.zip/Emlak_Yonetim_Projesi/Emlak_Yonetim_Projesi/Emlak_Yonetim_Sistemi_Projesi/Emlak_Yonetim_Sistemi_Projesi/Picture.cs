﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Emlak_Yonetim_Sistemi_Projesi
{
    public class Picture
    {
        public int index { get; set; }
        public int ResimID { get; set; }
        public string ResimPath { get; set; }
        public string ResimAdi { get; set; }

        public override string ToString()
        {
            return index.ToString();
        }
    }
}
