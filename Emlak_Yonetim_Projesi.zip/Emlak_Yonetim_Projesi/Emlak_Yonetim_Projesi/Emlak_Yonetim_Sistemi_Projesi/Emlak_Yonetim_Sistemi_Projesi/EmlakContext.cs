﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Emlak_Yonetim_Sistemi_Projesi
{
    public class EmlakContext : DbContext
    {
        public EmlakContext() : base("name=cnn") { }

        public virtual DbSet<Ilan> Ilanlar { get; set; }
        public virtual DbSet<IlanDetay> IlanDetaylari { get; set; }
        public virtual DbSet<IlanVeren> IlanVerenler { get; set; }
        public virtual DbSet<Kategori> Kategoriler { get; set; }
        public virtual DbSet<AltKategori> AltKategorileri { get; set; }
        public virtual DbSet<KategoriOzellik> KategoriOzellikleri { get; set; }
        public virtual DbSet<IlanTuru> IlanTurleri { get; set; }
        public virtual DbSet<Resim> Resimler { get; set; }
        public virtual DbSet<DisOzellik> DisOzellikleri { get; set; }
        public virtual DbSet<IcOzellik> IcOzellikleri { get; set; }
        public virtual DbSet<KonumOzellik> KonumOzellikleri { get; set; }
        public virtual DbSet<Semt> Semtler { get; set; }
        public virtual DbSet<Ilce> Ilceler { get; set; }
        public virtual DbSet<Il> Iller { get; set; }
    }

    [Table("Ilan")]
    public class Ilan
    {
        public Ilan()
        {
            this.ilanDetay = new HashSet<IlanDetay>();
            this.IlanTarihi = DateTime.Now;
        }
        [Key]
        public int IlanID { get; set; }
        public string IlanAdi { get; set; }
        public DateTime IlanTarihi { get; set; }
        public int IlanNo { get; set; }
        public decimal IlanFiyat { get; set; }
        public string Aciklama { get; set; }
        public int IlanVerenID { get; set; }
        //----------------
        public virtual IlanVeren ilanVeren { get; set; }
        public virtual ICollection<IlanDetay> ilanDetay { get; set; }
    }

    [Table("IlanDetay")]
    public class IlanDetay
    {
        public IlanDetay()
        {
        }
        [Key]
        public int IlanDetayID { get; set; }
        public int IlanID { get; set; }
        public decimal BrütMetreKare { get; set; }
        public decimal NetMetreKare { get; set; }
        public int AltKategoriID { get; set; }
        public int SemtID { get; set; }
        public int DisOzellikID { get; set; }
        public int IcOzellikID { get; set; }
        public int KonumOzellikID { get; set; }
        //--------------------
        public virtual AltKategori AltKategori { get; set; }
        public virtual Ilan Ilan { get; set; }
        public virtual Semt semt { get; set; }
        public virtual ICollection<DisOzellik> DisOzellik { get; set; }
        public virtual ICollection<IcOzellik> IcOzellik { get; set; }
        public virtual ICollection<KonumOzellik> KonumOzellik { get; set; }
    }
    [Table("DisOzellik")]
    public class DisOzellik
    {
        public DisOzellik()
        {
            //this.IlanDetay = new HashSet<IlanDetay>();
        }
        [Key]
        public int DisOzellikID { get; set; }
        public string DisOzellikAdi { get; set; }
        public bool Goster { get; set; }
        public int IlanDetayID { get; set; }

        //-----------------------------------

        public virtual IlanDetay IlanDetay { get; set; }
    }
    [Table("IcOzellik")]
    public class IcOzellik
    {
        public IcOzellik()
        {
            //this.IlanDetay = new HashSet<IlanDetay>();
        }
        [Key]
        public int IcOzellikID { get; set; }
        public string IcOzellikAdi { get; set; }
        public bool Goster { get; set; }
        public int IlanDetayID { get; set; }

        //-----------------------------------

        public virtual IlanDetay IlanDetay { get; set; }
    }
    [Table("KonumOzellik")]
    public class KonumOzellik
    {
        public KonumOzellik()
        {
        }
        [Key]
        public int KonumOzellikID { get; set; }
        public string KonumOzellikAdi { get; set; }
        public bool Goster { get; set; }
        public int IlanDetayID { get; set; }

        //-----------------------------------

        public virtual IlanDetay IlanDetay { get; set; }
    }

    [Table("KategoriOzellik")]
    public class KategoriOzellik
    {
        [Key]
        public int KategoriOzellikID { get; set; }
        public int IlanDetayID { get; set; }
        public string Adi { get; set; }
        public string Aciklama { get; set; }
        //---------------------------
        public virtual IlanDetay IlanDetay { get; set; }
    }

    [Table("Resim")]
    public class Resim
    {
        public Resim()
        {
            this.Ilan = new HashSet<Ilan>();
            this.AnaResim = false;
        }
        [Key]
        public int ResimID { get; set; }
        public string ResimPath { get; set; }
        public string ResimAdi { get; set; }
        public bool AnaResim { get; set; }
        public int IlanID { get; set; }

        public virtual ICollection<Ilan> Ilan { get; set; }

    }

    [Table("IlanVeren")]
    public class IlanVeren
    {
        public IlanVeren()
        {
        }
        [Key]
        public int IlanVerenID { get; set; }
        [MaxLength(20)]
        public string IlanVerenTel { get; set; }
        [MaxLength(20)]
        public string IlanVerenCepTel { get; set; }
        public string IlanVerenSirket { get; set; }
        public string IlanVerenWeb { get; set; }
        public string Aciklama { get; set; }
        public string Adres { get; set; }
        public string IlanVerenResim { get; set; }

        //---------------------------------
    }

    [Table("Kategori")]
    public class Kategori
    {
        public Kategori()
        {
            this.altKategori = new HashSet<AltKategori>();
        }
        [Key]
        public int KategoriID { get; set; }
        public string KategoriAdi { get; set; }
        public int IlanTuruID { get; set; }
        //------------------------
        public virtual IlanTuru IlanTuru { get; set; }
        public virtual ICollection<AltKategori> altKategori { get; set; }
    }

    [Table("AltKategori")]
    public class AltKategori
    {
        public AltKategori()
        {
        }
        [Key]
        public int AltKategoriID { get; set; }
        public int KategoriID { get; set; }
        public string AltKategoriAdi { get; set; }
        public int KategoriOzellikID { get; set; }
        //--------------------
        public virtual Kategori kategori { get; set; }
    }

    [Table("IlanTuru")]
    public class IlanTuru
    {
        [Key]
        public int IlanTuruID { get; set; }
        public string IlanTuruAdi { get; set; }
        //------------------------------

    }

    [Table("Semt")]
    public class Semt
    {
        public Semt()
        {
            this.ilanVeren = new HashSet<IlanVeren>();
        }
        [Key]
        public int SemtID { get; set; }
        public string SemtAdi { get; set; }
        public int IlceID { get; set; }
        //---------------
        public virtual Ilce ilce { get; set; }
        public virtual ICollection<IlanVeren> ilanVeren { get; set; }
    }

    [Table("Ilce")]
    public class Ilce
    {
        [Key]
        public int IlceID { get; set; }
        public string IlceAdi { get; set; }
        public int IlID { get; set; }
        //-------------------
        public virtual ICollection<Semt> semt { get; set; }
        public virtual Il il { get; set; }
    }

    [Table("Il")]
    public class Il
    {
        [Key]
        public int IlID { get; set; }
        public string IlAdi { get; set; }
        //----------------
        public virtual ICollection<Ilce> ilce { get; set; }
    }
}
