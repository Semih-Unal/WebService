﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using MyLoginScreen;

namespace MyLoginScreen
{
    public partial class CustomLoginForm : UserControl
    {
        string guid;
        public CustomLoginForm()
        {
            InitializeComponent();
            this.BackColor = Color.White;
        }

        // Event Oluşturma
        // Doğru giriş için delegate -> event oluşturalım

        public delegate void CorrectCustomLoginForm();
        public event CorrectCustomLoginForm correctCustomLoginForm;
        

        
        private void CustomLoginForm_Load(object sender, EventArgs e)
        {
            guid = Guid.NewGuid().ToString().Substring(0, 5).ToUpper();
            lblGuid.Text = guid;
            txtPassword.UseSystemPasswordChar = false;
            
        }
        // Buton Tıklandığında
        // Access Veritabanı kullanarak veri aktarımı gerçekleştirelim.
        string conStr = string.Format("Provider= Microsoft.Jet.OleDB.4.0; Data Source = {0}; Persist Security Info = False;", Application.StartupPath + "\\YoneticiDB.mdb");
        
        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtSecurityCode.Text.ToUpper() == guid) // Eğer güvenlik kodu doğru ise
            {

                OleDbConnection cnn = new OleDbConnection(conStr);
                // Oledb ile tablomuzu çekelim
                try
                {

                    if (cnn.State == ConnectionState.Closed)
                        cnn.Open();

                    OleDbCommand cmd = new OleDbCommand("Select * From Yoneticiler Where KullaniciAdi = @Ad and Sifre=@Sifre", cnn);
                    cmd.Parameters.AddWithValue("@Ad", txtUserName.Text);
                    cmd.Parameters.AddWithValue("@Sifre", txtPassword.Text);

                    OleDbDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        correctCustomLoginForm();
                    }
                    else // Eğer Kullanıcı Adı ve Şifre kodu doğru değilse ise
                    {
                        MessageBox.Show("Kullanıcı Adı veya Şifre Hatalı Girdiniz, Kontrol Edip Tekrar Deneyiniz !!!");
                        txtUserName.Text = "Kullanıcı Adı";
                        txtPassword.Text = "Şifre";
                        txtSecurityCode.Text = "Güvenlik Kodu";
                        txtuserfocus = false;
                        txtpswfocus = false;
                        txtguidfocus = false;
                        guid = Guid.NewGuid().ToString().Substring(0, 5).ToUpper();
                        lblGuid.Text = guid;
                    }
                }
                    catch (Exception ex)
                {
                    MessageBox.Show("Hatayla Karşılaşıldı, Tekrar Deneyiniz !!!" + ex.Message);
                }
                finally
                {
                    cnn.Close();
                }
            }
            else // Eğer güvenlik kodu doğru değil ise
            {
                MessageBox.Show("Güvenlik Kodunu Hatalı Girdiniz, Kontrol Edip Tekrar Deneyiniz !!!");
                txtUserName.Text = "Kullanıcı Adı";
                txtPassword.Text = "Şifre";
                txtSecurityCode.Text = "Güvenlik Kodu";
                txtuserfocus = false;
                txtpswfocus = false;
                txtguidfocus = false;
                guid = Guid.NewGuid().ToString().Substring(0, 5).ToUpper();
                lblGuid.Text = guid;
            }
        }
        
        #region TextBox Focus Olayı
        // TextBox'lar seçildiğinde text'lerini temizleme
        bool txtuserfocus = false;
        bool txtpswfocus = false;
        bool txtguidfocus = false;
        private void txtUserName_Enter(object sender, EventArgs e)
        {
            if (txtuserfocus == false)
            {
                if (txtUserName.Focused)
                {
                    txtUserName.Clear();
                }
                txtuserfocus = true;
            }
        }
        private void txtPassword_Enter(object sender, EventArgs e)
        {
            if (txtpswfocus == false)
            {
                if (txtPassword.Focused)
                {
                    txtPassword.UseSystemPasswordChar = true;
                    txtPassword.Clear();
                }
                txtpswfocus = true;
            }
        }
        private void txtSecurityCode_Enter(object sender, EventArgs e)
        {
            if (txtguidfocus == false)
            {
                if (txtSecurityCode.Focused)
                {
                    txtSecurityCode.Clear();
                }
                txtguidfocus = true;
            }
        }
        #endregion

    }
}
